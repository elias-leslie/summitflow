"""Credential loading for owner commands that call Agent Hub."""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

import typer

from .output import output_error

_ENV_FILE = ".env.local"
_KEY_CLIENT_ID = "SUMMITFLOW_CLIENT_ID"
_KEY_CLIENT_ID_LEGACY = "CONSULT_CLIENT_ID"
_KEY_REQUEST_SOURCE = "SUMMITFLOW_REQUEST_SOURCE"
_KEY_INTERNAL_SECRET = "INTERNAL_SERVICE_SECRET"


@lru_cache
def _read_env_local() -> dict[str, str]:
    """Read and cache approved Agent Hub identity fields from ~/.env.local."""
    env_file = Path.home() / _ENV_FILE
    if not env_file.exists():
        return {}
    creds: dict[str, str] = {}
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if line.startswith("export "):
            line = line[7:]
        if "=" in line and not line.startswith("#"):
            key, val = line.split("=", 1)
            key = key.strip()
            val = val.strip().strip("'\"")
            if key and val:
                creds[key] = val
    return creds


def load_credentials(default_source: str = "st-cli") -> tuple[str, str]:
    """Return the Agent Hub client id and request source."""
    creds = _read_env_local()
    if not creds:
        output_error(f"~/{_ENV_FILE} not found - required for Agent Hub authentication")
        raise typer.Exit(1)
    client_id = creds.get(_KEY_CLIENT_ID) or creds.get(_KEY_CLIENT_ID_LEGACY)
    if not client_id:
        output_error(f"Missing {_KEY_CLIENT_ID} in ~/{_ENV_FILE}")
        raise typer.Exit(1)
    return client_id, creds.get(_KEY_REQUEST_SOURCE, default_source)


def load_internal_service_secret() -> str:
    """Load the existing shared service secret from approved operator sources."""
    secret = os.getenv(_KEY_INTERNAL_SECRET, "").strip() or _read_env_local().get(
        _KEY_INTERNAL_SECRET, ""
    ).strip()
    if not secret:
        output_error(f"Missing {_KEY_INTERNAL_SECRET} in the process env or ~/{_ENV_FILE}")
        raise typer.Exit(1)
    return secret
