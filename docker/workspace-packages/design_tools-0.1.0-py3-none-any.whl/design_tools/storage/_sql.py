"""Host-provided static SQL composition helpers."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from ..host import join_static_sql as _join_static_sql
from ..host import static_sql as _static_sql


def static_sql(statement: str) -> Any:
    return _static_sql(statement)


def join_static_sql(fragments: Iterable[str], separator: str) -> Any:
    return _join_static_sql(fragments, separator)
