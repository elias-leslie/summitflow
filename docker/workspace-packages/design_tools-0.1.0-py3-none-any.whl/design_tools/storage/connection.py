"""Host-provided database connection context managers."""

from __future__ import annotations

from contextlib import AbstractContextManager
from typing import Any

from ..host import get_connection as _get_connection
from ..host import get_cursor as _get_cursor


def get_connection() -> AbstractContextManager[Any]:
    return _get_connection()


def get_cursor() -> AbstractContextManager[Any]:
    return _get_cursor()
