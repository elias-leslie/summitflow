"""Design Ops commands for UI mockups and game-art critique.

Use this when... matrix:

    Goal                                              | Command
    --------------------------------------------------+-----------------------
    Store hand-authored HTML as a new mockup          | st design ui create
    Add a hand-authored revision to an existing one   | st design ui attach
    Have an AI agent inspect a live URL and design    | st design ui analyze
    Have an AI agent regenerate an existing mockup    | st design ui rerun
    Critique a sprite / tile / game art image         | st design asset critique

`ui create` and `ui attach` are the right tools when an agent (Claude Code,
Codex CLI, etc.) wants to hand-author the HTML itself and just have it stored.
They never call an AI image / mockup agent.

`asset critique` sends a local image to an Agent Hub critic and prints the
critique; it does not save anything to Design Ops.

Design source gate: before making a UI mockup, ask the project lead whether
the current agent/user should hand-author it or the Agent Hub UI design agent
should generate it.

Storage gate: UI Design mockups are important project state. They must be
stored through SummitFlow's durable Design Ops storage, never in `/tmp` or
another temp-only location.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Any

import typer
from agent_hub_st.completion import call_complete
from st_sdk import APIError, STClient, get_config, usage
from st_sdk.output import (
    handle_api_error,
    output_error,
    output_json,
    require_explicit_project,
)

app = typer.Typer(
    help=(
        "Design Ops: UI mockups (hand-authored or AI) and game-art critique. "
        "Run `st design` for the full subcommand matrix."
    )
)
asset_app = typer.Typer(
    help=(
        "Game-art critique: send a local sprite, tile or other game image to "
        "an Agent Hub critic. Nothing is saved to Design Ops."
    )
)
ui_app = typer.Typer(
    help=(
        "UI Design mockups. `create` / `attach` store hand-authored HTML. "
        "`analyze` / `rerun` invoke the AI ui-mockup-designer agent."
    )
)

DEFAULT_ASSET_CRITIQUE_AGENT = "game-art-critic"
GEMMA_ASSET_CRITIQUE_AGENT = "game-art-critic-gemma"
# The ensemble is a panel of Agent Hub critics; each runs its configured route.
DEFAULT_ASSET_CRITIQUE_PANEL = (DEFAULT_ASSET_CRITIQUE_AGENT, GEMMA_ASSET_CRITIQUE_AGENT)


@app.callback(invoke_without_command=True)
@usage(
    surface="st.design",
    cmd="st design ui create | st design ui attach | st design asset critique",
    when="creating or revising UI mockups, or critiquing game art, sprites, icons or tile sets",
    precautions=(
        "before generating a UI mockup, ask the project lead whether the current agent/user should hand-author it or the Agent Hub UI design agent should generate it",
        "use st design ui create/attach for hand-authored HTML UI mockups; use st design ui analyze/rerun only when AI regeneration is wanted",
        "use st design asset critique for Agent Hub-routed visual critique of game art before accepting it; nothing is saved to Design Ops",
        "Design Ops storage is durable project state; never configure UI mockup storage under /tmp",
    ),
    task_types=("design", "ui-design", "design-review", "game-art"),
    on_demand="visual design",
    tier="guardrail",
)
def design_default(ctx: typer.Context) -> None:
    """Design Ops command group."""
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())


@asset_app.command("critique")
def critique_asset(
    image_file: Annotated[Path, typer.Argument(help="PNG/JPEG/GIF/WebP image to critique")],
    brief: Annotated[str | None, typer.Option("--brief", help="Asset-specific art direction / acceptance criteria")] = None,
    brief_file: Annotated[Path | None, typer.Option("--brief-file", help="Read art direction / acceptance criteria from a file")] = None,
    asset_kind: Annotated[
        str,
        typer.Option("--kind", help="Asset kind: sprite, animation, tileset, environment, ui, icon, vfx"),
    ] = "sprite",
    agent_slug: Annotated[
        str,
        typer.Option("--agent", help="Agent Hub visual critique agent slug"),
    ] = DEFAULT_ASSET_CRITIQUE_AGENT,
    gemma: Annotated[
        bool,
        typer.Option("--gemma", help="Use local Gemma 4 12B game-art critic agent"),
    ] = False,
    model_overrides: Annotated[
        list[str] | None,
        typer.Option("--model", "-M", help="Model override. Repeat for a critique panel."),
    ] = None,
    ensemble: Annotated[
        bool,
        typer.Option("--ensemble", help="Run the complementary critic-agent panel instead of only one agent."),
    ] = False,
    memory: Annotated[bool, typer.Option("--memory/--no-memory", help="Enable Agent Hub memory injection")] = True,
    timeout: Annotated[float, typer.Option("--timeout", "-t", min=1.0, help="HTTP read-timeout per critique call")] = 120.0,
) -> None:
    """Critique a visual game asset through Agent Hub.

    This is the canonical non-siloed game-asset critique surface. It calls an
    Agent Hub specialist (`game-art-critic` by default), can run a panel of
    critic agents, and returns compact structured output suitable for agent workflows.

    Examples:
        st -P the-aftertimes design asset critique ranger-proof.png --kind sprite
        st -P the-aftertimes design asset critique ranger-proof.png --kind sprite --gemma
        st -P the-aftertimes design asset critique ranger-proof.png --ensemble
        st design asset critique sheet.png -M gemini-3.8-flash -M codex/gpt-6.1-sol
    """
    cfg = get_config()
    require_explicit_project(cfg)
    if not image_file.is_file():
        output_error(f"Image not found: {image_file}")
        raise typer.Exit(1)
    effective_agent_slug = GEMMA_ASSET_CRITIQUE_AGENT if gemma else agent_slug
    resolved_brief = _resolve_optional_text(brief, brief_file)
    prompt = _build_asset_critique_prompt(asset_kind=asset_kind, brief=resolved_brief)
    plan = _critique_plan(effective_agent_slug, model_overrides, ensemble)

    critiques: list[dict[str, Any]] = []
    for slug, model in plan:
        model_prompt = f"@{model} {prompt}" if model else prompt
        label = model or f"{slug}:default"
        try:
            result = call_complete(
                agent_slug=slug,
                message=model_prompt,
                project_id=cfg.project_id,
                source_client="st-cli-design-asset-critique",
                use_memory=memory,
                timeout=timeout,
                skip_cache=True,
                task_type="design_asset_critique",
                images=[str(image_file)],
                source_metadata={
                    "surface": "st.design.asset.critique",
                    "asset_kind": asset_kind,
                    "image_file": str(image_file),
                    "model_override": model,
                    "ensemble": ensemble,
                    "gemma": gemma,
                },
                tool_name="st design asset critique",
            )
        except typer.Exit:
            raise
        except Exception as exc:  # pragma: no cover - defensive CLI boundary
            critiques.append({"agent": slug, "model": label, "ok": False, "error": str(exc)})
            continue
        critiques.append({
            "agent": slug,
            "model": label,
            "ok": not bool(result.get("error")),
            "content": result.get("content", ""),
            "session_id": result.get("session_id"),
            "model_used": result.get("model_used"),
            "provider": result.get("provider"),
            "fallback_used": result.get("fallback_used"),
            "fallback_reason": result.get("fallback_reason"),
            "raw_error": result.get("error"),
        })

    output_json({
        "success": all(item.get("ok") for item in critiques),
        "agent": effective_agent_slug,
        "project_id": cfg.project_id,
        "image_file": str(image_file),
        "asset_kind": asset_kind,
        "ensemble": len(plan) > 1,
        "models": [model or f"{slug}:default" for slug, model in plan],
        "critiques": critiques,
    })


def _resolve_optional_text(text: str | None, text_file: Path | None) -> str:
    """Resolve optional inline/file text."""
    parts: list[str] = []
    if text:
        parts.append(text)
    if text_file is not None:
        if not text_file.is_file():
            raise typer.BadParameter(f"Brief file not found: {text_file}")
        parts.append(text_file.read_text())
    return "\n\n".join(part.strip() for part in parts if part.strip())


def _critique_plan(
    agent_slug: str, model_overrides: list[str] | None, ensemble: bool
) -> list[tuple[str, str | None]]:
    """Return (agent slug, model override) pairs; None runs the agent's configured route."""
    cleaned = [model.strip() for model in model_overrides or [] if model.strip()]
    if cleaned:
        return [(agent_slug, model) for model in cleaned]
    if ensemble:
        return [(slug, None) for slug in DEFAULT_ASSET_CRITIQUE_PANEL]
    return [(agent_slug, None)]


def _build_asset_critique_prompt(*, asset_kind: str, brief: str) -> str:
    """Build the standard game-asset critique prompt."""
    brief_section = brief or "No extra brief supplied. Apply general production game-asset standards."
    return f"""You are critiquing a game {asset_kind} image for production use across 2D/3D game art media.

First prove you are looking at this exact image by naming 3-5 visible elements. If the image is unavailable, say that and stop; do not hallucinate.

Critique the whole image, not only the checklist. If the supplied brief is narrow, still report any other production issue you observe. For labeled direction sheets or turnaround poses, verify that each label actually faces that direction and flag any duplicate/mislabeled facing.

Evidence authority is strict:
- A project brief may contain an AUTHORITATIVE DETERMINISTIC VALIDATOR EVIDENCE block. Every measured fact in that block is ground truth and overrides visual inference.
- Never claim or request repairs for alpha/anti-aliasing, exact dimensions, palette membership, color counts, or outline gaps when deterministic evidence reports that check passing.
- If the preview merely looks soft or ambiguous while deterministic evidence passes, describe only the semantic readability concern. Do not turn that impression into a technical defect or blocking repair.
- Blocking issues must be semantic art-quality problems or failures explicitly reported by deterministic evidence. Never invent a validator failure.

Critique against these standards:
- strong silhouette/readability at intended game scale;
- disciplined hard pixel clusters and no blurry pseudo-pixel art when the asset is pixel art;
- coherent shape language, value grouping, material/readability, and export-safe edges for non-pixel 2D/UI art;
- proportions, material/texture read, UV/normal/lighting artifacts when visible, and rig/LOD readiness for 3D/model renders;
- non-generic player/enemy/environment identity;
- material separation, lighting direction, and beautiful cohesive mood;
- animation/runtime readiness: pivots, contacts, seams, scale, alpha, and engine export risks;
- concrete local edits an agent can implement.

Project/user brief:
{brief_section}

Return only:
1. Vision sanity: concrete observed elements.
2. Verdict: approve / approve-with-revisions / reject.
3. Blocking issues: exact region + why it hurts quality.
4. Concrete edit instructions: exact local edits.
5. Animation/engine-readiness risks.
6. What not to change.
7. Evidence conflicts: none, or name any visual impression you withheld because deterministic evidence overruled it.
8. Usefulness score 1-10.
"""


@ui_app.command("analyze")
def analyze_ui(
    page_url: Annotated[str, typer.Argument(help="Fully-qualified page URL to analyze")],
    page_path: Annotated[
        str | None,
        typer.Option("--page-path", help="Optional project page path metadata"),
    ] = None,
) -> None:
    """AI-analyze a live URL and produce a UI mockup via the design agent.

    Requires the page to be reachable. Invokes the `ui-mockup-designer` agent
    through Agent Hub, which screenshots the page and proposes a redesign.
    Use this when you want AI-generated suggestions from a live reference.

    Use `st design ui create` instead when you (or another agent) want to
    hand-author the HTML and just have it stored without AI regeneration.
    """
    require_explicit_project(get_config())
    client = STClient()

    try:
        result = client.post(
            client._url("/mockups/analyze-page"),
            json={"page_url": page_url, "page_path": page_path},
        )
    except APIError as exc:
        handle_api_error(exc)
        raise typer.Exit(1) from None

    output_json(result)


@ui_app.command("rerun")
def rerun_ui_mockup(
    mockup_id: Annotated[str, typer.Argument(help="Mockup id to rerun")],
    notes: Annotated[
        str | None,
        typer.Option("--notes", "-n", help="Revision notes for the UI mockup agent"),
    ] = None,
    notes_file: Annotated[
        Path | None,
        typer.Option("--notes-file", help="Path to a file containing revision notes"),
    ] = None,
) -> None:
    """Rerun a stored UI mockup through the AI design agent.

    Always invokes the `ui-mockup-designer` agent and saves the regenerated
    HTML as a child version. The agent rewrites the HTML — your exact markup
    will not survive.

    Use `st design ui attach` instead when you want to save a hand-authored
    revision under an existing mockup without AI regeneration.
    """
    require_explicit_project(get_config())
    revision_notes = _resolve_notes(notes, notes_file)
    client = STClient()

    try:
        result = client.post(
            client._url(f"/mockups/{mockup_id}/rerun"),
            json={"notes": revision_notes},
        )
    except APIError as exc:
        handle_api_error(exc)
        raise typer.Exit(1) from None

    output_json(result)


@ui_app.command("create")
def create_ui_mockup(
    name: Annotated[str, typer.Argument(help="Mockup display name")],
    html: Annotated[
        str | None,
        typer.Option("--html", help="Inline HTML content for the mockup"),
    ] = None,
    html_file: Annotated[
        Path | None,
        typer.Option("--html-file", help="Path to a file containing the HTML mockup"),
    ] = None,
    description: Annotated[
        str | None,
        typer.Option("--description", "-d", help="Optional description stored with the mockup"),
    ] = None,
    mockup_type: Annotated[
        str,
        typer.Option(
            "--mockup-type",
            help="Mockup classification: page, component, layout, flow, system",
        ),
    ] = "page",
    reference_url: Annotated[
        str | None,
        typer.Option("--reference-url", help="Live page URL this mockup references (stored as page_path)"),
    ] = None,
    reference_image: Annotated[
        Path | None,
        typer.Option(
            "--reference-image",
            help="Path to a reference screenshot; stored in metadata as reference_image_path",
        ),
    ] = None,
    tags: Annotated[
        str | None,
        typer.Option("--tags", help="Comma-separated tags stored in metadata"),
    ] = None,
    task_id: Annotated[
        str | None,
        typer.Option("--task-id", help="Optional task id to associate with the mockup"),
    ] = None,
) -> None:
    """Store hand-authored HTML as a new mockup (no AI regeneration).

    Use this when you (or another agent) want to commit a specific HTML
    layout and have it appear in the project's design gallery exactly as
    written. The HTML is saved verbatim with generator="manual-html".

    Don't use this for AI-driven mockup generation — use `ui analyze` for
    a fresh AI proposal from a live URL, or `ui rerun` to revise an existing
    mockup with the AI agent.

    Examples:
        st -P portfolio-ai design ui create today-layout-a \\
            --html-file /tmp/layout-a.html \\
            --reference-url https://example.com/ \\
            --reference-image /tmp/today.png \\
            -d "Balanced /today layout: hero + digest"

        st -P portfolio-ai design ui create signal-card --html "<section>...</section>" \\
            --mockup-type component --tags "signals,deterministic"
    """
    require_explicit_project(get_config())
    content = _resolve_html(html, html_file)
    client = STClient()

    payload = _build_manual_mockup_payload(
        name=name,
        content=content,
        description=description,
        mockup_type=mockup_type,
        reference_url=reference_url,
        reference_image=reference_image,
        tags=tags,
        task_id=task_id,
    )

    try:
        result = client.post(client._url("/mockups"), json=payload)
    except APIError as exc:
        handle_api_error(exc)
        raise typer.Exit(1) from None

    output_json(result)


@ui_app.command("attach")
def attach_ui_mockup(
    mockup_id: Annotated[
        str,
        typer.Argument(help="Existing mockup id (e.g. mk-abc123) to attach a revision to"),
    ],
    html: Annotated[
        str | None,
        typer.Option("--html", help="Inline HTML content for the revision"),
    ] = None,
    html_file: Annotated[
        Path | None,
        typer.Option("--html-file", help="Path to a file containing the revision HTML"),
    ] = None,
    description: Annotated[
        str | None,
        typer.Option("--description", "-d", help="Optional description stored with the revision"),
    ] = None,
    reference_url: Annotated[
        str | None,
        typer.Option("--reference-url", help="Live page URL this revision references"),
    ] = None,
    reference_image: Annotated[
        Path | None,
        typer.Option(
            "--reference-image",
            help="Path to a reference screenshot; stored in metadata as reference_image_path",
        ),
    ] = None,
) -> None:
    """Attach a hand-authored HTML revision to an existing mockup.

    Resolves the public mockup id (string) to its DB row id and creates a
    child mockup linked via parent_mockup_id, preserving the iteration chain
    in the gallery. The HTML is stored verbatim — no AI regeneration.

    Use `st design ui rerun` instead when you want the AI ui-mockup-designer
    agent to generate the next iteration for you.

    Example:
        st -P portfolio-ai design ui attach mk-abc123 \\
            --html-file /tmp/layout-a-v2.html \\
            -d "Tightened spacing, added deterministic badge"
    """
    require_explicit_project(get_config())
    content = _resolve_html(html, html_file)
    client = STClient()

    try:
        parent = client.get(client._url(f"/mockups/{mockup_id}"))
    except APIError as exc:
        handle_api_error(exc)
        raise typer.Exit(1) from None

    parent_db_id = parent.get("id")
    if not isinstance(parent_db_id, int):
        raise typer.BadParameter(
            f"Could not resolve parent mockup id from {mockup_id} (no integer 'id' field)"
        )

    name = parent.get("name") or mockup_id
    payload = _build_manual_mockup_payload(
        name=name,
        content=content,
        description=description,
        mockup_type=parent.get("mockup_type") or "page",
        reference_url=reference_url or parent.get("page_path"),
        reference_image=reference_image,
        tags=None,
        task_id=parent.get("task_id"),
        parent_mockup_id=parent_db_id,
    )

    try:
        result = client.post(client._url("/mockups"), json=payload)
    except APIError as exc:
        handle_api_error(exc)
        raise typer.Exit(1) from None

    output_json(result)


def _build_manual_mockup_payload(
    *,
    name: str,
    content: str,
    description: str | None,
    mockup_type: str,
    reference_url: str | None,
    reference_image: Path | None,
    tags: str | None,
    task_id: str | None,
    parent_mockup_id: int | None = None,
) -> dict[str, Any]:
    """Build a POST /mockups payload for hand-authored HTML."""
    metadata: dict[str, Any] = {}
    if reference_image is not None:
        metadata["reference_image_path"] = str(reference_image)
    parsed_tags = _split_csv(tags)
    if parsed_tags:
        metadata["tags"] = parsed_tags

    payload: dict[str, Any] = {
        "name": name,
        "mockup_type": mockup_type,
        "content": content,
        "generator": "manual-html",
    }
    if description:
        payload["description"] = description
    if reference_url:
        payload["page_path"] = reference_url
    if task_id:
        payload["task_id"] = task_id
    if parent_mockup_id is not None:
        payload["parent_mockup_id"] = parent_mockup_id
    if metadata:
        payload["metadata"] = metadata
    return payload


def _split_csv(value: str | None) -> list[str]:
    """Split a comma-separated option into trimmed values."""
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def _resolve_notes(notes: str | None, notes_file: Path | None) -> str:
    """Resolve revision notes from an option or file."""
    if notes and notes_file:
        raise typer.BadParameter("Use either --notes or --notes-file, not both")
    value = notes_file.read_text(encoding="utf-8").strip() if notes_file else (notes or "").strip()
    if not value:
        raise typer.BadParameter("Revision notes are required")
    return value


def _resolve_html(html: str | None, html_file: Path | None) -> str:
    """Resolve mockup HTML content from an inline option or file."""
    if html and html_file:
        raise typer.BadParameter("Use either --html or --html-file, not both")
    value = html_file.read_text(encoding="utf-8") if html_file else (html or "")
    if not value.strip():
        raise typer.BadParameter("HTML content is required (use --html or --html-file)")
    return value


app.add_typer(asset_app, name="asset")
app.add_typer(ui_app, name="ui")
