"""Explicit host bindings for infrastructure owned by the embedding application."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Iterable
from contextlib import AbstractContextManager
from dataclasses import dataclass
from pathlib import Path
from subprocess import CompletedProcess
from typing import Any


class HostNotConfiguredError(RuntimeError):
    """A host-dependent operation ran before bindings were installed."""


@dataclass(frozen=True)
class HostBindings:
    """Infrastructure callbacks supplied once by the embedding ST host."""

    get_connection: Callable[[], AbstractContextManager[Any]]
    get_cursor: Callable[[], AbstractContextManager[Any]]
    static_sql: Callable[[str], Any]
    join_static_sql: Callable[[Iterable[str], str], Any]
    get_explorer_entry: Callable[[int], dict[str, Any] | None]
    get_sync_client: Callable[[], Any]
    get_agent: Callable[[str], Any]
    run_browser_command: Callable[[list[str], float], Awaitable[CompletedProcess[str]]]
    logger_factory: Callable[[str], Any]
    image_agent_slug: str
    mockup_base_dir: Path


_bindings: HostBindings | None = None


def configure(bindings: HostBindings) -> HostBindings | None:
    """Install host bindings and return the previous value.

    Reinstalling the same object is intentionally harmless. Returning the old
    value lets tests restore process-global bindings without hidden monkeypatch
    hooks.
    """
    global _bindings
    previous = _bindings
    _bindings = bindings
    return previous


def restore(bindings: HostBindings | None) -> HostBindings | None:
    """Restore a previously returned binding value and return the replaced one."""
    global _bindings
    previous = _bindings
    _bindings = bindings
    return previous


def get_bindings() -> HostBindings:
    """Return configured bindings or fail at the host-dependent operation."""
    if _bindings is None:
        raise HostNotConfiguredError(
            "Design Tools host is not configured; call design_tools.configure(HostBindings(...)) "
            "before using storage, generation, Explorer, browser, or logging operations."
        )
    return _bindings


class _LazyHostLogger:
    """Resolve the host logger only when a logging operation is attempted."""

    def __init__(self, name: str) -> None:
        self._name = name
        self._resolved: Any | None = None

    def __getattr__(self, attribute: str) -> Any:
        if self._resolved is None:
            self._resolved = get_bindings().logger_factory(self._name)
        return getattr(self._resolved, attribute)


def get_logger(name: str) -> Any:
    """Return a lazy logger without forcing host setup during pure imports."""
    return _LazyHostLogger(name)


def get_connection() -> AbstractContextManager[Any]:
    return get_bindings().get_connection()


def get_cursor() -> AbstractContextManager[Any]:
    return get_bindings().get_cursor()


def static_sql(statement: str) -> Any:
    return get_bindings().static_sql(statement)


def join_static_sql(fragments: Iterable[str], separator: str) -> Any:
    return get_bindings().join_static_sql(fragments, separator)


def get_explorer_entry(entry_id: int) -> dict[str, Any] | None:
    return get_bindings().get_explorer_entry(entry_id)


def get_sync_client() -> Any:
    return get_bindings().get_sync_client()


def get_agent(agent_slug: str) -> Any:
    return get_bindings().get_agent(agent_slug)


async def run_browser_command(
    command: list[str], timeout: float
) -> CompletedProcess[str]:
    return await get_bindings().run_browser_command(command, timeout)


def get_image_agent_slug() -> str:
    return get_bindings().image_agent_slug


def get_mockup_base_dir_default() -> Path:
    return get_bindings().mockup_base_dir
