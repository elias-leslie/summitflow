"""Prompt builders for design analysis and improved-mockup images."""

from __future__ import annotations

from ._templates import ANALYSIS_RESPONSE_FORMAT

MOCKUP_RESOLUTION = "1920x1080"
COLOR_BACKGROUND = "#0f0a18"
COLOR_SURFACE = "#1a0a2e"
COLOR_ACCENT_PRIMARY = "#00f5ff"
COLOR_ACCENT_SECONDARY = "#ff00ff"
COLOR_TEXT_PRIMARY = "#ffffff"
COLOR_TEXT_MUTED = "#a0a0a0"

_DARK_THEME_COLORS = (
    f"   - Background: {COLOR_BACKGROUND} (deep purple-black)\n"
    f"   - Cards/surfaces: {COLOR_SURFACE} (slightly lighter)\n"
    f"   - Primary accent: {COLOR_ACCENT_PRIMARY} (cyan)\n"
    f"   - Secondary accent: {COLOR_ACCENT_SECONDARY} (magenta)\n"
    f"   - Text: {COLOR_TEXT_PRIMARY} (white) and {COLOR_TEXT_MUTED} (muted)"
)


def build_design_analysis_prompt(page_url: str) -> str:
    """Build prompt for design analysis."""
    return (
        f"Analyze this screenshot of a web page for design and UX issues.\n\n"
        f"PAGE URL: {page_url}\n\n"
        f"YOUR TASK:\n"
        f"1. Identify specific design and UX issues\n"
        f"2. Provide actionable improvement recommendations\n\n"
        f"RESPONSE FORMAT:\n{ANALYSIS_RESPONSE_FORMAT}"
    )


def build_mockup_image_prompt(
    recommendations: str,
    page_url: str,
) -> str:
    """Build prompt for generating an improved mockup image."""
    return (
        f"Generate a UI mockup image showing an IMPROVED version of a web application page.\n\n"
        f"CONTEXT:\nThis is a redesign of the page at: {page_url}\n\n"
        f"CURRENT ISSUES AND RECOMMENDED FIXES:\n{recommendations}\n\n"
        f"REQUIREMENTS:\n"
        f"1. Create a high-fidelity UI mockup at {MOCKUP_RESOLUTION} resolution\n"
        f"2. Apply ALL the recommended fixes from the analysis above\n"
        f"3. Maintain the overall page structure and purpose\n"
        f"4. Use a modern dark theme with these colors:\n{_DARK_THEME_COLORS}\n"
        f"5. Ensure proper visual hierarchy, spacing, and contrast\n"
        f"6. Make text legible and UI elements clearly defined\n"
        f"7. Show realistic content (not lorem ipsum)\n\n"
        f"OUTPUT:\nA single polished UI mockup image showing the IMPROVED design with all issues fixed."
    )


__all__ = [
    "build_design_analysis_prompt",
    "build_mockup_image_prompt",
]
