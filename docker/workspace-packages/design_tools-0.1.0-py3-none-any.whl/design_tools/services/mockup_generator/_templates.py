"""Static prompt templates for design analysis."""

from __future__ import annotations

ANALYSIS_RESPONSE_FORMAT = """\
## Summary
<1-2 sentences summarizing overall design quality>

## Issues Found

### Critical (Must Fix)
<List critical issues that significantly impact usability or accessibility>

### Warnings (Should Fix)
<List issues that impact design quality but aren't critical>

### Suggestions (Nice to Have)
<List optional improvements>

## Specific Recommendations

<For each significant issue, provide:>
1. **Issue**: <description>
   **Location**: <where on the page>
   **Fix**: <specific actionable recommendation>

## Design Score
- Typography: X/5
- Layout: X/5
- Color/Contrast: X/5
- Accessibility: X/5
- Overall UX: X/5

Be specific and actionable. Reference actual elements visible in the screenshot."""
