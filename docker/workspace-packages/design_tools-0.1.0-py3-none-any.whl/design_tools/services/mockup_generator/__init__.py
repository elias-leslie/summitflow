"""Mockup generator service for design audit workflows.

Analyzes a live page by URL and stores the screenshot, recommendations, and an
improved mockup image in the mockups table.

This module is organized as follows:
- models.py: Data models (DesignAnalysisResult)
- prompts.py: Prompt builders for design analysis and improved-mockup images
- analysis/: Design analysis, screenshot, and mockup-image tools
- storage_helpers.py: Storage utilities
- _workflows.py: Internal workflow helpers (analyze_page_design logic)
"""

from __future__ import annotations

from ._workflows import run_analyze_page_design
from .models import DesignAnalysisResult


async def analyze_page_design(
    project_id: str,
    page_url: str,
    page_path: str | None = None,
) -> DesignAnalysisResult:
    """Analyze a page's design and generate improvement recommendations.

    Delegates to _workflows.run_analyze_page_design for the full workflow:
    1. Capture screenshot of the page
    2. Fetch design standards for the project
    3. Analyze screenshot against standards using vision
    4. Store mockup record with screenshot and recommendations

    Args:
        project_id: Project ID
        page_url: Full URL to analyze
        page_path: Optional page path (for storage, defaults to URL path)

    Returns:
        DesignAnalysisResult with mockup details
    """
    return await run_analyze_page_design(project_id, page_url, page_path)


__all__ = [
    "DesignAnalysisResult",
    "analyze_page_design",
]
