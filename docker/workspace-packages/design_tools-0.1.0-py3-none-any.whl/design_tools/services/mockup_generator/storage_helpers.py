"""Storage helpers for Design Ops mockup and asset generation."""

from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Any

from ...host import get_mockup_base_dir_default

_TMP_ROOT = Path("/tmp").resolve()


def _resolve_mockup_base_dir() -> Path:
    """Resolve durable Design Ops storage and refuse temporary locations."""
    configured = os.environ.get("SUMMITFLOW_MOCKUP_BASE_DIR")
    default = get_mockup_base_dir_default()
    base_dir = Path(configured).expanduser() if configured else default
    if configured and not base_dir.is_absolute():
        # The historical fallback was <summitflow-root>/data/design-studio/mockups.
        # The host supplies that exact fallback; recover its repository root so
        # existing relative overrides retain their old meaning.
        base_dir = default.parents[2] / base_dir
    resolved = base_dir.resolve(strict=False)
    if resolved == _TMP_ROOT or _TMP_ROOT in resolved.parents:
        raise RuntimeError(
            "Refusing to use /tmp for Design Ops mockup/asset storage. "
            "Set SUMMITFLOW_MOCKUP_BASE_DIR to a durable path."
        )
    return resolved


def get_mockup_base_dir() -> Path:
    """Resolve durable storage lazily so pure package imports need no host."""
    return _resolve_mockup_base_dir()


class _LazyMockupBaseDir(os.PathLike[str]):
    """Path-compatible view retained for existing facade and test consumers."""

    def __fspath__(self) -> str:
        return os.fspath(get_mockup_base_dir())

    def __str__(self) -> str:
        return str(get_mockup_base_dir())

    def __truediv__(self, other: Any) -> Path:
        return get_mockup_base_dir() / other

    def resolve(self, *args: Any, **kwargs: Any) -> Path:
        return get_mockup_base_dir().resolve(*args, **kwargs)

    @property
    def parts(self) -> tuple[str, ...]:
        return get_mockup_base_dir().parts

    @property
    def parents(self) -> Any:
        return get_mockup_base_dir().parents


# Compatibility name: unlike the historical eager Path, this proxy resolves at
# first path use so importing prompts and schemas does not require host setup.
MOCKUP_BASE_DIR = _LazyMockupBaseDir()


def generate_mockup_id() -> str:
    """Generate a new mockup ID in the format mk-{uuid}."""
    return f"mk-{uuid.uuid4().hex[:12]}"


def get_mockup_directory(project_id: str, mockup_id: str) -> Path:
    """Get the directory path for a mockup.

    Args:
        project_id: Project ID
        mockup_id: Mockup ID

    Returns:
        Path to the mockup directory
    """
    return get_mockup_base_dir() / project_id / mockup_id


__all__ = [
    "MOCKUP_BASE_DIR",
    "generate_mockup_id",
    "get_mockup_base_dir",
    "get_mockup_directory",
]
