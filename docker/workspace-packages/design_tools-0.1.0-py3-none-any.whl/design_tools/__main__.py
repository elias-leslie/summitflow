"""Executable owner entry point for the Design Tools ST namespace."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from st_sdk.runtime import run_app

from .commands.design import app


def main(args: Sequence[str] | None = None) -> Any:
    """Run the Design Tools command surface through the public ST runtime."""
    return run_app(app, "design", args)


if __name__ == "__main__":
    main()
