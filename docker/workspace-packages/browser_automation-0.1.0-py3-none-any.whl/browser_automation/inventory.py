"""Read-only, structured inventory of locally installed browser runtimes."""

from __future__ import annotations

import json
import re
import shutil
import subprocess

from .contract import BrowserRequest


def _version(executable: str | None) -> tuple[str | None, str, str | None]:
    if not executable:
        return None, "absent", None
    resolved = shutil.which(executable)
    if resolved is None:
        return None, "absent", None
    try:
        result = subprocess.run(
            [resolved, "--version"], text=True, capture_output=True, check=False, timeout=5
        )
    except (OSError, subprocess.TimeoutExpired):
        return resolved, "error", None
    if result.returncode:
        return resolved, "error", None
    line = result.stdout.strip().splitlines()
    version = line[0] if line else None
    return resolved, "observed" if version else "error", version


def _entry(name: str, executable: str | None) -> dict[str, object]:
    path, status, raw = _version(executable)
    number = re.search(r"\b\d+\.\d+(?:\.\d+){0,3}\b", raw or "")
    return {
        "id": name,
        "executable": path,
        "installed_version": number.group(0) if number else None,
        "installed_status": status if status != "observed" or number else "error",
        "latest_version": None,
        "latest_status": "unchecked",
        "recommended_version": None,
        "recommended_status": "unchecked",
    }


def inventory(request: BrowserRequest) -> int:
    prefix = request.launch.prefix
    chrome = (
        prefix[prefix.index("--executable-path") + 1]
        if "--executable-path" in prefix and prefix.index("--executable-path") + 1 < len(prefix)
        else None
    )
    result = {
        "schema_version": 1,
        "owner": "browser-automation",
        "scope": "local-host",
        "runtimes": [
            _entry("agent-browser", request.launch.agent_browser_bin),
            _entry("chrome", chrome),
            _entry("playwright-cli", "playwright-cli"),
        ],
    }
    print(json.dumps(result, sort_keys=True))
    return 0
