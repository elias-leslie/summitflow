"""Bound data presentation without changing authoritative execution evidence."""
from __future__ import annotations

import json
import re
from typing import Any

_TREE_FIELDS = {"snapshot", "tree", "refs", "removedRefs", "changes", "treeChange"}
_REF = re.compile(r"\[ref=(e\d+)\]|@(e\d+)\b")
_AUTHORITY_FIELDS = {"error", "errors", "status", "binding", "coverage", "dialogOpened"}


def _size(value: Any) -> int:
    return len(json.dumps(value, separators=(",", ":")))


def _authority_evidence(value: Any, path: str) -> dict[str, Any]:
    """Retain nested diagnostic/recovery fields with their original JSON pointers."""
    retained: dict[str, Any] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            child_path = path + "/" + key.replace("~", "~0").replace("/", "~1")
            if key in _AUTHORITY_FIELDS:
                retained[child_path] = child
            else:
                retained.update(_authority_evidence(child, child_path))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            retained.update(_authority_evidence(child, f"{path}/{index}"))
    return retained


def _data_preview(value: Any, allowance: int) -> Any:
    """Keep typed values intact when they fit; explicitly wrap incomplete data."""
    if not value or _size(value) <= allowance or not isinstance(value, (dict, list, str)):
        return value
    kind = "object" if isinstance(value, dict) else "array" if isinstance(value, list) else "string"
    result: dict[str, Any] = {"preview_only": True, "type": kind, "complete": False,
                              "value": {} if isinstance(value, dict) else [] if isinstance(value, list) else ""}
    if isinstance(value, str):
        result["total_chars"] = len(value)
        result["returned_chars"] = 0
        low, high = 0, len(value)
        while low < high:
            middle = (low + high + 1) // 2
            result["value"] = value[:middle]
            result["returned_chars"] = middle
            if _size(result) <= allowance:
                low = middle
            else:
                high = middle - 1
        result["value"] = value[:low]
        result["returned_chars"] = low
        return result
    result.update({"total_items": len(value), "returned_items": 0})
    collection: dict[str, Any] | list[Any]
    if isinstance(value, dict):
        collection = {key: child for key, child in value.items() if key in _AUTHORITY_FIELDS}
    else:
        collection = []
    result["value"] = collection
    result["returned_items"] = len(collection)
    used = _size(result)
    items = value.items() if isinstance(value, dict) else enumerate(value)
    for key, child in items:
        if isinstance(value, dict) and key in _AUTHORITY_FIELDS:
            continue
        # Account for each append once. Re-serializing the growing collection at
        # every item would make large multiple-field extraction quadratic.
        count = result["returned_items"]
        count_growth = len(str(count + 1)) - len(str(count))
        overhead = (_size(key) + 1 if isinstance(value, dict) else 0) + int(count > 0) + count_growth
        available = allowance - used - overhead
        if available <= 0:
            break
        bounded = _data_preview(child, available)
        if _size(bounded) > available:
            break
        if isinstance(collection, dict):
            collection[str(key)] = bounded
        else:
            collection.append(bounded)
        result["returned_items"] += 1
        used += overhead + _size(bounded)
        if bounded != child:
            break
    return result


def _observation_preview(observation: dict[str, Any], fraction: float) -> tuple[dict[str, Any], dict[str, Any]]:
    # Native delta snapshots nest kind/revisions/refs/tree under snapshot. Legacy
    # snapshots return a flat string and refs. Preserve metadata in either shape.
    nested = isinstance(observation.get("snapshot"), dict)
    tree = observation["snapshot"] if nested else observation
    source = "snapshot.tree" if nested else "snapshot"
    text = tree.get("tree" if nested else "snapshot")
    if not isinstance(text, str):
        change = tree.get("treeChange")
        lines = change.get("lines") if isinstance(change, dict) else None
        text = "\n".join(lines) if isinstance(lines, list) and all(isinstance(line, str) for line in lines) else ""
        source = "snapshot.treeChange.lines" if nested else "treeChange.lines"
    refs = tree.get("refs")
    refs = refs if isinstance(refs, dict) else {}
    count = int(len(text) * fraction)
    excerpt = text[:count]
    partial_line = False
    if count < len(text) and count:
        end = excerpt.rfind("\n")
        if end >= 0:
            excerpt = excerpt[:end]
        else:
            partial_line = True
    visible: set[str] = set()
    for match in _REF.finditer(excerpt):
        # The excerpt's end is not necessarily a real token boundary: clipping
        # @e123 to @e12 must not promote a different, existing ref e12.
        complete_token = _REF.match(text, match.start())
        if complete_token is not None and complete_token.end() <= len(excerpt):
            visible.add(match[1] or match[2])
    selected_refs = {key: refs[key] for key in sorted(visible) if key in refs}
    bounded = {key: value for key, value in tree.items() if key not in _TREE_FIELDS}
    bounded.update({"preview_only": True, "refs": selected_refs})
    if source.endswith("treeChange.lines"):
        bounded["preview"] = {"source": source, "text": excerpt}
    else:
        bounded["tree" if nested else "snapshot"] = excerpt
    result = {**observation, "snapshot": bounded} if nested else bounded
    coverage = {"complete": False, "delta_applicable": False, "source": source,
                "returned_chars": len(excerpt), "total_chars": len(text), "partial_line": partial_line,
                "returned_refs": len(selected_refs), "total_refs": len(refs),
                "omitted_fields": sorted((set(tree) & _TREE_FIELDS) - {"snapshot", "tree", "refs"})}
    return result, coverage


def stdout_receipt(receipt: dict[str, Any], max_chars: int | None) -> dict[str, Any]:
    """Preview large observations and successful results; preserve recovery facts.

    Action indices, status, binding, errors, and postconditions are authoritative.
    If those exceed the requested budget, report that floor explicitly. Complete
    artifacts and recording always consume the unchanged receipt.
    """
    if max_chars is None or _size(receipt) + 1 <= max_chars:
        return receipt
    observation = receipt.get("observation")
    action_sizes = [_size(item.get("result")) for item in receipt.get("completed", [])]
    retained_evidence: dict[str, Any] = {}
    for item in receipt.get("completed", []):
        retained_evidence.update(_authority_evidence(item.get("result"), f"/completed/{item['index']}/result"))
    extraction = receipt.get("extraction")
    data_size = _size(extraction["data"]) if isinstance(extraction, dict) and "data" in extraction else None

    def candidate(fraction: float) -> dict[str, Any]:
        result = dict(receipt)
        output: dict[str, Any] = {"max_chars": max_chars, "truncated": False,
                                "budget_exceeded": False, "complete_artifact": receipt["details"]}
        if retained_evidence:
            output["retained_evidence"] = retained_evidence
        if isinstance(observation, dict):
            result["observation"], output["observation"] = _observation_preview(observation, fraction)
            output["truncated"] = True
        bounded_paths = []
        if action_sizes:
            result["completed"] = []
            for item, size in zip(receipt["completed"], action_sizes):
                bounded = _data_preview(item.get("result"), int(size * fraction))
                result["completed"].append({**item, "result": bounded})
                if bounded != item.get("result"):
                    bounded_paths.append(f"completed[{item['index']}].result")
        if data_size is not None and isinstance(extraction, dict):
            bounded = _data_preview(extraction["data"], int(data_size * fraction))
            result["extraction"] = {**extraction, "data": bounded}
            if bounded != extraction["data"]:
                bounded_paths.append("extraction.data")
        if bounded_paths:
            output["truncated"] = True
            output["incomplete_data"] = bounded_paths
        result["output"] = output
        return result

    minimum = candidate(0)
    if _size(minimum) + 1 > max_chars:
        minimum["output"]["budget_exceeded"] = True
        return minimum
    low, high = 0, 1_000_000
    while low < high:
        middle = (low + high + 1) // 2
        if _size(candidate(middle / 1_000_000)) + 1 <= max_chars:
            low = middle
        else:
            high = middle - 1
    return candidate(low / 1_000_000)
