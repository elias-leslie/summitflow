"""Deterministic browser workflows with durable action checkpoints and human waits."""
from __future__ import annotations

import contextlib
import fcntl
import io
import json
import os
import re
from dataclasses import replace
from hashlib import sha256
from pathlib import Path
from typing import Any
from uuid import uuid4

from . import sessions
from .contract import BrowserRequest
from .payload import validate_payload
from .structured import execute_structured

_TEMPLATE = re.compile(r'\{\{([A-Za-z][A-Za-z0-9_]*)\}\}')
_SENSITIVE = re.compile(r'password|credential|secret|token|private.?key|cookie|authorization', re.I)


def _directory() -> Path:
    base = sessions.state_base().parent / 'workflow-runs'
    sessions._private(base, create=True)
    return base


def _path(run_id: str) -> Path:
    if not isinstance(run_id, str) or not run_id.strip():
        raise ValueError('Workflow run_id is required')
    return _directory() / (sha256(run_id.encode()).hexdigest() + '.json')


@contextlib.contextmanager
def _record_lock(run_id: str):
    path = _path(run_id).with_suffix('.lock')
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield path.with_suffix('.json')
    finally:
        os.close(fd)


def _read(run_id: str) -> dict[str, Any]:
    path = _path(run_id)
    if path.is_symlink() or path.stat().st_uid != os.getuid() or path.stat().st_mode & 0o077:
        raise ValueError('Workflow checkpoint ownership is unverifiable')
    record = json.loads(path.read_text())
    if record.get('actor') != sessions.actor_identity() or record.get('run_id') != run_id:
        raise ValueError('Workflow run belongs to a different owner')
    return record


def _save(record: dict[str, Any], *, create: bool = False, cancellation_only: bool = False) -> dict[str, Any]:
    with _record_lock(record['run_id']) as path:
        if path.exists():
            existing = _read(record['run_id'])
            if create:
                raise ValueError('Workflow run_id already exists; resume or inspect it')
            if cancellation_only:
                record = {**existing, 'cancel_requested': True}
            if existing.get('cancel_requested'):
                record['cancel_requested'] = True
        tmp = path.with_name(path.name + '.' + uuid4().hex)
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, 'w') as stream:
                json.dump(record, stream, separators=(',', ':'))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(tmp, path)
            directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        finally:
            tmp.unlink(missing_ok=True)
        return record


def _substitute(value: Any, parameters: dict[str, Any]) -> Any:
    if isinstance(value, str):
        def replace_match(match):
            name = match.group(1)
            if name not in parameters:
                raise ValueError(f'Missing workflow parameter {name}')
            item = parameters[name]
            if not isinstance(item, (str, int, float, bool)) or isinstance(item, (dict, list)):
                raise ValueError(f'Workflow parameter {name} must be scalar')
            return str(item)
        return _TEMPLATE.sub(replace_match, value)
    if isinstance(value, list):
        return [_substitute(item, parameters) for item in value]
    if isinstance(value, dict):
        return {key: _substitute(item, parameters) for key, item in value.items()}
    return value


def validate_definition(definition: Any, parameters: Any) -> dict[str, Any]:
    if not isinstance(definition, dict) or set(definition) - {'schema_version','name','parameters','steps'} or definition.get('schema_version') != 1:
        raise ValueError('Workflow definition requires schema_version 1, name, parameters, steps')
    if not isinstance(definition.get('name'), str) or not definition['name'].strip():
        raise ValueError('Workflow name is required')
    if not isinstance(parameters, dict) or any(_SENSITIVE.search(key) for key in parameters):
        raise ValueError('Workflow parameters must be a non-sensitive object; use a human sign-in checkpoint')
    specifications = definition.get('parameters', {})
    if not isinstance(specifications, dict):
        raise ValueError('Workflow parameters schema must be an object')
    parameters = dict(parameters)
    for name, spec in specifications.items():
        if not isinstance(spec, dict) or set(spec)-{'type','required','default','sensitive'} or spec.get('sensitive') or _SENSITIVE.search(name):
            raise ValueError('Sensitive parameters cannot be persisted; use a human checkpoint')
        if name not in parameters:
            if 'default' in spec:
                parameters[name] = spec['default']
            elif spec.get('required', True):
                raise ValueError(f'Missing workflow parameter {name}')
        if name in parameters:
            value = parameters[name]
            kind = spec.get('type', 'string')
            if kind not in {'string','number','boolean'} or (kind=='string' and not isinstance(value,str)) or (kind=='boolean' and type(value) is not bool) or (kind=='number' and (type(value) not in {int,float})):
                raise ValueError(f'Invalid workflow parameter {name}')
    steps = definition.get('steps')
    if not isinstance(steps, list) or not steps:
        raise ValueError('Workflow steps must be non-empty')
    resolved = _substitute(definition, parameters)
    ids = set()
    for step in resolved['steps']:
        if not isinstance(step, dict) or set(step)-{'id','actions','postconditions','effect','mode','observation','screenshot'}:
            raise ValueError('Workflow step has unsupported fields')
        identifier = step.get('id')
        if not isinstance(identifier,str) or not identifier or identifier in ids:
            raise ValueError('Workflow step ids must be unique strings')
        ids.add(identifier)
        if step.get('mode','automatic') not in {'automatic','human'} or step.get('effect','write') not in {'read','write'}:
            raise ValueError('Workflow step mode/effect is invalid')
        actions = step.get('actions', [])
        if not actions and step.get('mode') != 'human':
            raise ValueError('Automatic workflow steps require actions')
        validate_payload('run', {'actions': actions or [['eval','true']], 'postconditions':step.get('postconditions',[]), 'observation':step.get('observation'), 'screenshot':step.get('screenshot')})
        if any(any(re.fullmatch(r'@e\d+', argument) for argument in action) for action in actions):
            raise ValueError('Workflows require semantic find commands or stable selectors; transient refs cannot be replayed')
        if any(action[0] in {'auth','cookies','storage','eval','clipboard'} for action in actions):
            raise ValueError('Workflow actions cannot persist credentials or arbitrary script/state; use semantic controls and human checkpoints')
    return resolved


def _run_step(request: BrowserRequest, runner, step: dict[str, Any], cursor: int, *, assertion_only: bool = False) -> dict[str, Any]:
    actions = [['get','url']] if assertion_only else step['actions'][cursor:]
    payload = {key:step[key] for key in ('postconditions','observation','screenshot') if key in step}
    payload['actions'] = actions or [['get','url']]
    capture = io.StringIO()
    with contextlib.redirect_stdout(capture):
        execute_structured(replace(request,operation='run',payload=payload), runner)
    return json.loads(capture.getvalue())


def _summary(record: dict[str, Any]) -> dict[str, Any]:
    return {key:record.get(key) for key in ('schema_version','run_id','session','status','step_cursor','action_cursor','completed','waiting','error','last_receipt','cancel_requested','cleanup')}


def execute_workflow(request: BrowserRequest, runner, session: sessions.Session | None = None) -> int:
    payload = request.payload or {}
    action, run_id = payload['action'], payload['run_id']
    name = request.launch.managed_session
    if not isinstance(name,str):
        raise ValueError('Workflow requires a managed session')
    record: dict[str,Any]
    if action == 'run':
        definition = validate_definition(payload['definition'], payload.get('parameters',{}))
        record = {'schema_version':1,'run_id':run_id,'session':name,'actor':sessions.actor_identity(),'definition':definition,'status':'running','step_cursor':0,'action_cursor':0,'completed':[],'inflight':False,'cancel_requested':False}
        _save(record,create=True)
    else:
        record = _read(run_id)
        if record['session'] != name:
            raise ValueError('Workflow session changed; select the original owned session')
    if action == 'status':
        print(json.dumps(_summary(record),separators=(',',':')))
        return 0
    if action == 'cancel':
        # Independent short record lock lets a running invocation observe cancel
        # between steps without allowing simultaneous browser mutations.
        record = _save(record, cancellation_only=True)
        if record['status'] in {'complete','cancelled'}:
            record['status'] = 'cancelled' if record['status'] != 'complete' else 'complete'
        else:
            try:
                with sessions.session_lock(name) as held:
                    record = _read(run_id)
                    current = sessions.resolve(name,lock=held)
                    from .engine import _managed_request
                    record['cleanup']=sessions.close(name,request=_managed_request(request,current),runner=runner,lock=held)
                    record['status']='cancelled' if record['cleanup']['closed'] else 'unknown'
                    _save(record)
            except sessions.SessionBusy:
                pass  # The active loop observes durable cancel intent between steps.
        print(json.dumps(_summary(record),separators=(',',':')))
        return 0
    if record['status'] in {'complete','cancelled'}:
        print(json.dumps(_summary(record),separators=(',',':')))
        return 0
    if session is None:
        raise ValueError('Workflow execution needs an owned session lease')
    if record.get('inflight') and record['definition']['steps'][record['step_cursor']].get('effect','write') == 'write':
        record['status']='waiting_human'
        record['waiting']={'step':record['definition']['steps'][record['step_cursor']]['id'],'reason':'Interrupted write outcome requires reconciliation'}
    resolution = payload.get('resolution')
    if record['status'] == 'waiting_human':
        step = record['definition']['steps'][record['step_cursor']]
        if not resolution or resolution['step'] != step['id']:
            _save(record)
            sessions.pause(session.name,lock=session.lock)
            print(json.dumps(_summary(record),separators=(',',':')))
            return 3
        if resolution['outcome']=='completed':
            receipt = _run_step(request,runner,step,0,assertion_only=True)
            if receipt['status'] != 'complete':
                record['last_receipt']=receipt
                _save(record)
                sessions.pause(session.name,lock=session.lock)
                print(json.dumps(_summary(record),separators=(',',':')))
                return 3
            record['completed'].append(step['id'])
            record['step_cursor']+=1
            record['action_cursor']=0
        record['inflight']=False
        record['status']='running'
        record.pop('waiting',None)
    while record['step_cursor'] < len(record['definition']['steps']):
        if _read(run_id).get('cancel_requested'):
            record['status']='cancelled'
            break
        step = record['definition']['steps'][record['step_cursor']]
        if step.get('mode')=='human' and not (resolution and resolution['step']==step['id'] and resolution['outcome']=='retry'):
            record['status']='waiting_human'
            record['waiting']={'step':step['id'],'reason':'Human action required'}
            break
        record['inflight']=True
        record['status']='running'
        _save(record)
        receipt = _run_step(request,runner,step,record['action_cursor'])
        record['last_receipt']=receipt
        record['action_cursor']+=len(receipt.get('completed',[]))
        record['inflight']=False
        if receipt['status'] != 'complete':
            record['status']='waiting_human' if step.get('effect','write')=='write' else 'failed'
            record['waiting']={'step':step['id'],'reason':'Inspect partial outcome before resuming'}
            break
        record['completed'].append(step['id'])
        record['step_cursor']+=1
        record['action_cursor']=0
        _save(record)
    if record['step_cursor']==len(record['definition']['steps']):
        record['status']='complete'
    _save(record)
    if record['status']=='waiting_human':
        sessions.pause(session.name,lock=session.lock)
    elif record['status'] in {'complete','cancelled'}:
        record['cleanup']=sessions.close(session.name,request=request,runner=runner,lock=session.lock)
        if not record['cleanup']['closed']:
            record['status']='unknown'
            record['error']='Workflow finished but session cleanup incomplete'
        _save(record)
    print(json.dumps(_summary(record),separators=(',',':')))
    return 0 if record['status'] in {'complete','cancelled'} else 3 if record['status']=='waiting_human' else 2
