"""Owner assist window for a paused managed session.

When an agent pauses a session for the owner (login, 2FA, "look at this", a yes/no
question), `ensure` starts one small loopback server for that session as a
transient user unit and, when the owner is at the workstation, opens it as a
focused Chrome app window. The page is the live browser plus a slim bar with the
agent's reason and only the needed controls (Done, or Approve/Decline). The
server holds the human input lease only while a viewer is connected, relays
frames and input in memory (nothing is recorded), and exits once the session
stops waiting. Remote viewers reach it through the host's authenticated proxy,
which supplies the per-server token in a header.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import math
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
from importlib.resources import files
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit, urlunsplit

from . import sessions

ANSWERS = ("approve", "decline")
OWNER_IDLE_MS = 5 * 60_000
MAX_LIFETIME_S = 2 * 3600
WINDOW_SIZE = "1280,900"
TOKEN_HEADER = "X-Assist-Token"
# A proxied page must open its socket on the proxy's path, not the loopback one.
WS_PATH_HEADER = "X-Assist-Ws"
_PASSED_ENV = ("PATH", "HOME", "XDG_STATE_HOME", "XDG_RUNTIME_DIR", "DBUS_SESSION_BUS_ADDRESS")


def _dir() -> Path:
    path = sessions.state_base().parent / "assist"
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    return path


def _state_path(name: str) -> Path:
    return _dir() / f"{sessions._key(name)}.json"


def _answer_path(name: str) -> Path:
    return _dir() / f"{sessions._key(name)}.answer.json"


def unit_name(name: str) -> str:
    return f"st-browser-assist-{sessions._key(name)}"


def _write(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_name(f".{path.name}.{os.getpid()}")
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(value, handle)
    temporary.replace(path)


def _read(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return value if isinstance(value, dict) else None


def _run(args: list[str], timeout: float = 5) -> subprocess.CompletedProcess[str] | None:
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError):
        return None


def _unit_active(name: str) -> bool:
    result = _run(["systemctl", "--user", "is-active", "--quiet", unit_name(name)])
    return result is not None and result.returncode == 0


def running(name: str) -> dict[str, Any] | None:
    """{name, actor, port, token, ...} of the live assist server for NAME, else None."""
    state = _read(_state_path(name))
    if not state or type(state.get("port")) is not int or not _unit_active(name):
        return None
    return state


def local_url(state: dict[str, Any]) -> str:
    return f"http://127.0.0.1:{state['port']}/?t={state['token']}"


def owner_at_desktop() -> bool:
    """The owner's graphical session is active, unlocked and used in the last few minutes."""
    listed = _run(["loginctl", "list-sessions", "--no-legend"])
    if listed is None or listed.returncode:
        return False
    uid = str(os.getuid())
    for line in listed.stdout.splitlines():
        fields = line.split()
        if len(fields) < 2 or fields[1] != uid:
            continue
        shown = _run(["loginctl", "show-session", fields[0], "-p", "Type", "-p", "Active",
                      "-p", "LockedHint", "-p", "IdleHint"])
        props = dict(item.split("=", 1) for item in (shown.stdout.splitlines() if shown else []) if "=" in item)
        if (props.get("Type") in {"x11", "wayland"} and props.get("Active") == "yes"
                and props.get("LockedHint") == "no" and props.get("IdleHint") == "no"):
            idle = _run(["gdbus", "call", "--session", "--dest", "org.gnome.Mutter.IdleMonitor",
                         "--object-path", "/org/gnome/Mutter/IdleMonitor/Core",
                         "--method", "org.gnome.Mutter.IdleMonitor.GetIdletime"])
            match = re.search(r"uint64 (\d+)", idle.stdout) if idle and idle.returncode == 0 else None
            # Without GNOME's idle monitor, logind's idle hint alone decides.
            return match is None or int(match.group(1)) < OWNER_IDLE_MS
    return False


def open_window(url: str) -> bool:
    """A Chrome app window on the owner's desktop, outside the caller's process tree."""
    result = _run(["systemd-run", "--user", "--collect", "--quiet", "--",
                   "google-chrome", f"--app={url}", f"--window-size={WINDOW_SIZE}"], timeout=15)
    return result is not None and result.returncode == 0


def ensure(name: str, actor: str, *, reason: str = "", question: str = "", st_bin: str | None = None,
           window: bool | None = None, start_timeout_s: float = 10) -> dict[str, Any]:
    """Start NAME's assist server unless it already runs; pop its window for a new hand-off.

    window=None opens it only when the owner is at the workstation. A repeated call
    while the server runs never opens a second window.
    """
    sessions._name(name)
    if running(name):
        return {"started": False, "window": False}
    executable = st_bin or shutil.which("st")
    if not executable:
        raise sessions.SessionError("st is not on PATH; the assist window needs it for the live view")
    _answer_path(name).unlink(missing_ok=True)
    path = _state_path(name)
    _write(path, {"name": name, "actor": actor, "reason": reason, "question": question,
                  "token": secrets.token_urlsafe(24), "st": executable, "started_ms": int(time.time() * 1000)})
    env = [f"--setenv={key}={os.environ[key]}" for key in _PASSED_ENV if os.environ.get(key)]
    env += [f"--setenv={key}={value}" for key, value in os.environ.items()
            if key.startswith("ST_BROWSER_") and key not in {"ST_BROWSER_OWNER", "ST_BROWSER_SHARED_PROFILE"}]
    # A failed earlier server leaves its unit name behind until reset.
    _run(["systemctl", "--user", "reset-failed", unit_name(name)])
    started = _run(["systemd-run", "--user", "--collect", "--quiet", f"--unit={unit_name(name)}", *env,
                    "--", sys.executable, "-m", "browser_automation.assist", "serve", name], timeout=15)
    if started is None or started.returncode:
        raise sessions.SessionError("assist window server did not start")
    deadline = time.monotonic() + start_timeout_s
    while (state := _read(path)) is None or type(state.get("port")) is not int:
        if time.monotonic() >= deadline:
            raise sessions.SessionError("assist window server did not report its port")
        time.sleep(0.1)
    opened = (owner_at_desktop() if window is None else window) and open_window(local_url(state))
    return {"started": True, "window": opened}


def stop(name: str) -> None:
    """End NAME's assist server (its viewer's lease is released first)."""
    if _unit_active(name):
        _run(["systemctl", "--user", "stop", unit_name(name)], timeout=30)


def take_answer(name: str) -> str | None:
    """The owner's Approve/Decline for NAME's question, consumed once."""
    path = _answer_path(name)
    record = _read(path)
    path.unlink(missing_ok=True)
    answer = record.get("answer") if record else None
    return answer if answer in ANSWERS else None


def render_page(config: dict[str, Any]) -> str:
    """The assist page with its config embedded; also used by proxies for the not-waiting state."""
    template = files("browser_automation").joinpath("assets/assist/index.html").read_text(encoding="utf-8")
    payload = json.dumps(config).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    title = "Browser needs you" if config.get("waiting") else "Browser session"
    return template.replace("__ASSIST_CONFIG__", payload).replace("__ASSIST_TITLE__", title)


def input_event(raw: str) -> dict[str, Any]:
    """Only native input, frame acknowledgements and the owner's finish controls."""
    if len(raw) > 4096:
        raise ValueError("Input message is too large")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("Invalid native input")
    kind = value.get("type")
    if kind == "done" and set(value) == {"type"}:
        return value
    if kind == "answer" and set(value) == {"type", "answer"} and value["answer"] in ANSWERS:
        return value
    if kind == "ack" and set(value) == {"type", "seq"} and type(value["seq"]) is int and value["seq"] >= 0:
        return value
    if kind == "input_mouse":
        allowed = {"type", "eventType", "x", "y", "button", "clickCount", "deltaX", "deltaY", "modifiers"}
        if value.get("eventType") not in {"mousePressed", "mouseReleased", "mouseMoved", "mouseWheel"}:
            raise ValueError("Invalid mouse event")
        if value.get("button", "none") not in {"none", "left", "middle", "right"}:
            raise ValueError("Invalid mouse button")
        for field in ("x", "y"):
            if type(value.get(field)) not in {int, float} or not math.isfinite(value[field]) or not 0 <= value[field] <= 100000:
                raise ValueError("Invalid mouse position")
        for field in ("deltaX", "deltaY", "clickCount", "modifiers"):
            number = value.get(field, 0)
            if type(number) not in {int, float} or not math.isfinite(number) or abs(number) > 100000:
                raise ValueError("Invalid mouse input")
        if type(value.get("clickCount", 0)) is not int or not 0 <= value.get("clickCount", 0) <= 3:
            raise ValueError("Invalid mouse click count")
        if type(value.get("modifiers", 0)) is not int or not 0 <= value.get("modifiers", 0) <= 15:
            raise ValueError("Invalid mouse modifiers")
    elif kind == "input_keyboard":
        allowed = {"type", "eventType", "key", "code", "text", "windowsVirtualKeyCode", "modifiers"}
        if value.get("eventType") not in {"keyDown", "keyUp", "char"}:
            raise ValueError("Invalid keyboard event")
        for field in ("key", "code", "text"):
            if field in value and (not isinstance(value[field], str) or len(value[field]) > 64):
                raise ValueError("Invalid keyboard input")
        for field in ("windowsVirtualKeyCode", "modifiers"):
            if field in value and (type(value[field]) is not int or not 0 <= value[field] <= 65535):
                raise ValueError("Invalid keyboard input")
        if value.get("modifiers", 0) > 15:
            raise ValueError("Invalid keyboard modifiers")
    else:
        raise ValueError("Unsupported native input")
    if set(value) - allowed:
        raise ValueError("Unknown native input field")
    return value


def display_url(value: object) -> str:
    """Human display never carries OAuth queries, fragments or URL credentials."""
    if not isinstance(value, str):
        return ""
    try:
        parts = urlsplit(value)
        if parts.scheme not in {"http", "https", "about"}:
            return ""
        return urlunsplit((parts.scheme, parts.netloc.rsplit("@", 1)[-1], parts.path, "", ""))
    except ValueError:
        return ""


class Server:
    """One session's assist server: page, single viewer, lease and finish controls."""

    def __init__(self, name: str) -> None:
        state = _read(_state_path(name))
        if not state or state.get("name") != name:
            raise sessions.SessionError("assist state is missing")
        self.name, self.state = name, state
        self.actor, self.token, self.st = str(state["actor"]), str(state["token"]), str(state["st"])
        os.environ["ST_BROWSER_OWNER"] = self.actor
        self.finished = asyncio.Event()
        self.viewer: tuple[Any, asyncio.Event] | None = None
        self.busy = asyncio.Lock()

    def _config(self, ws_path: str) -> dict[str, Any]:
        return {"waiting": True, "name": self.name, "reason": self.state.get("reason") or "",
                "question": self.state.get("question") or "", "ws": ws_path}

    def _authorized(self, request: Any) -> bool:
        query = parse_qs(urlsplit(request.path).query).get("t", [""])[0]
        offered = request.headers.get(TOKEN_HEADER) or query
        return secrets.compare_digest(offered, self.token)

    def process_request(self, connection: Any, request: Any) -> Any:
        from http import HTTPStatus

        path = urlsplit(request.path).path
        if path not in {"/", "/ws"}:
            return connection.respond(HTTPStatus.NOT_FOUND, "Not found\n")
        if not self._authorized(request):
            return connection.respond(HTTPStatus.FORBIDDEN, "Forbidden\n")
        if path == "/":
            ws_path = request.headers.get(WS_PATH_HEADER) or f"/ws?t={self.token}"
            response = connection.respond(HTTPStatus.OK, render_page(self._config(ws_path)))
            response.headers["Content-Type"] = "text/html; charset=utf-8"
            response.headers["Cache-Control"] = "no-store"
            response.headers["Referrer-Policy"] = "no-referrer"
            return response
        return None

    def _command(self, *args: str) -> list[str]:
        return [self.st, "--no-compact", "browser", "--local-ai", "session", *args]

    def _env(self) -> dict[str, str]:
        return {**os.environ, "ST_BROWSER_OWNER": self.actor}

    async def _waiting(self) -> bool:
        def check() -> bool:
            try:
                current = sessions.status(self.name, self.actor)
            except sessions.SessionBusy:
                return True
            except sessions.SessionError:
                return False
            return current["paused"] is True and current["state"] not in {"closed", "revoked"}
        return await asyncio.to_thread(check)

    async def watchdog(self) -> None:
        deadline = time.monotonic() + MAX_LIFETIME_S
        while not self.finished.is_set():
            await asyncio.sleep(5)
            if self.viewer is None and not self.busy.locked() and not await self._waiting():
                self.finished.set()
            if time.monotonic() >= deadline:
                self.finished.set()

    async def handler(self, ws: Any) -> None:
        if self.viewer is not None:
            # The newest viewer (desktop or phone) takes over; the lease moves with it.
            previous, released = self.viewer
            await previous.close(code=1000, reason="Opened in another window")
            await released.wait()
        released = asyncio.Event()
        self.viewer = (ws, released)
        try:
            await self._view(ws)
        finally:
            released.set()
            if self.viewer is not None and self.viewer[0] is ws:
                self.viewer = None

    async def _view(self, ws: Any) -> None:
        from websockets.asyncio.client import connect
        from websockets.exceptions import ConnectionClosed, WebSocketException

        await ws.send(json.dumps({"type": "hello", **self._config("")}))
        if not await self._waiting():
            await ws.send(json.dumps({"type": "ended"}))
            return
        lease = await asyncio.create_subprocess_exec(
            *self._command("lease", self.name), env=self._env(), stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL, start_new_session=True)
        finish: dict[str, Any] | None = None
        try:
            assert lease.stdout is not None
            view = json.loads(await asyncio.wait_for(lease.stdout.readline(), timeout=30))
            stream, binding = view.get("stream") or {}, view.get("binding") or {}
            if (view.get("status") != "leased" or view.get("paused") is not True
                    or type(stream.get("port")) is not int or binding.get("session") != self.name):
                raise ValueError("live view is unavailable")
            target = binding.get("target_id")
            async with connect(f"ws://127.0.0.1:{stream['port']}/?pacing=ack&maxFps=15", max_size=8 * 1024 * 1024,
                               open_timeout=5, close_timeout=5, proxy=None) as upstream:
                await upstream.send(json.dumps({"type": "config", "pacing": "ack", "maxFps": 15}))
                page = view.get("page") or {}
                await ws.send(json.dumps({"type": "bound", "url": display_url(page.get("url")),
                                          "title": page.get("title") if isinstance(page.get("title"), str) else ""}))

                async def inputs() -> None:
                    nonlocal finish
                    async for raw in ws:
                        event = input_event(raw if isinstance(raw, str) else raw.decode())
                        if event["type"] in {"done", "answer"}:
                            finish = event
                            return
                        await upstream.send(json.dumps(event))

                async def frames() -> None:
                    async for raw in upstream:
                        value = json.loads(raw)
                        if not isinstance(value, dict):
                            continue
                        if value.get("type") == "frame":
                            await ws.send(raw if isinstance(raw, str) else raw.decode())
                        elif value.get("type") == "url":
                            await ws.send(json.dumps({"type": "url", "url": display_url(value.get("url"))}))
                        elif value.get("type") == "tabs":
                            tabs = value.get("tabs") if isinstance(value.get("tabs"), list) else []
                            active = [tab for tab in tabs if isinstance(tab, dict) and tab.get("active") is True]
                            if len(active) != 1 or active[0].get("targetId") != target:
                                raise ValueError("browser tab changed")

                async def ended() -> None:
                    await self.finished.wait()

                tasks = [asyncio.create_task(loop()) for loop in (inputs, frames, ended)]
                done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
                for task in done:
                    task.result()
        except (ValueError, OSError, TimeoutError, KeyError, AttributeError, WebSocketException) as exc:
            if not isinstance(exc, ConnectionClosed):
                with contextlib.suppress(WebSocketException):
                    await ws.send(json.dumps({"type": "error", "message": "The live view stopped. Reconnect to try again."}))
        finally:
            # Release the lease before any lifecycle change so queued human input
            # cannot race the agent's next command.
            await self._release(lease)
        if finish is not None:
            await self._finish(ws, finish)
        elif self.finished.is_set():
            with contextlib.suppress(WebSocketException):
                await ws.send(json.dumps({"type": "ended"}))

    async def _release(self, lease: asyncio.subprocess.Process) -> None:
        if lease.stdin is not None:
            lease.stdin.close()
        try:
            await asyncio.wait_for(lease.wait(), timeout=10)
        except TimeoutError:
            lease.terminate()
            await lease.wait()

    async def _finish(self, ws: Any, event: dict[str, Any]) -> None:
        from websockets.exceptions import WebSocketException

        async with self.busy:
            answer = event.get("answer")
            if answer is not None:
                _write(_answer_path(self.name), {"name": self.name, "answer": answer, "at_ms": int(time.time() * 1000)})
            result = await asyncio.create_subprocess_exec(
                *self._command("resume", self.name), env=self._env(),
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            ok = await result.wait() == 0
            if not ok:
                _answer_path(self.name).unlink(missing_ok=True)
            with contextlib.suppress(WebSocketException):
                await ws.send(json.dumps({"type": "done", "ok": ok, "answer": answer}))
            if ok:
                self.finished.set()


async def _serve(name: str) -> None:
    from websockets.asyncio.server import serve as serve_ws

    server = Server(name)
    path = _state_path(name)
    async with serve_ws(server.handler, "127.0.0.1", 0, process_request=server.process_request,
                        max_size=64 * 1024) as listener:
        port = next(iter(listener.sockets)).getsockname()[1]
        _write(path, {**server.state, "port": port, "pid": os.getpid()})
        watchdog = asyncio.create_task(server.watchdog())
        await server.finished.wait()
        await asyncio.sleep(1)  # Let the finished page receive its last message.
        watchdog.cancel()
    state = _read(path)
    if state and state.get("token") == server.token:
        path.unlink(missing_ok=True)


def main(argv: list[str]) -> int:
    if len(argv) != 2 or argv[0] != "serve":
        print("usage: python -m browser_automation.assist serve NAME", file=sys.stderr)
        return 2
    asyncio.run(_serve(argv[1]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
