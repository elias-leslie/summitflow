"""Lifecycle of explicitly owned, ephemeral local browser runtimes.

The recovery boundary is an ownership record plus exact process identity. Shared
profiles and unmarked legacy daemons are never candidates.
"""
from __future__ import annotations

import ctypes
import errno
import json
import os
import re
import select
import shutil
import signal
import socket
import subprocess
import time
from dataclasses import dataclass
from hashlib import sha1
from pathlib import Path

_SCHEMA = 1
_SESSION = re.compile(r"[A-Za-z0-9_-]+")
# agent-browser 0.38.1 documents a 30-second CLI IPC read timeout.
CLOSE_TIMEOUT_SECONDS = 30
# Preserve the existing managed reaper's TERM grace before KILL.
_TERM_GRACE_MS = 250
# The installed cleanup timer runs every two minutes.
_RUN_BUDGET_SECONDS = 120



def _pidfd_open(pid: int) -> int:
    libc = ctypes.CDLL(None, use_errno=True)
    try:
        function = libc.pidfd_open
    except AttributeError as exc:
        raise OSError(errno.ENOSYS, "pidfd_open unavailable; cannot safely terminate") from exc
    function.argtypes = [ctypes.c_int, ctypes.c_uint]
    function.restype = ctypes.c_int
    fd = function(pid, 0)
    if fd < 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))
    return fd


def _pidfd_signal(fd: int, signum: int) -> None:
    libc = ctypes.CDLL(None, use_errno=True)
    try:
        function = libc.pidfd_send_signal
    except AttributeError as exc:
        raise OSError(errno.ENOSYS, "pidfd_send_signal unavailable; cannot safely terminate") from exc
    function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint]
    function.restype = ctypes.c_int
    if function(fd, signum, None, 0) < 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))


def runtime_base() -> Path:
    return Path(os.environ.get("XDG_RUNTIME_DIR", "").strip() or f"/tmp/st-browser-{os.getuid()}") / "st-browser-checks"


def process_start(pid: int, proc: Path = Path("/proc")) -> str | None:
    try:
        return (proc / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()[19]
    except (OSError, IndexError):
        return None


def record_owner(root: Path, session: str) -> None:
    start = process_start(os.getpid())
    if start is None:
        raise OSError("cannot establish isolated runtime process ownership")
    record = {"schema": _SCHEMA, "session": session, "owner_pid": os.getpid(), "owner_start": start}
    with (root / "ownership.json").open("x", encoding="utf-8") as handle:
        json.dump(record, handle)


@dataclass(frozen=True)
class Owner:
    session: str
    pid: int
    start: str


def read_owner(root: Path) -> Owner | None:
    try:
        if root.is_symlink() or root.stat().st_uid != os.getuid():
            return None
        if any((root / part).is_symlink() for part in ("ownership.json", "sockets", "profile", "config.json")):
            return None
        record = json.loads((root / "ownership.json").read_text())
        if not isinstance(record, dict) or set(record) != {"schema", "session", "owner_pid", "owner_start"}:
            return None
        session = record["session"]
        if record["schema"] != _SCHEMA or not isinstance(session, str) or not _SESSION.fullmatch(session):
            return None
        if root != runtime_base() / sha1(session.encode()).hexdigest()[:12]:
            return None
        if type(record["owner_pid"]) is not int or record["owner_pid"] < 1 or not isinstance(record["owner_start"], str):
            return None
        return Owner(session, record["owner_pid"], record["owner_start"])
    except (OSError, ValueError, TypeError):
        return None


def process_is_owned(root: Path, entry: Path, *, profile: Path | None = None) -> bool:
    try:
        if entry.stat().st_uid != os.getuid():
            return False
        args = (entry / "cmdline").read_bytes().split(b"\0")
        profile = profile if profile is not None else root / "profile"
        if os.fsencode(f"--user-data-dir={profile}") in args:
            return True
        if os.fsencode(f"--database={profile / 'Crashpad'}") in args:
            return True
        marker = os.fsencode(f"AGENT_BROWSER_SOCKET_DIR={root / 'sockets'}")
        return marker in (entry / "environ").read_bytes().split(b"\0")
    except OSError:
        return False


def owned_processes(root: Path, proc: Path = Path("/proc"), *, profile: Path | None = None) -> list[tuple[int, str]]:
    """Identify processes by exact private socket environment or Chrome profile argument."""
    owned = []
    for entry in proc.iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        start = process_start(int(entry.name), proc)
        matches = process_is_owned(root, entry) if profile is None else process_is_owned(root, entry, profile=profile)
        if start and matches:
            owned.append((int(entry.name), start))
    return sorted(owned)


def _wait_for_exit(handles: list[tuple[int, int]]) -> set[int]:
    poller = select.poll()
    waiting = {fd for _, fd in handles}
    for fd in waiting:
        poller.register(fd, select.POLLIN)
    deadline = time.monotonic() + _TERM_GRACE_MS / 1000
    while waiting and (remaining := deadline - time.monotonic()) > 0:
        for fd, _ in poller.poll(max(1, int(remaining * 1000))):
            waiting.discard(fd)
            poller.unregister(fd)
    return waiting


def terminate_owned(root: Path, session: str, *, profile: Path | None = None) -> list[str]:
    """Use pidfds and revalidate scope after opening each handle to prevent PID reuse."""
    errors = []
    handles: list[tuple[int, int]] = []
    try:
        processes = owned_processes(root) if profile is None else owned_processes(root, profile=profile)
        for pid, start in processes:
            try:
                fd = _pidfd_open(pid)
            except ProcessLookupError:
                continue
            except OSError as exc:
                errors.append(f"pid={pid}: {exc.strerror}")
                continue
            matches = process_is_owned(root, Path("/proc") / str(pid)) if profile is None else process_is_owned(root, Path("/proc") / str(pid), profile=profile)
            if process_start(pid) != start or not matches:
                os.close(fd)
                errors.append(f"pid={pid}: ownership changed")
                continue
            handles.append((pid, fd))
        for pid, fd in handles:
            try:
                _pidfd_signal(fd, signal.SIGTERM)
                print(f"BROWSER_CLEANUP:TERM|session={session}|pid={pid}")
            except ProcessLookupError:
                pass
        waiting = _wait_for_exit(handles)
        for pid, fd in handles:
            if fd not in waiting:
                continue
            try:
                _pidfd_signal(fd, signal.SIGKILL)
                print(f"BROWSER_CLEANUP:KILL|session={session}|pid={pid}")
            except ProcessLookupError:
                pass
        if waiting:
            _wait_for_exit([(pid, fd) for pid, fd in handles if fd in waiting])
    except OSError as exc:
        errors.append(str(exc))
    finally:
        for _, fd in handles:
            os.close(fd)
    remaining = owned_processes(root) if profile is None else owned_processes(root, profile=profile)
    if remaining:
        errors.append("owned processes remain: " + ",".join(str(pid) for pid, _ in remaining))
    return errors


def _runtime_identity_error(root: Path, session: str) -> str | None:
    pid_path = root / "sockets" / f"{session}.pid"
    if pid_path.exists():
        try:
            pid = int(pid_path.read_text().strip())
        except (OSError, ValueError):
            return "daemon PID is unverifiable; runtime retained"
        if process_start(pid) is not None and not process_is_owned(root, Path("/proc") / str(pid)):
            return f"pid={pid}: daemon ownership is unverifiable; runtime retained"
    return None


def finish_runtime(root: Path, session: str) -> list[str]:
    owner = read_owner(root)
    if owner is None or owner.session != session:
        return ["isolated runtime ownership is unverifiable; retained for recovery"]
    if error := _runtime_identity_error(root, session):
        return [error]
    errors = terminate_owned(root, session)
    if errors:
        return errors
    try:
        shutil.rmtree(root)
    except OSError as exc:
        return [f"isolated runtime cleanup: {exc}"]
    return []


def _recover(root: Path, owner: Owner, agent_browser_bin: str, remaining: float) -> list[str]:
    if error := _runtime_identity_error(root, owner.session):
        return [error]
    if owned_processes(root):
        config = root / "config.json"
        config.write_text("{}\n", encoding="utf-8")
        env = {k: v for k, v in os.environ.items() if not k.startswith("AGENT_BROWSER_")}
        env.update(AGENT_BROWSER_SOCKET_DIR=str(root / "sockets"), AGENT_BROWSER_CONFIG=str(config))
        try:
            subprocess.run(
                [agent_browser_bin, "--config", str(config), "--profile", str(root / "profile"),
                 "--session", owner.session, "close"],
                env=env, text=True, capture_output=True, check=False,
                timeout=min(CLOSE_TIMEOUT_SECONDS, remaining),
            )
        except (OSError, subprocess.TimeoutExpired):
            pass  # Verified owned process fallback below; no name-only killing.
    return finish_runtime(root, owner.session)


def reap_isolated(agent_browser_bin: str, *, dry_run: bool = False) -> int:
    base = runtime_base()
    counts = {"active": 0, "cleaned": 0, "unverified": 0, "incomplete": 0, "would_clean": 0, "deferred": 0}
    roots = sorted(base.iterdir()) if base.exists() else []
    deadline = time.monotonic() + _RUN_BUDGET_SECONDS
    for index, root in enumerate(roots):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            counts["deferred"] = len(roots) - index
            break
        if not root.is_dir():
            continue
        # Same contract mutex as the host; prevents overlapping recovery or a new check.
        address = f"\0st-browser-check-{os.getuid()}-{sha1(os.fsencode(root)).hexdigest()}"
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as lock:
            try:
                lock.bind(address)
            except OSError as exc:
                if exc.errno != errno.EADDRINUSE:
                    raise
                counts["active"] += 1
                continue
            owner = read_owner(root)
            if owner is None:
                counts["unverified"] += 1
                continue
            if process_start(owner.pid) == owner.start:
                counts["active"] += 1
                continue
            if dry_run:
                counts["would_clean"] += 1
                print(f"BROWSER_CLEANUP:WOULD_CLEAN|session={owner.session}|owner_pid={owner.pid}")
                continue
            try:
                errors = _recover(root, owner, agent_browser_bin, remaining)
            except OSError as exc:
                errors = [str(exc)]
            if errors:
                counts["incomplete"] += 1
                print(f"BROWSER_CLEANUP:INCOMPLETE|session={owner.session}|reason={'; '.join(errors)}")
            else:
                counts["cleaned"] += 1
                print(f"BROWSER_CLEANUP:CLEANED|session={owner.session}|owner_pid={owner.pid}")
    print("BROWSER_CLEANUP:SUMMARY|" + "|".join(f"{name}={count}" for name, count in counts.items()))
    return 2 if counts["incomplete"] or counts["deferred"] else 0
