/* Volatile user grants only: no profiles, tab enumeration, persisted authority or credentials. */
const HOST = "com.summitflow.browser_selected_tabs";
const DOMAINS = new Set([
  "Accessibility", "DOM", "DOMSnapshot", "CSS", "Runtime", "Page", "Input",
  "Emulation", "Network", "Log", "Console",
]);
const DENIED = new Set([
  "Page.close", "Page.crash", "Page.addScriptToEvaluateOnNewDocument", "Page.setBypassCSP", "Page.setDownloadBehavior",
  "Network.getCookies", "Network.getAllCookies", "Network.setCookie", "Network.setCookies",
  "Network.deleteCookies", "Network.clearBrowserCookies", "Network.clearBrowserCache",
  "Network.setCookieControls",
  "Network.getRequestPostData",
]);
let grant = null;
let changing = false;

function rendererCommand(method) {
  return new Set(["Runtime", "DOM", "DOMSnapshot", "CSS", "Accessibility", "Input", "Emulation"]).has(method.split(".")[0]) ||
    ["Page.navigate", "Page.reload", "Page.navigateToHistoryEntry", "Page.getFrameTree", "Page.getLayoutMetrics",
      "Page.captureScreenshot", "Page.captureSnapshot", "Page.printToPDF", "Page.createIsolatedWorld"].includes(method);
}

function regularOrigin(url) {
  const parsed = new URL(url);
  if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password) {
    throw new Error("Choose a regular HTTP or HTTPS tab");
  }
  return parsed.origin;
}

async function setStatus(tabId, badge, title) {
  await chrome.action.setBadgeText({ tabId, text: badge });
  await chrome.action.setTitle({ tabId, title });
}

async function revoke(reason, expected = grant) {
  if (!expected || grant !== expected) return;
  grant = null; // Authority disappears synchronously, before any awaited cleanup.
  try { expected.port.postMessage({ type: "revoke", tab_id: expected.tabId, reason }); } catch {}
  try { expected.port.disconnect(); } catch {}
  try { await chrome.debugger.detach({ tabId: expected.tabId }); } catch {}
  try { await setStatus(expected.tabId, "", "Grant automation access to this tab and origin"); } catch {}
}

async function verifiedTab(expected) {
  if (!expected || grant !== expected) throw new Error("User regrant required");
  const tab = await chrome.tabs.get(expected.tabId);
  if (grant !== expected || tab.id !== expected.tabId || regularOrigin(tab.url) !== expected.origin ||
      (tab.pendingUrl && regularOrigin(tab.pendingUrl) !== expected.origin)) {
    await revoke("origin-changed", expected);
    throw new Error("User regrant required");
  }
  return tab;
}

function commandAllowed(expected, message) {
  if (message.tab_id !== expected.tabId || message.origin !== expected.origin ||
      typeof message.request_id !== "string" || typeof message.method !== "string" ||
      !message.params || typeof message.params !== "object" || Array.isArray(message.params) ||
      !DOMAINS.has(message.method.split(".")[0]) || DENIED.has(message.method)) return false;
  if (expected.dialogOpen && rendererCommand(message.method)) return false;
  if (message.method === "Page.navigate" && regularOrigin(message.params.url) !== expected.origin) return false;
  const contextId = message.params.contextId ?? message.params.executionContextId;
  if (contextId !== undefined && expected.contexts.get(contextId) !== expected.origin) return false;
  return true;
}

async function command(expected, message) {
  try {
    await verifiedTab(expected);
    if (!commandAllowed(expected, message)) throw new Error("Unsupported selected-tab command");
    const result = await chrome.debugger.sendCommand({ tabId: expected.tabId }, message.method, message.params);
    await verifiedTab(expected);
    expected.port.postMessage({ type: "result", tab_id: expected.tabId, request_id: message.request_id, result: result ?? {} });
  } catch {
    if (grant === expected) {
      try { expected.port.postMessage({ type: "result", tab_id: expected.tabId, request_id: message.request_id,
        error: "Selected-tab command unavailable or unsupported" }); } catch { await revoke("native-disconnected", expected); }
    }
  }
}

chrome.action.onClicked.addListener(async (tab) => {
  if (changing) return;
  changing = true;
  try {
    if (grant?.tabId === tab.id) { await revoke("user-revoked"); return; }
    if (grant) await revoke("user-selected-another-tab");
    const allowedOrigin = regularOrigin(tab.url);
    if (!Number.isInteger(tab.id) || tab.incognito) throw new Error("Choose a regular Chrome tab");
    await chrome.debugger.attach({ tabId: tab.id }, "1.3");
    const port = chrome.runtime.connectNative(HOST);
    const expected = { tabId: tab.id, origin: allowedOrigin, port, contexts: new Map(), started: false, dialogOpen: false };
    grant = expected;
    port.onDisconnect.addListener(() => { void revoke("native-disconnected", expected); });
    port.onMessage.addListener((message) => {
      if (grant !== expected) return;
      if (message.type === "command") void command(expected, message);
      else if (message.type === "revoke") void revoke("native-revoked", expected);
      else if (message.type === "ready" && message.tab_id === expected.tabId && message.origin === expected.origin) {
        void setStatus(expected.tabId, "ON", `Automation granted for ${expected.origin}. Click to revoke.`);
      } else void revoke("invalid-native-message", expected);
    });
    const current = await verifiedTab(expected);
    // Enable navigation events immediately, even before an agent connects.
    await chrome.debugger.sendCommand({ tabId: expected.tabId }, "Page.enable");
    port.postMessage({ type: "grant", tab_id: expected.tabId, origin: expected.origin,
      url: current.url, title: current.title ?? "" });
    expected.started = true;
  } catch {
    await revoke("grant-failed");
    if (Number.isInteger(tab.id)) {
      // If connectNative failed after attach but before grant construction, detach our exact tab.
      try { await chrome.debugger.detach({ tabId: tab.id }); } catch {}
      try { await setStatus(tab.id, "!", "Grant unavailable. Check native host setup and choose a regular tab."); } catch {}
    }
  } finally { changing = false; }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (grant?.tabId === tabId) void revoke("tab-closed");
});
chrome.tabs.onReplaced.addListener((addedTabId, removedTabId) => {
  if (grant?.tabId === removedTabId) void revoke("tab-replaced");
});
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (grant?.tabId !== tabId || !change.url) return;
  try { if (regularOrigin(change.url) !== grant.origin) void revoke("origin-changed"); }
  catch { void revoke("origin-changed"); }
});
chrome.webNavigation.onBeforeNavigate.addListener((event) => {
  if (grant?.tabId !== event.tabId || event.frameId !== 0) return;
  try { if (regularOrigin(event.url) !== grant.origin) void revoke("origin-navigation"); }
  catch { void revoke("origin-navigation"); }
});
chrome.debugger.onDetach.addListener((source) => {
  if (grant?.tabId === source.tabId) void revoke("debugger-detached");
});

function redactNetwork(params) {
  const copy = structuredClone(params);
  const redact = (headers) => {
    if (!headers) return;
    for (const name of Object.keys(headers)) {
      if (/^(cookie|set-cookie|authorization|proxy-authorization)$/i.test(name)) delete headers[name];
    }
  };
  redact(copy.headers);
  redact(copy.request?.headers);
  redact(copy.response?.headers);
  // Native messaging never transfers request bodies or cookie credential records.
  if (copy.request) { delete copy.request.postData; delete copy.request.postDataEntries; }
  delete copy.associatedCookies;
  delete copy.blockedCookies;
  delete copy.exemptedCookies;
  delete copy.headersText;
  delete copy.requestHeadersText;
  if (copy.request) delete copy.request.headersText;
  if (copy.response) delete copy.response.headersText;
  return copy;
}

chrome.debugger.onEvent.addListener((source, method, params) => {
  const expected = grant;
  if (!expected || source.tabId !== expected.tabId || source.sessionId) return;
  if (method === "Page.javascriptDialogOpening") {
    try {
      if (!["alert", "confirm", "prompt", "beforeunload"].includes(params.type) || regularOrigin(params.url) !== expected.origin) {
        void revoke("invalid-dialog", expected); return;
      }
    } catch { void revoke("invalid-dialog", expected); return; }
    expected.dialogOpen = true;
  } else if (method === "Page.javascriptDialogClosed") expected.dialogOpen = false;
  if (method === "Page.frameNavigated" && !params.frame.parentId) {
    try { if (regularOrigin(params.frame.url) !== expected.origin) { void revoke("origin-changed", expected); return; } }
    catch { void revoke("origin-changed", expected); return; }
  }
  if (method === "Runtime.executionContextCreated") {
    expected.contexts.set(params.context.id, params.context.origin);
  } else if (method === "Runtime.executionContextDestroyed") expected.contexts.delete(params.executionContextId);
  else if (method === "Runtime.executionContextsCleared") expected.contexts.clear();
  if (!expected.started) return;
  try { expected.port.postMessage({ type: "event", tab_id: expected.tabId, method,
    params: method.startsWith("Network.") ? redactNetwork(params) : params }); }
  catch { void revoke("native-disconnected", expected); }
});
