"""Verified value assignment for native controls the core fill command misses."""
from __future__ import annotations

import json
from string import Template

HELP = '''st browser step set-value <CSS|label=exact-label> <value>

Set a native input, textarea, select, or contenteditable value and dispatch input
and change events. The target must be unique and visible. Invalid native values
fail rather than acknowledging an empty value. Password fields require human input.
Use ISO values for date/time controls, e.g. 2026-10-16 for an input[type=date].
The operation works in the currently selected frame; bind the run to an observation.
'''


def command(action: list[str]) -> list[str]:
    if action[0] == 'vitals':
        if len(action) != 1:
            raise ValueError('vitals takes no arguments')
        return ['eval', '''JSON.stringify((()=>{const nav=performance.getEntriesByType('navigation')[0];return {source:'current-document Performance API',navigation:nav?{duration_ms:nav.duration,ttfb_ms:nav.responseStart-nav.requestStart,dom_content_loaded_ms:nav.domContentLoadedEventEnd,load_ms:nav.loadEventEnd,transfer_bytes:nav.transferSize}:null,paint:performance.getEntriesByType('paint').map(e=>({name:e.name,start_ms:e.startTime})),resource_count:performance.getEntriesByType('resource').length,web_vitals:{lcp:null,cls:null,inp:null},limitations:'LCP, CLS and INP require lifecycle observers and are not collected by this snapshot'}})())''']
    if action[0] != 'set-value':
        return action
    if len(action)!=3 or not action[1]:
        raise ValueError('set-value requires one CSS/label selector and a value')
    selector,value = action[1:]
    script = Template('''JSON.stringify((()=>{const selector=$SELECTOR,value=$VALUE;
const nodes=selector.startsWith('label=')?[...document.querySelectorAll('label')].filter(e=>e.textContent.trim()===selector.slice(6)).map(e=>e.control).filter(Boolean):[...document.querySelectorAll(selector)];
if(nodes.length!==1||!nodes[0].getClientRects().length)throw new Error('set-value needs one visible control');
const e=nodes[0];if(e.type==='password'||/password|one-time-code/.test(e.autocomplete||''))throw new Error('Sensitive fields require human input');
if(e.isContentEditable)e.textContent=value;
else {const setter=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e),'value')?.set;if(!setter)throw new Error('Unsupported native control');const probe=e.cloneNode(true);setter.call(probe,value);if(probe.value!==value)throw new Error('Native control rejected the requested value');setter.call(e,value);}
e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));
const actual=e.isContentEditable?e.textContent:e.value;if(actual!==value)throw new Error('Native control rejected the requested value');
return {verified:true,selector,type:e.type||e.tagName.toLowerCase()};})())''').substitute(SELECTOR=json.dumps(selector),VALUE=json.dumps(value))
    return ['eval',script]
