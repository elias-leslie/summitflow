"""Browser process and CDP data plane for fully resolved requests."""

from __future__ import annotations

import shutil
import subprocess
import time
from importlib.resources import files
from pathlib import Path

from st_sdk.details import display_path, emit_result_or_details, summary_hint, write_details
from st_sdk.output import output_error, output_warning

from .contract import BrowserRequest, Check
from .support import (
    browser_page_target_ids,
    close_blank_browser_targets,
    close_browser_targets,
    http_json,
    json_from_agent_eval,
    parse_agent_console,
)

_NAVIGATION_COMMANDS = {"open", "goto", "navigate"}
_ENGINE_PORTS = {"chrome": 9222, "lightpanda": 9223}
_minimized = False


def run_agent_compat(
    *,
    agent_browser_bin: str,
    prefix: list[str],
    args: list[str],
    window_mode: str,
    default_launch: bool,
    minimize: bool,
    window_class: str,
) -> subprocess.CompletedProcess[str]:
    """Public compatibility hook for post-import SummitFlow helper callers."""
    request = BrowserRequest.from_mapping(
        {
            "contract_version": 1,
            "operation": "agent",
            "target": "local-ai",
            "command": "compat",
            "args": args,
            "root": str(Path.cwd()),
            "endpoint": None,
            "launch": {
                "agent_browser_bin": agent_browser_bin,
                "prefix": prefix,
                "window_mode": window_mode,
                "default_launch": default_launch,
                "minimize": minimize,
                "window_class": window_class,
            },
            "check": None,
            "default_viewport": None,
            "reaper": None,
        }
    )
    result = _run_agent(request, args)
    _maybe_warn_visible(request, result)
    result = _without_default_daemon_warning(result, default_launch=default_launch)
    _maybe_minimize(request)
    return result


def _run_agent(request: BrowserRequest, args: list[str], *, capture: bool = True) -> subprocess.CompletedProcess[str]:
    argv = [request.launch.agent_browser_bin]
    if request.target == "proxmox":
        assert request.endpoint is not None
        argv.extend(["--cdp", request.endpoint.ws])
    else:
        argv.extend(request.launch.prefix)
    argv.extend(args)
    return subprocess.run(argv, text=True, capture_output=capture, check=False)


def _run_reaper(request: BrowserRequest) -> None:
    if not request.reaper:
        return
    reaper = (
        str(files("browser_automation").joinpath("assets/agent-browser-idle-reaper.js"))
        if request.reaper == "bundled"
        else request.reaper
    )
    if Path(reaper).is_file():
        subprocess.run(["node", reaper], text=True, capture_output=True, check=False)


def _is_default_daemon_warning(line: str) -> bool:
    stripped = line.strip()
    return stripped.startswith("⚠ ") and "ignored: daemon already running" in stripped


def _without_default_daemon_warning(
    result: subprocess.CompletedProcess[str], *, default_launch: bool
) -> subprocess.CompletedProcess[str]:
    if not default_launch:
        return result

    def clean(output: str | None) -> str:
        if not output:
            return ""
        lines = [line for line in output.splitlines() if not _is_default_daemon_warning(line)]
        return "\n".join(lines) + ("\n" if lines and output.endswith("\n") else "")

    return subprocess.CompletedProcess(result.args, result.returncode, clean(result.stdout), clean(result.stderr))


def _maybe_warn_visible(request: BrowserRequest, result: subprocess.CompletedProcess[str]) -> None:
    output = "\n".join(part for part in (result.stdout, result.stderr) if part)
    if request.launch.window_mode == "visible" and "ignored: daemon already running" in output:
        output_warning(
            "visible window mode requested but a browser daemon is already running in another mode — "
            "no on-screen window will appear. Run `st browser close` to stop it, then retry."
        )


def _maybe_minimize(request: BrowserRequest) -> None:
    global _minimized
    if _minimized or not request.launch.minimize or not request.launch.window_class or not shutil.which("xdotool"):
        return
    try:
        found = subprocess.run(
            ["xdotool", "search", "--class", request.launch.window_class],
            text=True,
            capture_output=True,
            timeout=5,
            check=False,
        )
        for window_id in found.stdout.split():
            subprocess.run(
                ["xdotool", "windowminimize", window_id],
                text=True,
                capture_output=True,
                timeout=5,
                check=False,
            )
        _minimized = bool(found.stdout.split())
    except (OSError, subprocess.SubprocessError):
        return


def _agent_failure(label: str, result: subprocess.CompletedProcess[str]) -> str | None:
    if result.returncode == 0:
        return None
    output = "\n".join(part for part in (result.stdout, result.stderr) if part)
    return f"{label}: rc={result.returncode} hint={summary_hint(output) if output else '-'}"


def _check_items(value: dict[str, object] | list[object], key: str) -> list[object]:
    if not isinstance(value, dict):
        return []
    items = value.get(key)
    return list(items) if isinstance(items, list) else []


def _execute_check(request: BrowserRequest, check: Check) -> int:
    session_args = ["--session", check.session]
    endpoint = request.endpoint
    baseline = browser_page_target_ids(endpoint.host, endpoint.port) if endpoint else None
    command_warnings: list[str] = []
    page_result = subprocess.CompletedProcess([], 0, stdout="{}", stderr="")
    console_result = subprocess.CompletedProcess([], 0, stdout="", stderr="")
    network_result = subprocess.CompletedProcess([], 0, stdout="[]", stderr="")

    def run(
        label: str,
        args: list[str],
        *,
        retry_startup_socket: bool = False,
    ) -> subprocess.CompletedProcess[str]:
        result = _run_agent(request, [*session_args, *args])
        result = _without_default_daemon_warning(result, default_launch=request.launch.default_launch)
        output = "\n".join(part for part in (result.stdout, result.stderr) if part)
        if (
            retry_startup_socket
            and request.target == "local-ai"
            and result.returncode != 0
            and "Failed to connect: No such file or directory" in output
        ):
            time.sleep(0.5)
            result = _run_agent(request, [*session_args, *args])
            result = _without_default_daemon_warning(result, default_launch=request.launch.default_launch)
        if warning := _agent_failure(label, result):
            command_warnings.append(warning)
        return result

    try:
        first = check.viewports[0]
        run("initial viewport", ["set", "viewport", str(first.width), str(first.height)])
        run("console clear", ["console", "--clear"], retry_startup_socket=True)
        opened = run("open", ["open", check.url])
        if opened.returncode != 0:
            output_error(command_warnings[-1])
            return opened.returncode
        run("load wait", ["wait", "--load", "networkidle"])
        run("settle wait", ["wait", check.settle_ms])
        for viewport in check.viewports:
            run(f"{viewport.label} viewport", ["set", "viewport", str(viewport.width), str(viewport.height)])
            run(f"{viewport.label} wait", ["wait", check.viewport_settle_ms])
            run(f"{viewport.label} screenshot", ["screenshot", viewport.path])
        console_result = run("console read", ["console"])
        page_result = run("page read", ["eval", "JSON.stringify({url:location.href,title:document.title})"])
        network_result = run(
            "network read",
            [
                "eval",
                "JSON.stringify(performance.getEntriesByType('resource').filter(e=>e.responseStatus>=400).map(e=>e.responseStatus+' '+e.name.split('/').pop()))",
            ],
        )
    finally:
        run("close", ["close"])
        _run_reaper(request)
        if endpoint:
            remaining = browser_page_target_ids(endpoint.host, endpoint.port)
            if baseline is not None and remaining is not None:
                close_browser_targets(endpoint.host, endpoint.port, remaining - baseline)

    page = json_from_agent_eval(page_result.stdout)
    console_errors, console_warnings = parse_agent_console(
        "\n".join(part for part in (console_result.stdout, console_result.stderr) if part)
    )
    errors: dict[str, object] = {
        **(page if isinstance(page, dict) else {}),
        "errors": console_errors,
        "warnings": console_warnings,
    }
    network = json_from_agent_eval(network_result.stdout)
    error_items = _check_items(errors, "errors")
    warning_items = _check_items(errors, "warnings")
    network_items = list(network) if isinstance(network, list) else []
    detail_lines = [
        *( [f"Target: {request.target}"] if request.target == "local-ai" else []),
        f"Screenshot: {display_path(request.root, Path(check.screenshot_path))}",
        "Responsive set: " + ", ".join(f"{v.label} {v.width}x{v.height}" for v in check.viewports),
    ]
    if len(check.viewports) > 1:
        detail_lines.append("Additional screenshots:")
        detail_lines.extend(
            f"  {v.label}: {display_path(request.root, Path(v.path))}" for v in check.viewports[1:]
        )
    detail_lines.extend([f"Page: {errors.get('url', 'unknown')}", f"Title: {errors.get('title', 'unknown')}"])
    for heading, items in (
        ("Console errors", error_items),
        ("Console warnings", warning_items),
        ("Failed network requests", network_items),
        ("Browser command warnings", command_warnings),
    ):
        if items:
            detail_lines.append(f"\n{heading} ({len(items)}):")
            detail_lines.extend(str(item) for item in items)
    name = "browser-check-local-ai" if request.target == "local-ai" else "browser-check"
    details = write_details(request.root, name, "\n".join(detail_lines))
    status = "INCOMPLETE" if command_warnings else "OK" if not error_items and not warning_items and not network_items else "ISSUES"
    target = "|target=local-ai" if request.target == "local-ai" else ""
    print(
        f"BROWSER_CHECK:{status}{target}|errors={len(error_items)}|warnings={len(warning_items)}|"
        f"network={len(network_items)}|command_warnings={len(command_warnings)}|"
        f"screenshot={display_path(request.root, Path(check.screenshot_path)) if request.target == 'local-ai' else check.screenshot_path}|"
        f"details:{display_path(request.root, details)}"
    )
    if command_warnings:
        return 2
    return 1 if error_items or warning_items or network_items else 0


def _execute_health(request: BrowserRequest) -> int:
    if request.target == "local-ai":
        prefix = list(request.launch.prefix)
        profile = prefix[prefix.index("--profile") + 1] if "--profile" in prefix else "AI"
        executable = prefix[prefix.index("--executable-path") + 1] if "--executable-path" in prefix else "not found"
        session = request.args[request.args.index("--session") + 1] if "--session" in request.args else "unknown"
        print("Target: local system Chrome (AI profile)")
        print(f"chrome: {executable}")
        print(f"profile: {profile}")
        print(f"session: {session} (singleton)")
        print(f"window-mode: {request.launch.window_mode}")
        if request.launch.window_mode == "minimized":
            print("window-behavior: starts minimized/iconified; restore the st-browser-ai window from the taskbar to watch")
        if request.launch.window_mode == "headless":
            print("window-behavior: no desktop window; hardware GL required; software rasterizer disabled")
        print(f"agent-browser-bin: {request.launch.agent_browser_bin}")
        return 0
    assert request.endpoint is not None
    marker = "; debug-local" if request.endpoint.debug_local else ""
    print(f"Target: {request.endpoint.host} ({request.endpoint.source}{marker})")
    print(f"{'ENGINE':<12} {'PORT':<6} {'STATUS':<6} DETAILS")
    for engine, port in _ENGINE_PORTS.items():
        payload = http_json(f"http://{request.endpoint.host}:{port}/json/version")
        detail = str(payload.get("Browser") or payload.get("webSocketDebuggerUrl") or "-") if isinstance(payload, dict) else "-"
        print(f"{engine:<12} {port:<6} {'UP' if isinstance(payload, dict) else 'DOWN':<6} {detail}")
    return 0


def _execute_update(request: BrowserRequest) -> int:
    current = subprocess.run(
        [request.launch.agent_browser_bin, "--version"], text=True, capture_output=True, check=False
    ).stdout.strip() or "unknown"
    latest = subprocess.run(["npm", "view", "agent-browser", "version"], text=True, capture_output=True, check=False)
    print(f"agent-browser: installed={current} latest={latest.stdout.strip() or '?'}")
    if request.endpoint:
        print("Runtime:")
        print(f"  host: {request.endpoint.host}")
        print(f"  source: {request.endpoint.source}")
        print(f"  debug_local: {request.endpoint.debug_local}")
    print(f"  agent-browser-bin: {request.launch.agent_browser_bin}")
    return 0


def _execute_agent(request: BrowserRequest) -> int:
    if request.target == "proxmox" and request.command == "open" and request.default_viewport:
        session = list(request.args[:2]) if request.args[:1] == ("--session",) else []
        _run_agent(
            request,
            [*session, "set", "viewport", request.default_viewport.width, request.default_viewport.height],
        )
    result = _run_agent(request, list(request.args))
    if request.target == "local-ai":
        _maybe_warn_visible(request, result)
        result = _without_default_daemon_warning(result, default_launch=request.launch.default_launch)
        _maybe_minimize(request)
    name = f"browser-local-ai-{request.command or 'command'}" if request.target == "local-ai" else f"browser-{request.command or 'command'}"
    emit_result_or_details(request.root, name, "BROWSER", result)
    if request.target == "proxmox":
        _run_reaper(request)
        if request.command not in _NAVIGATION_COMMANDS and request.endpoint:
            close_blank_browser_targets(request.endpoint.host, request.endpoint.port)
    return result.returncode


def execute(request: BrowserRequest) -> int:
    if request.operation == "health":
        return _execute_health(request)
    if request.operation == "update":
        return _execute_update(request)
    if request.operation == "check":
        assert request.check is not None
        return _execute_check(request, request.check)
    return _execute_agent(request)
