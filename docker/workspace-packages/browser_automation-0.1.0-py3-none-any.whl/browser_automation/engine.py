"""Browser process and CDP data plane for fully resolved requests."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
import zlib
from dataclasses import asdict, replace
from importlib.resources import files
from pathlib import Path
from typing import cast
from urllib.parse import urlsplit, urlunsplit
from uuid import uuid4

from st_sdk.details import display_path, emit_result_or_details, summary_hint, write_details
from st_sdk.output import output_error, output_warning

from .contract import BrowserRequest, Check, Endpoint
from .inventory import inventory
from .ownership import CLOSE_TIMEOUT_SECONDS, finish_runtime, reap_isolated, record_owner
from .support import (
    http_json,
    json_from_agent_eval,
    parse_agent_console,
)

_ENGINE_PORTS = {"chrome": 9222}
_SESSION_NAME = re.compile(r"^[A-Za-z0-9_-]+$")
_READINESS_JS = """JSON.stringify((()=>{
  /* __ST_RENDER_READINESS__ */
  const visible=e=>e.getClientRects().length>0 && getComputedStyle(e).visibility!=='hidden';
  const selectors='[aria-busy="true"],[role="progressbar"],[data-loading="true"],[class*="skeleton" i]';
  const marked=Array.from(document.querySelectorAll(selectors)).filter(visible);
  const pulses=Array.from(document.querySelectorAll('[class*="animate-pulse" i]')).filter(e=>{
    const box=e.getBoundingClientRect();
    return visible(e) && box.width>=80 && box.height>=24 && !(e.textContent||'').trim();
  });
  const loading=Array.from(document.querySelectorAll('body *')).filter(e=>
    e.children.length===0 && visible(e) &&
    /^(loading|fetching|preparing|please wait)(?:\\b|[.…])/i.test((e.textContent||'').trim()));
  const indicators=[...new Set([...marked,...pulses,...loading].map(e=>(e.textContent||e.getAttribute('aria-label')||e.getAttribute('class')||e.tagName).toString().trim().slice(0,100)))];
  return {readyState:document.readyState,body:!!document.body,indicators:indicators.slice(0,10)};
})())"""
_minimized = False


def run_agent_compat(
    *,
    agent_browser_bin: str,
    prefix: list[str],
    args: list[str],
    window_mode: str,
    default_launch: bool,
    minimize: bool,
    window_class: str,
) -> subprocess.CompletedProcess[str]:
    """Public compatibility hook for post-import SummitFlow helper callers."""
    request = BrowserRequest.from_mapping(
        {
            "contract_version": 1,
            "operation": "agent",
            "target": "local-ai",
            "command": "compat",
            "args": args,
            "root": str(Path.cwd()),
            "endpoint": None,
            "launch": {
                "agent_browser_bin": agent_browser_bin,
                "prefix": prefix,
                "window_mode": window_mode,
                "default_launch": default_launch,
                "minimize": minimize,
                "window_class": window_class,
            },
            "check": None,
            "default_viewport": None,
            "reaper": None,
        }
    )
    result = _run_agent(request, args)
    _maybe_warn_visible(request, result)
    result = _without_default_daemon_warning(result, default_launch=default_launch)
    _maybe_minimize(request)
    return result


def _run_agent(request: BrowserRequest, args: list[str], *, capture: bool = True, input_data: str | None = None) -> subprocess.CompletedProcess[str]:
    if request.launch.daemon_session and "--session" in args:
        args = list(args)
        args[args.index("--session") + 1] = request.launch.daemon_session
    argv = [request.launch.agent_browser_bin]
    if request.target == "proxmox":
        assert request.endpoint is not None
        argv.extend(["--cdp", request.endpoint.ws])
    else:
        argv.extend(request.launch.prefix)
    argv.extend(args)
    env = None
    if request.launch.isolation_root is not None:
        root = request.launch.isolation_root
        root.mkdir(parents=True, exist_ok=True, mode=0o700)
        (root / "sockets").mkdir(exist_ok=True, mode=0o700)
        if request.launch.selected_tab is not None:
            from .selected_execution import validate_private_config

            config = validate_private_config(request)
        else:
            config = root / "config.json"
            config.write_text("{}\n", encoding="utf-8")
        # Do not inherit a profile, remote connection, config, or session from another agent.
        env = {key: value for key, value in os.environ.items() if not key.startswith("AGENT_BROWSER_")}
        env.update(AGENT_BROWSER_SOCKET_DIR=str(root / "sockets"), AGENT_BROWSER_CONFIG=str(config))
        argv[1:1] = ["--config", str(config)]
    try:
        if env is not None:
            return subprocess.run(
                argv, text=True, capture_output=capture, check=False, env=env,
                timeout=CLOSE_TIMEOUT_SECONDS if args[-1:] == ["close"] else None,
                input=input_data,
            )
        return subprocess.run(argv, text=True, capture_output=capture, check=False, input=input_data)
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(argv, 124, stdout="", stderr="isolated close exceeded the 30-second CLI IPC timeout")
    except OSError as exc:
        return subprocess.CompletedProcess(argv, 127, stdout="", stderr=f"browser executable unavailable: {exc.strerror}")


def _run_reaper(request: BrowserRequest, session: str | None) -> None:
    if not request.reaper or not session or not _SESSION_NAME.fullmatch(session):
        return
    reaper = (
        str(files("browser_automation").joinpath("assets/agent-browser-idle-reaper.js"))
        if request.reaper == "bundled"
        else request.reaper
    )
    if Path(reaper).is_file():
        subprocess.run(["node", reaper, "--session", session], text=True, capture_output=True, check=False)


def _is_default_daemon_warning(line: str) -> bool:
    stripped = line.strip()
    return stripped.startswith("⚠ ") and "ignored: daemon already running" in stripped


def _without_default_daemon_warning(
    result: subprocess.CompletedProcess[str], *, default_launch: bool
) -> subprocess.CompletedProcess[str]:
    if not default_launch:
        return result

    def clean(output: str | None) -> str:
        if not output:
            return ""
        lines = [line for line in output.splitlines() if not _is_default_daemon_warning(line)]
        return "\n".join(lines) + ("\n" if lines and output.endswith("\n") else "")

    return subprocess.CompletedProcess(result.args, result.returncode, clean(result.stdout), clean(result.stderr))


def _maybe_warn_visible(request: BrowserRequest, result: subprocess.CompletedProcess[str]) -> None:
    output = "\n".join(part for part in (result.stdout, result.stderr) if part)
    if request.launch.window_mode == "visible" and "ignored: daemon already running" in output:
        output_warning(
            "visible window mode requested but a browser daemon is already running in another mode — "
            "no on-screen window will appear. Run `st browser close` to stop it, then retry."
        )


def _maybe_minimize(request: BrowserRequest) -> None:
    global _minimized
    if _minimized or not request.launch.minimize or not request.launch.window_class or not shutil.which("xdotool"):
        return
    try:
        found = subprocess.run(
            ["xdotool", "search", "--class", request.launch.window_class],
            text=True,
            capture_output=True,
            timeout=5,
            check=False,
        )
        for window_id in found.stdout.split():
            subprocess.run(
                ["xdotool", "windowminimize", window_id],
                text=True,
                capture_output=True,
                timeout=5,
                check=False,
            )
        _minimized = bool(found.stdout.split())
    except (OSError, subprocess.SubprocessError):
        return


def _agent_failure(label: str, result: subprocess.CompletedProcess[str]) -> str | None:
    if result.returncode == 0:
        return None
    output = "\n".join(part for part in (result.stdout, result.stderr) if part)
    return f"{label}: rc={result.returncode} hint={summary_hint(output) if output else '-'}"


def _check_items(value: dict[str, object] | list[object], key: str) -> list[object]:
    if not isinstance(value, dict):
        return []
    items = value.get(key)
    return list(items) if isinstance(items, list) else []


def _agent_data(result: subprocess.CompletedProcess[str], key: str) -> list[object] | None:
    if result.returncode != 0:
        return None
    try:
        payload = json.loads(result.stdout.strip())
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(payload, dict) or payload.get("success") is not True:
        return None
    data = payload.get("data")
    items = data.get(key) if isinstance(data, dict) else None
    return items if isinstance(items, list) else None


def _network_findings(requests: list[object]) -> tuple[list[str], list[str]]:
    failures: list[str] = []
    unknown: list[str] = []
    for item in requests:
        if not isinstance(item, dict):
            continue
        item = cast(dict[str, object], item)
        status = item.get("status")
        failed = item.get("error") or item.get("failure")
        raw_url = str(item.get("url") or "")
        parts = urlsplit(raw_url)
        safe_url = urlunsplit((parts.scheme, parts.netloc.rsplit("@", 1)[-1], parts.path, "", ""))
        label = f"{item.get('method', '?')} {safe_url}"
        if (isinstance(status, int) and (status == 0 or status >= 400)) or failed:
            failures.append(f"{label} status={status if status is not None else '?'}")
        elif status is None and item.get("resourceType") not in {"WebSocket", "EventSource"}:
            unknown.append(f"{label} response unavailable")
    return failures, unknown


def _page_error_text(item: object) -> str:
    if isinstance(item, dict):
        data = cast(dict[str, object], item)
        return str(data.get("text") or data.get("message") or data)
    return str(item)


def _screenshot_stamp(path: str) -> tuple[int, int, int] | None:
    try:
        stat = Path(path).stat()
    except OSError:
        return None
    return stat.st_ino, stat.st_mtime_ns, stat.st_size


def _screenshot_complete(path: str, previous: tuple[int, int, int] | None) -> bool:
    current = _screenshot_stamp(path)
    if current is None or current == previous or current[2] < 16:
        return False
    try:
        data = Path(path).read_bytes()
    except OSError:
        return False
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        offset = 8
        saw_header = saw_image = False
        while offset + 12 <= len(data):
            length = int.from_bytes(data[offset : offset + 4], "big")
            end = offset + 12 + length
            if end > len(data):
                return False
            kind = data[offset + 4 : offset + 8]
            body = data[offset + 8 : offset + 8 + length]
            expected_crc = int.from_bytes(data[end - 4 : end], "big")
            if zlib.crc32(kind + body) != expected_crc:
                return False
            if kind == b"IHDR":
                saw_header = length == 13 and offset == 8
            elif kind == b"IDAT":
                saw_image = True
            elif kind == b"IEND":
                return saw_header and saw_image and length == 0 and end == len(data)
            offset = end
        return False
    if data.startswith(b"\xff\xd8"):
        return data.endswith(b"\xff\xd9")
    return False


def _fresh_screenshot_path(path: str) -> str:
    """Reserve a destination atomically so concurrent checks never overwrite each other."""
    target = Path(path)
    candidate = target
    while True:
        try:
            with candidate.open("xb"):
                pass
            return str(candidate)
        except FileExistsError:
            candidate = target.with_name(f"{target.stem}-{uuid4().hex[:12]}{target.suffix}")


def _execute_check(request: BrowserRequest, check: Check) -> int:
    if request.launch.isolation_root is not None:
        root = request.launch.isolation_root
        try:
            root.parent.mkdir(parents=True, exist_ok=True)
            root.mkdir(mode=0o700)
        except FileExistsError:
            output_error(f"Isolated check runtime already exists: {root}; recover that session before reusing its name")
            print("BROWSER_CHECK:INCOMPLETE|target=local-ai|cleanup=runtime-already-exists")
            return 2
        except OSError as exc:
            output_error(f"Unable to create isolated check runtime: {exc}")
            return 2
        try:
            record_owner(root, check.session)
        except OSError as exc:
            # No browser command has run yet, so this newly-created root is ours alone.
            try:
                shutil.rmtree(root)
            except OSError as cleanup_error:
                output_error(f"Pre-launch cleanup incomplete; runtime retained at {root}: {cleanup_error}")
            output_error(f"Unable to record isolated runtime ownership: {exc}")
            return 2
    session_args = ["--session", check.session]
    command_warnings: list[str] = []
    page_result = subprocess.CompletedProcess([], 1, stdout="", stderr="")
    console_result = subprocess.CompletedProcess([], 0, stdout="", stderr="")
    errors_result = subprocess.CompletedProcess([], 1, stdout="", stderr="")
    network_result = subprocess.CompletedProcess([], 1, stdout="", stderr="")
    screenshot_paths: dict[str, str] = {}
    readiness = "unavailable"
    readiness_indicators: list[str] = []

    def run(
        label: str,
        args: list[str],
        *,
        retry_startup_socket: bool = False,
    ) -> subprocess.CompletedProcess[str]:
        result = _run_agent(request, [*session_args, *args])
        result = _without_default_daemon_warning(result, default_launch=request.launch.default_launch)
        output = "\n".join(part for part in (result.stdout, result.stderr) if part)
        if (
            retry_startup_socket
            and request.target == "local-ai"
            and result.returncode != 0
            and "Failed to connect: No such file or directory" in output
        ):
            time.sleep(0.5)
            result = _run_agent(request, [*session_args, *args])
            result = _without_default_daemon_warning(result, default_launch=request.launch.default_launch)
        if warning := _agent_failure(label, result):
            command_warnings.append(warning)
        return result

    try:
        first = check.viewports[0]
        run("initial viewport", ["set", "viewport", str(first.width), str(first.height)])
        run(
            "evidence clear",
            ["batch", "--bail", "console --clear", "errors --clear", "network requests --clear"],
            retry_startup_socket=True,
        )
        opened = run("open", ["open", check.url])
        if opened.returncode != 0:
            output_error(command_warnings[-1])
            return opened.returncode
        run("load wait", ["wait", "--load", "networkidle"])
        run("settle wait", ["wait", check.settle_ms])
        viewport_readiness: dict[str, str] = {}
        for index, viewport in enumerate(check.viewports):
            if index:
                run(f"{viewport.label} viewport", ["set", "viewport", str(viewport.width), str(viewport.height)])
                run(f"{viewport.label} wait", ["wait", check.viewport_settle_ms])
            current_readiness = "unavailable"
            for attempt in range(6):
                probe = run(f"{viewport.label} render readiness probe", ["eval", _READINESS_JS])
                evidence = json_from_agent_eval(probe.stdout)
                if (
                    probe.returncode != 0
                    or not isinstance(evidence, dict)
                    or not isinstance(evidence.get("indicators"), list)
                    or not isinstance(evidence.get("readyState"), str)
                ):
                    break
                readiness_indicators = [str(item) for item in cast(list[object], evidence["indicators"])]
                current_readiness = "ready" if evidence["readyState"] == "complete" and evidence.get("body") is True and not readiness_indicators else "pending"
                if current_readiness == "ready":
                    break
                if attempt < 5:
                    run(f"{viewport.label} render readiness wait", ["wait", "1000"])
            viewport_readiness[viewport.label] = current_readiness
            if current_readiness != "ready":
                command_warnings.append(f"{viewport.label} render readiness: {current_readiness}")
            readiness = "ready" if all(state == "ready" for state in viewport_readiness.values()) else current_readiness if current_readiness != "ready" else "pending"
            destination = _fresh_screenshot_path(viewport.path)
            previous = _screenshot_stamp(destination)
            image_result = run(f"{viewport.label} screenshot", ["screenshot", destination])
            if image_result.returncode == 0 and _screenshot_complete(destination, previous):
                screenshot_paths[viewport.label] = destination
            else:
                # The path was reserved by this check; never leave an empty or partial image.
                Path(destination).unlink(missing_ok=True)
                if image_result.returncode == 0:
                    command_warnings.append(f"{viewport.label} screenshot: completed image unavailable")
        console_result = run("console read", ["console"])
        errors_result = run("page errors read", ["errors", "--json"])
        page_result = run("page read", ["eval", "JSON.stringify({url:location.href,title:document.title})"])
        network_result = run("network read", ["network", "requests", "--json"])
    finally:
        closed = run("close", ["close"])
        _run_reaper(request, check.session)
        if request.launch.isolation_root is not None:
            cleanup_errors = finish_runtime(request.launch.isolation_root, check.session)
            for warning in cleanup_errors:
                command_warnings.append(warning)
                output_error(warning)
            if closed.returncode != 0:
                state = "runtime retained" if cleanup_errors else "owned runtime recovered"
                output_error(f"Isolated browser cleanup: close failed; {state}")

    page = json_from_agent_eval(page_result.stdout)
    console_errors, console_warnings = parse_agent_console(
        "\n".join(part for part in (console_result.stdout, console_result.stderr) if part)
    )
    page_errors = _agent_data(errors_result, "errors")
    network = _agent_data(network_result, "requests")
    if page_errors is None:
        command_warnings.append("page errors: evidence unavailable")
    if network is None:
        command_warnings.append("network requests: evidence unavailable")
    if not isinstance(page, dict) or not isinstance(page.get("url"), str) or not isinstance(page.get("title"), str):
        command_warnings.append("page identity: evidence unavailable")
        page = {}
    elif isinstance(page["url"], str) and page["url"].startswith(("chrome-error://", "about:blank")):
        command_warnings.append("navigation: browser error page or blank page")
    formatted_page_errors = [_page_error_text(item) for item in page_errors or []]
    errors: dict[str, object] = {
        **page,
        "errors": list(dict.fromkeys([*console_errors, *formatted_page_errors])),
        "warnings": console_warnings,
    }
    error_items = _check_items(errors, "errors")
    warning_items = _check_items(errors, "warnings")
    network_items, network_unknown = _network_findings(network or [])
    if network_unknown:
        command_warnings.append(f"network responses: {len(network_unknown)} unavailable")
    first_screenshot = screenshot_paths.get(check.viewports[0].label)
    detail_lines = [
        *( [f"Target: {request.target}"] if request.target == "local-ai" else []),
        f"Screenshot: {display_path(request.root, Path(first_screenshot)) if first_screenshot else 'unavailable'}",
        f"Render readiness: {readiness}",
        "Viewport readiness: " + json.dumps(viewport_readiness, sort_keys=True),
        "Responsive set: " + ", ".join(f"{v.label} {v.width}x{v.height}" for v in check.viewports),
    ]
    if readiness_indicators:
        detail_lines.extend(["Visible loading indicators:", *(f"  {indicator}" for indicator in readiness_indicators)])
    if len(check.viewports) > 1:
        detail_lines.append("Additional screenshots:")
        detail_lines.extend(
            f"  {v.label}: {display_path(request.root, Path(screenshot_paths[v.label])) if v.label in screenshot_paths else 'unavailable'}"
            for v in check.viewports[1:]
        )
    detail_lines.extend([f"Page: {errors.get('url', 'unknown')}", f"Title: {errors.get('title', 'unknown')}"])
    for heading, items in (
        ("Console errors", error_items),
        ("Console warnings", warning_items),
        ("Failed network requests", network_items),
        ("Network response unavailable", network_unknown),
        ("Browser command warnings", command_warnings),
    ):
        if items:
            detail_lines.append(f"\n{heading} ({len(items)}):")
            detail_lines.extend(str(item) for item in items)
    name = ("browser-check-local-ai" if request.target == "local-ai" else "browser-check") + f"-{uuid4().hex[:12]}"
    details = write_details(request.root, name, "\n".join(detail_lines))
    status = "INCOMPLETE" if command_warnings else "OK" if not error_items and not warning_items and not network_items else "ISSUES"
    target = "|target=local-ai" if request.target == "local-ai" else ""
    print(
        f"BROWSER_CHECK:{status}{target}|errors={len(error_items)}|warnings={len(warning_items)}|"
        f"network={len(network_items)}|command_warnings={len(command_warnings)}|readiness={readiness}|"
        f"screenshot={(display_path(request.root, Path(first_screenshot)) if request.target == 'local-ai' else first_screenshot) if first_screenshot else 'unavailable'}|"
        f"details:{display_path(request.root, details)}"
    )
    if command_warnings:
        return 2
    return 1 if error_items or warning_items or network_items else 0


def _execute_health(request: BrowserRequest) -> int:
    if request.target == "local-ai":
        prefix = list(request.launch.prefix)
        profile = prefix[prefix.index("--profile") + 1] if "--profile" in prefix else "AI"
        executable = prefix[prefix.index("--executable-path") + 1] if "--executable-path" in prefix else "not found"
        session = request.args[request.args.index("--session") + 1] if "--session" in request.args else "unknown"
        print("Target: local system Chrome (AI profile)")
        print(f"chrome: {executable}")
        print(f"profile: {profile}")
        print(f"session: {session} (singleton)")
        print(f"window-mode: {request.launch.window_mode}")
        if request.launch.window_mode == "minimized":
            print("window-behavior: starts minimized/iconified; restore the st-browser-ai window from the taskbar to watch")
        if request.launch.window_mode == "headless":
            print("window-behavior: no desktop window; hardware GL required; software rasterizer disabled")
        print(f"agent-browser-bin: {request.launch.agent_browser_bin}")
        probe = _run_agent(request, ["--session", session, "get", "url"])
        ready = probe.returncode == 0 and bool(probe.stdout.strip())
        print(f"status: {'UP' if ready else 'DOWN'}")
        return 0 if ready else 1
    assert request.endpoint is not None
    marker = "; debug-local" if request.endpoint.debug_local else ""
    print(f"Target: {request.endpoint.host} ({request.endpoint.source}{marker})")
    print(f"{'ENGINE':<12} {'PORT':<6} {'STATUS':<6} DETAILS")

    def ready(payload: dict[str, object] | list[object] | None) -> bool:
        if not isinstance(payload, dict):
            return False
        websocket = payload.get("webSocketDebuggerUrl")
        return isinstance(websocket, str) and websocket.startswith(("ws://", "wss://"))

    selected_up = False
    for engine, port in _ENGINE_PORTS.items():
        payload = http_json(f"http://{request.endpoint.host}:{port}/json/version")
        detail = str(payload.get("Browser") or payload.get("webSocketDebuggerUrl") or "-") if isinstance(payload, dict) else "-"
        available = ready(payload)
        print(f"{engine:<12} {port:<6} {'UP' if available else 'DOWN':<6} {detail}")
        if port == request.endpoint.port:
            selected_up = available
    if request.endpoint.port not in _ENGINE_PORTS.values():
        selected_up = ready(http_json(f"http://{request.endpoint.host}:{request.endpoint.port}/json/version"))
        print(f"{'selected':<12} {request.endpoint.port:<6} {'UP' if selected_up else 'DOWN':<6} -")
    return 0 if selected_up else 1


def _execute_update(request: BrowserRequest) -> int:
    current = subprocess.run(
        [request.launch.agent_browser_bin, "--version"], text=True, capture_output=True, check=False
    ).stdout.strip() or "unknown"
    latest = subprocess.run(["npm", "view", "agent-browser", "version"], text=True, capture_output=True, check=False)
    print(f"agent-browser: installed={current} latest={latest.stdout.strip() or '?'}")
    if request.endpoint:
        print("Runtime:")
        print(f"  host: {request.endpoint.host}")
        print(f"  source: {request.endpoint.source}")
        print(f"  debug_local: {request.endpoint.debug_local}")
    print(f"  agent-browser-bin: {request.launch.agent_browser_bin}")
    return 0


def _execute_agent(request: BrowserRequest) -> int:
    if request.target == "proxmox" and request.command == "open" and request.default_viewport:
        session = list(request.args[:2]) if request.args[:1] == ("--session",) else []
        _run_agent(
            request,
            [*session, "set", "viewport", request.default_viewport.width, request.default_viewport.height],
        )
    result = _run_agent(request, list(request.args))
    if request.target == "local-ai":
        _maybe_warn_visible(request, result)
        result = _without_default_daemon_warning(result, default_launch=request.launch.default_launch)
        _maybe_minimize(request)
    name = f"browser-local-ai-{request.command or 'command'}" if request.target == "local-ai" else f"browser-{request.command or 'command'}"
    name += f"-{uuid4().hex[:12]}"
    emit_result_or_details(request.root, name, "BROWSER", result)
    if request.target == "proxmox":
        args = list(request.args)
        session = args[args.index("--session") + 1] if "--session" in args and args.index("--session") + 1 < len(args) else None
        _run_reaper(request, session)
    return result.returncode


def _execute_resolved(request: BrowserRequest) -> int:
    if request.contract_version == 2:
        from .structured import execute_structured
        return execute_structured(request, _run_agent)
    if request.operation == "reap-isolated":
        return reap_isolated(request.launch.agent_browser_bin, dry_run="--dry-run" in request.args)
    if request.operation == "inventory":
        return inventory(request)
    if request.operation == "health":
        return _execute_health(request)
    if request.operation == "update":
        return _execute_update(request)
    if request.operation == "check":
        assert request.check is not None
        return _execute_check(request, request.check)
    return _execute_agent(request)


def _managed_request(request: BrowserRequest, session) -> BrowserRequest:
    prefix = list(request.launch.prefix)
    if "--profile" in prefix:
        index = prefix.index("--profile")
        del prefix[index:index + 2]
    resolved = replace(request, launch=replace(request.launch,
        prefix=("--profile", str(session.profile), "--idle-timeout", "0", *prefix), isolation_root=session.runtime_root,
        managed_session=session.name, daemon_session=session.daemon_session, minimize=False), reaper=None)
    return _with_runtime_target(resolved, session)


def _with_runtime_target(request: BrowserRequest, session) -> BrowserRequest:
    """A running daemon keeps the browser it launched against.

    agent-browser relaunches a different browser when a command's launch options
    differ from the running daemon's, so every command for a running session
    reuses the recorded remote endpoint (or none). A dormant session adopts the
    host-selected target and records it for the rest of its runtime.
    """
    from . import sessions
    if sessions.running(session):
        recorded = sessions.runtime_endpoint(session)
        if recorded is None:
            return replace(request, target="local-ai", endpoint=None, default_viewport=None)
        return replace(request, target="proxmox", endpoint=Endpoint.parse(recorded))
    remote = request.target == "proxmox" and request.endpoint is not None
    if request.operation not in {"session"}:
        sessions.record_runtime_endpoint(session, asdict(request.endpoint) if remote and request.endpoint else None)
    return request


def _execute_session(request: BrowserRequest) -> int:
    from . import sessions
    payload = request.payload or {}
    action, name = payload["action"], payload.get("name")
    if action == "list":
        result = {"schema_version": 1, "sessions": sessions.operator_inventory() if payload.get("all") else sessions.list_sessions()}
    elif action == "maintenance":
        result = sessions.maintenance(dry_run=payload.get("dry_run", True), idle_ms=payload.get("idle_ms"),
            request_factory=lambda session: _managed_request(request, session), runner=_run_agent)
    else:
        if not isinstance(name, str):
            raise ValueError("Session lifecycle action requires a name")
        with sessions.session_lock(name) as held:
            if action == "create":
                sessions.create(name, lock=held)
            elif action == "pause":
                sessions.pause(name, lock=held)
            elif action == "resume":
                sessions.resume(name, lock=held)
            if action in {"view", "lease"}:
                from .structured import _batch, _IDENTITY, _value
                session = sessions.resolve(name, lock=held)
                current = sessions.status(name, lock=held)
                if action == 'lease' and not current['paused']:
                    raise ValueError('Human input lease requires a paused session')
                if current['runtime_state'] != 'running':
                    raise ValueError('Live view requires the existing running session; reopen it explicitly')
                resolved = replace(_managed_request(request, session), args=("--session", name))
                rows, error = _batch(resolved, _run_agent, [["tab", "list"], ["eval", _IDENTITY], ["stream", "status"]])
                if error or len(rows) != 3 or not all(row['success'] for row in rows):
                    raise ValueError('Live view evidence unavailable for the selected session')
                tabs = rows[0]['result']['tabs']
                tab = next((tab for tab in tabs if tab.get('active') or tab.get('current')), None)
                page = _value(rows[1]['result'])
                stream = rows[2]['result']
                if not tab or not isinstance(page, dict) or type(stream.get('port')) is not int or not 1 <= stream['port'] <= 65535:
                    raise ValueError('Live view target or stream port is unverifiable')
                url = urlsplit(page.get('url',''))
                page['url'] = urlunsplit((url.scheme, url.netloc.rsplit('@', 1)[-1], url.path, '', ''))
                result = {**current, 'stream':{'enabled':stream.get('enabled') is True,'port':stream['port']}, 'page':page,
                          'binding':{'session':name,'target_id':tab.get('targetId'),'document_id':page['document_id']}}
                if action == 'lease':
                    print(json.dumps({**result,'status':'leased'},separators=(',',':')),flush=True)
                    sys.stdin.buffer.read()
                    return 0
            elif action == "close":
                session = sessions.resolve(name, lock=held)
                result = sessions.close(name, request=_managed_request(request, session), runner=_run_agent, lock=held)
            else:
                result = sessions.status(name, lock=held)
    print(json.dumps(result, separators=(",", ":")))
    return 2 if result.get("errors") else 0


def execute(request: BrowserRequest) -> int:
    from . import sessions
    try:
        if request.operation == 'selected-tabs':
            from . import selected_tabs
            payload = request.payload or {}
            if payload['action']=='list':
                result = {'schema_version':1,'selections':selected_tabs.list_grants()}
            elif payload['action']=='revoke':
                selected_tabs.revoke_grant(payload['handle'])
                result = {'schema_version':1,'status':'revoked','selection':payload['handle']}
            else:
                result = {'schema_version':1,**selected_tabs.capabilities()}
            print(json.dumps(result,separators=(',',':')))
            return 0
        if request.target == 'selected-tab':
            from .selected_execution import execute as execute_selected
            return execute_selected(request,_run_agent)
        if request.operation == "session":
            return _execute_session(request)
        if request.operation == "workflow":
            from .workflows import execute_workflow
            if not request.launch.managed_session:
                raise ValueError('Workflows require an explicit managed session')
            payload = request.payload or {}
            if payload['action'] in {'record-start', 'record-stop'}:
                from .recording import execute_recording
                with sessions.use(request.launch.managed_session) as session:
                    return execute_recording(request, session)
            if payload['action'] in {'status', 'cancel'}:
                return execute_workflow(request, _run_agent)
            if payload['action'] == 'resume':
                from .workflows import _read
                record = _read(payload['run_id'])
                if record['session'] != request.launch.managed_session:
                    raise ValueError('Workflow session changed; select the original owned session')
                if record['status'] in {'complete', 'cancelled'}:
                    return execute_workflow(request, _run_agent)
                sessions.resume(request.launch.managed_session)
            with sessions.use(request.launch.managed_session) as session:
                return execute_workflow(_managed_request(request, session), _run_agent, session)
        if request.launch.managed_session:
            with sessions.use(request.launch.managed_session) as session:
                resolved = _managed_request(request, session)
                if request.operation == "agent" and request.command in {"close", "quit", "exit"}:
                    result = sessions.close(session.name, request=resolved, runner=_run_agent, lock=session.lock)
                    print(json.dumps(result, separators=(",", ":")))
                    return 0 if result["closed"] else 2
                if request.contract_version == 2 and request.operation in {'observe', 'run', 'extract'}:
                    from .structured import execute_structured
                    return execute_structured(resolved, _run_agent, session=session)
                return _execute_resolved(resolved)
        return _execute_resolved(request)
    except sessions.SessionError as exc:
        output_error(str(exc))
        return 75
