"""Versioned, fully resolved request contract for browser execution."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

CONTRACT_VERSION = 1
_REQUEST_KEYS = {
    "contract_version",
    "operation",
    "target",
    "command",
    "args",
    "root",
    "endpoint",
    "launch",
    "check",
    "default_viewport",
    "reaper",
}


def _exact(value: Mapping[str, Any], keys: set[str], label: str) -> None:
    if set(value) != keys:
        raise ValueError(f"{label} must contain exactly {sorted(keys)}")


def _text(value: Any, label: str, *, empty: bool = False) -> str:
    if not isinstance(value, str) or (not empty and not value.strip()):
        qualifier = "a string" if empty else "a non-empty string"
        raise ValueError(f"{label} must be {qualifier}")
    return value


@dataclass(frozen=True)
class Endpoint:
    host: str
    port: int
    ws: str
    source: str
    debug_local: bool

    @classmethod
    def parse(cls, value: Any) -> Endpoint | None:
        if value is None:
            return None
        if not isinstance(value, dict):
            raise ValueError("request.endpoint must be an object or null")
        _exact(value, {"host", "port", "ws", "source", "debug_local"}, "request.endpoint")
        port = value["port"]
        if type(port) is not int or not 1 <= port <= 65535:
            raise ValueError("request.endpoint.port must be an integer from 1 to 65535")
        if type(value["debug_local"]) is not bool:
            raise ValueError("request.endpoint.debug_local must be a boolean")
        return cls(
            host=_text(value["host"], "request.endpoint.host"),
            port=port,
            ws=_text(value["ws"], "request.endpoint.ws"),
            source=_text(value["source"], "request.endpoint.source"),
            debug_local=value["debug_local"],
        )


@dataclass(frozen=True)
class Launch:
    agent_browser_bin: str
    prefix: tuple[str, ...]
    window_mode: str
    default_launch: bool
    minimize: bool
    window_class: str

    @classmethod
    def parse(cls, value: Any) -> Launch:
        if not isinstance(value, dict):
            raise ValueError("request.launch must be an object")
        _exact(
            value,
            {"agent_browser_bin", "prefix", "window_mode", "default_launch", "minimize", "window_class"},
            "request.launch",
        )
        prefix = value["prefix"]
        if not isinstance(prefix, list) or any(not isinstance(item, str) for item in prefix):
            raise ValueError("request.launch.prefix must be an array of strings")
        if type(value["default_launch"]) is not bool or type(value["minimize"]) is not bool:
            raise ValueError("request.launch default_launch and minimize must be booleans")
        return cls(
            agent_browser_bin=_text(value["agent_browser_bin"], "request.launch.agent_browser_bin"),
            prefix=tuple(prefix),
            window_mode=_text(value["window_mode"], "request.launch.window_mode"),
            default_launch=value["default_launch"],
            minimize=value["minimize"],
            window_class=_text(value["window_class"], "request.launch.window_class", empty=True),
        )


@dataclass(frozen=True)
class Viewport:
    label: str
    width: int
    height: int
    path: str

    @classmethod
    def parse(cls, value: Any, index: int) -> Viewport:
        if not isinstance(value, dict):
            raise ValueError(f"request.check.viewports[{index}] must be an object")
        _exact(value, {"label", "width", "height", "path"}, f"request.check.viewports[{index}]")
        if type(value["width"]) is not int or type(value["height"]) is not int:
            raise ValueError("viewport width and height must be integers")
        return cls(
            label=_text(value["label"], "viewport.label"),
            width=value["width"],
            height=value["height"],
            path=_text(value["path"], "viewport.path"),
        )


@dataclass(frozen=True)
class Check:
    url: str
    screenshot_path: str
    session: str
    viewports: tuple[Viewport, ...]
    settle_ms: str
    viewport_settle_ms: str

    @classmethod
    def parse(cls, value: Any) -> Check | None:
        if value is None:
            return None
        if not isinstance(value, dict):
            raise ValueError("request.check must be an object or null")
        _exact(
            value,
            {"url", "screenshot_path", "session", "viewports", "settle_ms", "viewport_settle_ms"},
            "request.check",
        )
        viewports = value["viewports"]
        if not isinstance(viewports, list) or not viewports:
            raise ValueError("request.check.viewports must be a non-empty array")
        return cls(
            url=_text(value["url"], "request.check.url"),
            screenshot_path=_text(value["screenshot_path"], "request.check.screenshot_path"),
            session=_text(value["session"], "request.check.session"),
            viewports=tuple(Viewport.parse(item, index) for index, item in enumerate(viewports)),
            settle_ms=_text(value["settle_ms"], "request.check.settle_ms"),
            viewport_settle_ms=_text(value["viewport_settle_ms"], "request.check.viewport_settle_ms"),
        )


@dataclass(frozen=True)
class DefaultViewport:
    width: str
    height: str

    @classmethod
    def parse(cls, value: Any) -> DefaultViewport | None:
        if value is None:
            return None
        if not isinstance(value, dict):
            raise ValueError("request.default_viewport must be an object or null")
        _exact(value, {"width", "height"}, "request.default_viewport")
        return cls(
            width=_text(value["width"], "request.default_viewport.width"),
            height=_text(value["height"], "request.default_viewport.height"),
        )


@dataclass(frozen=True)
class BrowserRequest:
    contract_version: int
    operation: str
    target: str
    command: str
    args: tuple[str, ...]
    root: Path
    endpoint: Endpoint | None
    launch: Launch
    check: Check | None
    default_viewport: DefaultViewport | None
    reaper: str | None

    @classmethod
    def from_json(cls, raw: str) -> BrowserRequest:
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError("--request must contain valid JSON") from exc
        if not isinstance(value, dict):
            raise ValueError("--request must contain a JSON object")
        return cls.from_mapping(value)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> BrowserRequest:
        _exact(value, _REQUEST_KEYS, "request")
        if value["contract_version"] != CONTRACT_VERSION:
            raise ValueError(f"unsupported browser request contract version: {value['contract_version']!r}")
        operation = _text(value["operation"], "request.operation")
        if operation not in {"agent", "check", "health", "update"}:
            raise ValueError("request.operation must be agent, check, health, or update")
        target = _text(value["target"], "request.target")
        if target not in {"local-ai", "proxmox"}:
            raise ValueError("request.target must be local-ai or proxmox")
        args = value["args"]
        if not isinstance(args, list) or any(not isinstance(item, str) for item in args):
            raise ValueError("request.args must be an array of strings")
        root = Path(_text(value["root"], "request.root"))
        if not root.is_absolute():
            raise ValueError("request.root must be an absolute path")
        endpoint = Endpoint.parse(value["endpoint"])
        if target == "proxmox" and operation != "update" and endpoint is None:
            raise ValueError("request.endpoint is required for the proxmox target")
        check = Check.parse(value["check"])
        if operation == "check" and check is None:
            raise ValueError("request.check is required for the check operation")
        if operation != "check" and check is not None:
            raise ValueError("request.check is only valid for the check operation")
        reaper = value["reaper"]
        if reaper is not None:
            reaper = _text(reaper, "request.reaper")
        return cls(
            contract_version=CONTRACT_VERSION,
            operation=operation,
            target=target,
            command=_text(value["command"], "request.command", empty=True),
            args=tuple(args),
            root=root,
            endpoint=endpoint,
            launch=Launch.parse(value["launch"]),
            check=check,
            default_viewport=DefaultViewport.parse(value["default_viewport"]),
            reaper=reaper,
        )
