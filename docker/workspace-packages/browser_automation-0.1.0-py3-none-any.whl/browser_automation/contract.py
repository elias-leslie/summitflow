"""Versioned, fully resolved request contract for browser execution."""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from hashlib import sha1
from pathlib import Path
from typing import Any, Mapping

from .payload import validate_payload

CONTRACT_VERSION = 1
STRUCTURED_CONTRACT_VERSION = 2
_REQUEST_KEYS = {
    "contract_version",
    "operation",
    "target",
    "command",
    "args",
    "root",
    "endpoint",
    "launch",
    "check",
    "default_viewport",
    "reaper",
}


def _exact(value: Mapping[str, Any], keys: set[str], label: str) -> None:
    if set(value) != keys:
        raise ValueError(f"{label} must contain exactly {sorted(keys)}")


def _text(value: Any, label: str, *, empty: bool = False) -> str:
    if not isinstance(value, str) or (not empty and not value.strip()):
        qualifier = "a string" if empty else "a non-empty string"
        raise ValueError(f"{label} must be {qualifier}")
    return value


@dataclass(frozen=True)
class Endpoint:
    host: str
    port: int
    ws: str
    source: str
    debug_local: bool

    @classmethod
    def parse(cls, value: Any) -> Endpoint | None:
        if value is None:
            return None
        if not isinstance(value, dict):
            raise ValueError("request.endpoint must be an object or null")
        _exact(value, {"host", "port", "ws", "source", "debug_local"}, "request.endpoint")
        port = value["port"]
        if type(port) is not int or not 1 <= port <= 65535:
            raise ValueError("request.endpoint.port must be an integer from 1 to 65535")
        if type(value["debug_local"]) is not bool:
            raise ValueError("request.endpoint.debug_local must be a boolean")
        return cls(
            host=_text(value["host"], "request.endpoint.host"),
            port=port,
            ws=_text(value["ws"], "request.endpoint.ws"),
            source=_text(value["source"], "request.endpoint.source"),
            debug_local=value["debug_local"],
        )


@dataclass(frozen=True)
class Launch:
    agent_browser_bin: str
    prefix: tuple[str, ...]
    window_mode: str
    default_launch: bool
    minimize: bool
    window_class: str
    isolation_root: Path | None = None
    managed_session: str | None = None
    daemon_session: str | None = None
    selected_tab: str | None = None

    @classmethod
    def parse(cls, value: Any) -> Launch:
        if not isinstance(value, dict):
            raise ValueError("request.launch must be an object")
        _exact(
            value,
            {"agent_browser_bin", "prefix", "window_mode", "default_launch", "minimize", "window_class"}
            | ({"isolation_root"} if "isolation_root" in value else set())
            | ({"managed_session"} if "managed_session" in value else set())
            | ({"selected_tab"} if "selected_tab" in value else set()),
            # Managed-session identity is resolved by the browser owner, never a
            # caller-supplied profile/runtime path.
            "request.launch",
        )
        prefix = value["prefix"]
        if not isinstance(prefix, list) or any(not isinstance(item, str) for item in prefix):
            raise ValueError("request.launch.prefix must be an array of strings")
        if type(value["default_launch"]) is not bool or type(value["minimize"]) is not bool:
            raise ValueError("request.launch default_launch and minimize must be booleans")
        managed = value.get("managed_session")
        if managed is not None and (not isinstance(managed, str) or re.fullmatch(r"[A-Za-z0-9_-]+", managed) is None):
            raise ValueError("launch.managed_session must be a managed session name or null")
        selected = value.get("selected_tab")
        if selected is not None and (not isinstance(selected,str) or re.fullmatch(r"[0-9a-f]{32}",selected) is None):
            raise ValueError("launch.selected_tab must be an explicit selected tab handle")
        if selected is not None and managed is not None:
            raise ValueError("selected tabs cannot select managed profiles")
        return cls(
            agent_browser_bin=_text(value["agent_browser_bin"], "request.launch.agent_browser_bin"),
            prefix=tuple(prefix),
            window_mode=_text(value["window_mode"], "request.launch.window_mode"),
            default_launch=value["default_launch"],
            minimize=value["minimize"],
            window_class=_text(value["window_class"], "request.launch.window_class", empty=True),
            isolation_root=Path(_text(value["isolation_root"], "request.launch.isolation_root")) if "isolation_root" in value else None,
            managed_session=managed,
            selected_tab=selected,
        )


@dataclass(frozen=True)
class Viewport:
    label: str
    width: int
    height: int
    path: str

    @classmethod
    def parse(cls, value: Any, index: int) -> Viewport:
        if not isinstance(value, dict):
            raise ValueError(f"request.check.viewports[{index}] must be an object")
        _exact(value, {"label", "width", "height", "path"}, f"request.check.viewports[{index}]")
        if type(value["width"]) is not int or type(value["height"]) is not int:
            raise ValueError("viewport width and height must be integers")
        return cls(
            label=_text(value["label"], "viewport.label"),
            width=value["width"],
            height=value["height"],
            path=_text(value["path"], "viewport.path"),
        )


@dataclass(frozen=True)
class Check:
    url: str
    screenshot_path: str
    session: str
    viewports: tuple[Viewport, ...]
    settle_ms: str
    viewport_settle_ms: str

    @classmethod
    def parse(cls, value: Any) -> Check | None:
        if value is None:
            return None
        if not isinstance(value, dict):
            raise ValueError("request.check must be an object or null")
        _exact(
            value,
            {"url", "screenshot_path", "session", "viewports", "settle_ms", "viewport_settle_ms"},
            "request.check",
        )
        viewports = value["viewports"]
        if not isinstance(viewports, list) or not viewports:
            raise ValueError("request.check.viewports must be a non-empty array")
        session = _text(value["session"], "request.check.session")
        if re.fullmatch(r"[A-Za-z0-9_-]+", session) is None:
            raise ValueError("request.check.session must contain only letters, digits, underscores, or hyphens")
        return cls(
            url=_text(value["url"], "request.check.url"),
            screenshot_path=_text(value["screenshot_path"], "request.check.screenshot_path"),
            session=session,
            viewports=tuple(Viewport.parse(item, index) for index, item in enumerate(viewports)),
            settle_ms=_text(value["settle_ms"], "request.check.settle_ms"),
            viewport_settle_ms=_text(value["viewport_settle_ms"], "request.check.viewport_settle_ms"),
        )


@dataclass(frozen=True)
class DefaultViewport:
    width: str
    height: str

    @classmethod
    def parse(cls, value: Any) -> DefaultViewport | None:
        if value is None:
            return None
        if not isinstance(value, dict):
            raise ValueError("request.default_viewport must be an object or null")
        _exact(value, {"width", "height"}, "request.default_viewport")
        return cls(
            width=_text(value["width"], "request.default_viewport.width"),
            height=_text(value["height"], "request.default_viewport.height"),
        )


@dataclass(frozen=True)
class BrowserRequest:
    contract_version: int
    operation: str
    target: str
    command: str
    args: tuple[str, ...]
    root: Path
    endpoint: Endpoint | None
    launch: Launch
    check: Check | None
    default_viewport: DefaultViewport | None
    reaper: str | None
    payload: dict[str, Any] | None = None

    @classmethod
    def from_json(cls, raw: str) -> BrowserRequest:
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError("--request must contain valid JSON") from exc
        if not isinstance(value, dict):
            raise ValueError("--request must contain a JSON object")
        return cls.from_mapping(value)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> BrowserRequest:
        version = value.get("contract_version")
        if type(version) is not int or version not in {CONTRACT_VERSION, STRUCTURED_CONTRACT_VERSION}:
            raise ValueError(f"unsupported browser request contract version: {version!r}")
        _exact(value, _REQUEST_KEYS | ({"payload"} if version == 2 else set()), "request")
        operation = _text(value["operation"], "request.operation")
        legacy = {"agent", "check", "health", "update", "inventory", "reap-isolated"}
        structured = {"capabilities", "help", "observe", "run", "extract", "session", "workflow", "selected-tabs"}
        if operation not in (legacy if version == 1 else structured):
            raise ValueError("request.operation is not supported by this browser contract version")
        payload = validate_payload(operation, value["payload"]) if version == 2 else None
        target = _text(value["target"], "request.target")
        if target not in {"local-ai", "proxmox", "selected-tab"}:
            raise ValueError("request.target must be local-ai, proxmox, or selected-tab")
        args = value["args"]
        if not isinstance(args, list) or any(not isinstance(item, str) for item in args):
            raise ValueError("request.args must be an array of strings")
        if operation == "reap-isolated" and (target != "local-ai" or args not in ([], ["--dry-run"])):
            raise ValueError("reap-isolated supports only local runtime cleanup and optional --dry-run")
        root = Path(_text(value["root"], "request.root"))
        if not root.is_absolute():
            raise ValueError("request.root must be an absolute path")
        endpoint = Endpoint.parse(value["endpoint"])
        if target == "proxmox" and operation not in {"update", "inventory", "capabilities", "help"} and endpoint is None:
            raise ValueError("request.endpoint is required for the proxmox target")
        check = Check.parse(value["check"])
        if operation == "check" and check is None:
            raise ValueError("request.check is required for the check operation")
        if operation != "check" and check is not None:
            raise ValueError("request.check is only valid for the check operation")
        launch = Launch.parse(value["launch"])
        if target == "selected-tab":
            if version != 2 or endpoint is not None or launch.prefix or launch.isolation_root or launch.managed_session:
                raise ValueError("Selected tabs require a v2 profile-free request with no caller endpoint")
            if operation not in {"selected-tabs","help","capabilities"} and launch.selected_tab is None:
                raise ValueError("Selected-tab execution requires an explicit grant")
        elif launch.selected_tab is not None:
            raise ValueError("selected_tab launch requires the selected-tab target")
        if launch.managed_session is not None:
            if target != "local-ai" or launch.isolation_root is not None or operation in {"check", "capabilities", "help"}:
                raise ValueError("managed sessions require a local interactive operation")
            if tuple(args[:2]) != ("--session", launch.managed_session):
                raise ValueError("managed launch session must match request.args")
        if launch.isolation_root is not None:
            if target != "local-ai" or operation != "check" or check is None:
                raise ValueError("isolated launch is only valid for local checks")
            runtime = Path(os.environ.get("XDG_RUNTIME_DIR", "").strip() or f"/tmp/st-browser-{os.getuid()}")
            expected = runtime / "st-browser-checks" / sha1(check.session.encode()).hexdigest()[:12]
            if launch.isolation_root != expected:
                raise ValueError("isolated launch root must match the check session runtime directory")
            if tuple(args) != ("--session", check.session, "check", check.url, check.screenshot_path):
                raise ValueError("isolated check args must match the check session and artifacts")
            if (
                len(launch.prefix) != 6
                or launch.prefix[:2] != ("--profile", str(expected / "profile"))
                or launch.prefix[2] != "--executable-path"
                or launch.prefix[4] != "--args"
                or launch.window_mode != "headless"
                or launch.minimize
                or not launch.default_launch
            ):
                raise ValueError("isolated launch must use its own profile and headless executable prefix")
        reaper = value["reaper"]
        if reaper is not None:
            reaper = _text(reaper, "request.reaper")
        return cls(
            contract_version=version,
            operation=operation,
            target=target,
            command=_text(value["command"], "request.command", empty=True),
            args=tuple(args),
            root=root,
            endpoint=endpoint,
            launch=launch,
            check=check,
            default_viewport=DefaultViewport.parse(value["default_viewport"]),
            reaper=reaper,
            payload=payload,
        )
