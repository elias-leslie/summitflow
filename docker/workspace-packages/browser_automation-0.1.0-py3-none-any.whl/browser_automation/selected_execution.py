"""Owned agent-browser IPC for one extension-granted tab, without a profile."""
from __future__ import annotations

import contextlib
import io
import json
import os
import shutil
import stat
import subprocess
from dataclasses import replace
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit
from uuid import uuid4

from . import ownership, selected_tabs, sessions
from .contract import BrowserRequest
from .selected_tabs import SelectedTabError
from .structured import Runner, execute_structured

_ACTIONS = {"open", "navigate", "click", "dblclick", "fill", "set-value", "type", "press", "keyboard", "key", "select", "check", "uncheck",
            "hover", "focus", "scroll", "scrollintoview", "wait", "eval", "get", "find", "snapshot", "screenshot", "upload",
            "dialog", "mouse", "frame", "back", "forward", "reload", "highlight", "is"}


def _name(selection: str) -> str:
    if selected_tabs._HANDLE.fullmatch(selection) is None:
        raise SelectedTabError("selected-tab execution requires an explicit grant handle")
    return f"sel-{selection}"


def runtime_root(selection: str) -> Path:
    """One private IPC location per grant, independent of caller runtime env."""
    name = _name(selection)
    base = Path(f"/tmp/st-bs-{os.getuid()}")
    selected_tabs.private_directory(base)
    selected_tabs.private_directory(base / "st-browser-sessions")
    return sessions.runtime_root(name, runtime_base=base)


def _read_private(path: Path) -> dict[str, Any]:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "r", encoding="utf-8") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077 or info.st_size > 4096:
            raise SelectedTabError("selected-tab IPC ownership is not private")
        value = json.load(stream)
        if not isinstance(value, dict):
            raise SelectedTabError("selected-tab IPC ownership is invalid")
        return value


def _write_private(path: Path, value: dict[str, Any]) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(value, stream, separators=(",", ":"))


def _replace_private(path: Path, value: dict[str, Any]) -> None:
    temporary = path.parent / f".selected-config-{uuid4().hex}.json"
    try:
        _write_private(temporary, value)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def _prepare(selection: str, actor: str, grant: selected_tabs.SelectedGrant, request: BrowserRequest) -> BrowserRequest:
    name = _name(selection)
    root = runtime_root(selection)
    selected_tabs.private_directory(root)
    selected_tabs.private_directory(root / "sockets")
    daemon = f"sel-{selection[:20]}"
    expected = {"schema_version": 1, "selection": selection, "actor": actor, "daemon": daemon}
    owner = root / "selected-owner.json"
    if owner.exists() or owner.is_symlink():
        if _read_private(owner) != expected:
            raise SelectedTabError("selected-tab grant belongs to another actor; request a new user grant")
    else:
        _write_private(owner, expected)
    config = root / "config.json"
    expected_config = {"cdp": grant.cdp_url}
    if config.exists() or config.is_symlink():
        current = _read_private(config)
        if current == {}:
            # Upgrade only our previous empty, private selected config under the
            # same actor/selection lock. Its old daemon may already carry the
            # credential in argv, so release exact owned IPC before upgrading.
            if cleanup_runtime(selection, remove=False):
                raise SelectedTabError("selected-tab legacy IPC cleanup incomplete; use the extension action")
            _replace_private(config, expected_config)
        elif current != expected_config:
            raise SelectedTabError("selected-tab IPC configuration changed")
    else:
        _write_private(config, expected_config)
    # Official 0.38.1 tab_binding.rs schema. Pinning without this creates a new tab.
    binding = root / "sockets" / f"{daemon}.target"
    if binding.exists() or binding.is_symlink():
        current = _read_private(binding)
        if current.get("targetId") != grant.target_id or current.get("pinned") is not True:
            raise SelectedTabError("selected-tab target binding changed; request a new user grant")
    else:
        _write_private(binding, {"targetId": grant.target_id, "url": grant.origin, "pinned": True})
    launch = replace(request.launch, prefix=("--pin-tab", "--restore-save", "never"),
                     isolation_root=root, managed_session=None, daemon_session=daemon,
                     default_launch=False, minimize=False, window_mode="headless", window_class="")
    return replace(request, target="local-ai", endpoint=None, launch=launch, args=("--session", name), reaper=None)


def validate_private_config(request: BrowserRequest) -> Path:
    """Runner guard for the private selected CDP config, with no fallback launch."""
    selection = request.launch.selected_tab
    if not isinstance(selection, str):
        raise SelectedTabError("selected-tab private config requires an explicit grant")
    name = _name(selection)
    root = runtime_root(selection)
    daemon = f"sel-{selection[:20]}"
    if (request.launch.isolation_root != root or request.launch.daemon_session != daemon or
            request.launch.managed_session is not None or request.target != "local-ai" or request.endpoint is not None or
            request.launch.prefix != ("--pin-tab", "--restore-save", "never") or request.args != ("--session", name)):
        raise SelectedTabError("selected-tab private config execution context changed")
    selected_tabs.private_directory(root)
    selected_tabs.private_directory(root / "sockets")
    expected = {"schema_version": 1, "selection": selection, "actor": sessions.actor_identity(), "daemon": daemon}
    if _read_private(root / "selected-owner.json") != expected:
        raise SelectedTabError("selected-tab grant belongs to another actor")
    config = root / "config.json"
    if _read_private(config) != {"cdp": selected_tabs.resolve_grant(selection).cdp_url}:
        raise SelectedTabError("selected-tab private config no longer matches the live grant")
    return config


def cleanup_runtime(selection: str, *, remove: bool = True) -> list[str]:
    """Close only processes proven to have this private IPC environment marker.

    Called by the native host on grant revocation. Its stdout must remain binary,
    so established ownership cleanup diagnostics are captured locally.
    """
    try:
        root = runtime_root(selection)
        if not root.exists():
            return []
        selected_tabs.private_directory(root)
        record = _read_private(root / "selected-owner.json")
        if record.get("schema_version") != 1 or record.get("selection") != selection or record.get("daemon") != f"sel-{selection[:20]}":
            return ["selected-tab IPC ownership unverifiable; retained"]
        if (root / "profile").exists() or (root / "profile").is_symlink():
            return ["selected-tab IPC contains an unexpected Chrome profile; retained"]
        if ownership._runtime_identity_error(root, record["daemon"]):
            return ["selected-tab IPC process ownership unverifiable; retained"]
        with contextlib.redirect_stdout(io.StringIO()):
            errors = ownership.terminate_owned(root, _name(selection))
        if errors:
            return ["selected-tab IPC process cleanup incomplete; retained"]
        if remove:
            shutil.rmtree(root)
        return []
    except (OSError, ValueError):
        return ["selected-tab IPC ownership unverifiable; retained"]


def revoke(selection: str) -> None:
    """Release this actor's idle IPC, then revoke its exact authenticated grant.

    The selection mutex prevents interrupting an active public command. Retaining
    the ownership record until native revocation completes prevents actor adoption
    if the control transport fails after the daemon has been stopped.
    """
    from websockets.sync.client import connect

    name = _name(selection)
    actor = sessions.actor_identity()
    with sessions.session_lock(name):
        grant = selected_tabs.resolve_grant(selection)
        root = runtime_root(selection)
        if root.exists() or root.is_symlink():
            selected_tabs.private_directory(root)
            expected = {"schema_version": 1, "selection": selection, "actor": actor, "daemon": f"sel-{selection[:20]}"}
            try:
                record = _read_private(root / "selected-owner.json")
            except (OSError, ValueError) as exc:
                raise SelectedTabError("selected-tab IPC ownership unverifiable; use the extension action") from exc
            if record != expected:
                raise SelectedTabError("selected-tab grant belongs to another actor; use the extension action")
            if cleanup_runtime(selection, remove=False):
                raise SelectedTabError("selected-tab IPC cleanup incomplete; use the extension action")
        try:
            with connect(grant.cdp_url, open_timeout=2, close_timeout=2, proxy=None) as connection:
                connection.send(json.dumps({"id": 1, "method": "BrowserAutomation.revokeGrant"}))
                reply = json.loads(connection.recv(timeout=5))
                if reply.get("id") != 1 or reply.get("result") != {} or reply.get("error"):
                    raise ValueError("revoke acknowledgement unavailable")
        except Exception as exc:
            raise SelectedTabError("grant revoke unavailable; use the extension action") from exc
        if cleanup_runtime(selection):
            raise SelectedTabError("selected-tab grant revoked but IPC cleanup incomplete")


def _validate_actions(request: BrowserRequest, grant: selected_tabs.SelectedGrant) -> None:
    for action in (request.payload or {}).get("actions", []):
        if action[0] not in _ACTIONS and action != ["tab", "list"]:
            raise SelectedTabError("action is unsupported by selected-tab authority; consult selected-tab capabilities")
        if action[0] in {"open", "navigate"} and (len(action) < 2 or selected_tabs.origin(action[1]) != grant.origin):
            raise SelectedTabError("navigation outside the granted origin requires user regrant")


def execute(request: BrowserRequest, runner: Runner) -> int:
    """Execute v2 evidence/actions using Launch.selected_tab's exact live grant."""
    try:
        if request.contract_version != 2 or request.operation not in {"observe", "run", "extract", "help", "capabilities"}:
            raise SelectedTabError("selected-tab provider supports v2 observe, run, extract, help, and capabilities")
        if request.operation == "capabilities":
            print(json.dumps(selected_tabs.capabilities(), separators=(",", ":")))
            return 0
        if request.operation == "help":
            return execute_structured(request, runner)
        selection = getattr(request.launch, "selected_tab", None)
        if not isinstance(selection, str):
            raise SelectedTabError("select an explicit extension grant handle")
        name = _name(selection)
        actor = sessions.actor_identity()
        with sessions.session_lock(name):
            grant = selected_tabs.resolve_grant(selection)
            _validate_actions(request, grant)
            resolved = _prepare(selection, actor, grant, request)
            token = urlsplit(grant.cdp_url).path.split("/")[1]

            def safe_runner(current: BrowserRequest, args: list[str], **options: Any) -> subprocess.CompletedProcess[str]:
                result = runner(current, args, **options)
                def redact(value: str | None) -> str:
                    return (value or "").replace(grant.cdp_url, "[private selected-tab endpoint]").replace(token, "[private selected-tab credential]")
                return subprocess.CompletedProcess([], result.returncode, redact(result.stdout), redact(result.stderr))

            # This skip-launch command disables agent-browser's automatic unauthenticated
            # loopback stream before the daemon receives a selected-page CDP client.
            safe_runner(resolved, [*resolved.args, "stream", "disable", "--json"])
            disabled = safe_runner(resolved, [*resolved.args, "stream", "status", "--json"])
            try:
                evidence = json.loads(disabled.stdout)
            except (ValueError, TypeError) as exc:
                raise SelectedTabError("cannot verify disabled selected-tab streaming") from exc
            if disabled.returncode or not evidence.get("success") or evidence.get("data", {}).get("enabled") is not False:
                raise SelectedTabError("cannot verify disabled selected-tab streaming")
            return execute_structured(resolved, safe_runner)
    except (SelectedTabError, sessions.SessionError, OSError) as exc:
        # No raw transport exceptions or command lines reach the public receipt.
        message = str(exc) if isinstance(exc, (SelectedTabError, sessions.SessionError)) else "selected-tab IPC unavailable"
        print(json.dumps({"schema_version": 1, "status": "failed", "error": message}, separators=(",", ":")))
        return 75 if isinstance(exc, sessions.SessionBusy) else 2
