"""Browser data-plane helpers, independent of SummitFlow routing policy."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

import httpx


def http_json(url: str) -> dict[str, object] | list[object] | None:
    try:
        response = httpx.get(url, timeout=2.0)
    except httpx.HTTPError:
        return None
    if response.status_code >= 400:
        return None
    try:
        parsed = response.json()
    except json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict | list) else None


def browser_page_target_ids(host: str, port: int) -> set[str] | None:
    targets = http_json(f"http://{host}:{port}/json/list")
    if not isinstance(targets, list):
        return None
    ids: set[str] = set()
    for target in targets:
        if not isinstance(target, dict):
            continue
        data = cast(dict[str, Any], target)
        target_id = data.get("id")
        if data.get("type") == "page" and isinstance(target_id, str) and target_id:
            ids.add(target_id)
    return ids


def close_browser_targets(host: str, port: int, target_ids: set[str]) -> int:
    closed = 0
    for target_id in target_ids:
        try:
            response = httpx.get(f"http://{host}:{port}/json/close/{target_id}", timeout=2.0)
        except httpx.HTTPError:
            continue
        if response.status_code < 400:
            closed += 1
    return closed


def close_blank_browser_targets(host: str, port: int) -> int:
    targets = http_json(f"http://{host}:{port}/json/list")
    if not isinstance(targets, list):
        return 0
    ids: set[str] = set()
    for target in targets:
        if not isinstance(target, dict):
            continue
        data = cast(dict[str, Any], target)
        target_id = data.get("id")
        title = str(data.get("title") or "")
        if (
            data.get("type") == "page"
            and isinstance(target_id, str)
            and target_id
            and data.get("url") == "about:blank"
            and (title in {"", "about:blank"} or title.startswith("Starting agent "))
        ):
            ids.add(target_id)
    return close_browser_targets(host, port, ids)


def suffixed(path: str, suffix: str) -> str:
    target = Path(path)
    return str(target.with_name(f"{target.stem}{suffix}{target.suffix}"))


def json_from_agent_eval(raw: str) -> dict[str, object] | list[object]:
    try:
        parsed = json.loads(raw.strip())
        if isinstance(parsed, str):
            parsed = json.loads(parsed)
        return parsed if isinstance(parsed, dict | list) else {}
    except json.JSONDecodeError:
        return {}


def parse_agent_console(raw: str) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    active: list[str] | None = None
    for line in raw.splitlines():
        stripped = line.strip()
        lowered = stripped.lower()
        if lowered.startswith(("[error]", "[pageerror]")):
            errors.append(stripped)
            active = errors
        elif lowered.startswith(("[warning]", "[warn]")):
            warnings.append(stripped)
            active = warnings
        elif stripped.startswith("["):
            active = None
        elif active is not None and stripped and not stripped.startswith("⚠"):
            active[-1] = f"{active[-1]}\n{stripped}"
    return errors, warnings

