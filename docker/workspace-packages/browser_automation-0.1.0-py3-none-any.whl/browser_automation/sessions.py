"""Owned persistent browser sessions, with separate durable and runtime state.

Ownership prevents accidental same-user agent collisions; it is not a security
boundary against another process running as the same Unix user. Profiles never
leave the machine and are never deleted by lifecycle or maintenance operations.
"""
from __future__ import annotations

import errno
import json
import contextlib
import sys
import os
import re
import shutil
import socket
import subprocess
import time
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from hashlib import sha256
from pathlib import Path
from typing import Any, Callable, Iterator

from . import ownership

SCHEMA_VERSION = 1
_NAME = re.compile(r"[A-Za-z0-9_-]+")
_ACTOR_ENV = ("ST_BROWSER_OWNER", "ST_AGENT_ID", "CODEX_THREAD_ID")
_STATES = {"active", "paused", "closed"}


class SessionError(ValueError):
    """A session could not be safely resolved or changed."""


class SessionBusy(SessionError):
    """The session is locked by another invocation."""


def actor_identity(actor: str | None = None) -> str:
    """Require an explicit environment identity; supplied identities must match."""
    current = next((os.environ[key].strip() for key in _ACTOR_ENV if os.environ.get(key, "").strip()), None)
    if current is None:
        raise SessionError("session actor requires ST_BROWSER_OWNER, ST_AGENT_ID, or CODEX_THREAD_ID")
    if re.fullmatch(r"[A-Za-z0-9_.:@/-]+", current) is None:
        raise SessionError("session actor must be a stable identifier without spaces or control characters")
    if actor is not None and (not isinstance(actor, str) or actor != current):
        raise SessionError("session actor does not match the current owner identity")
    return current


def _name(name: str) -> str:
    if not isinstance(name, str) or not _NAME.fullmatch(name):
        raise SessionError("session name must contain only letters, digits, underscores, or hyphens")
    return name


def state_base() -> Path:
    state = os.environ.get("XDG_STATE_HOME", "").strip()
    base = Path(state) if state else Path.home() / ".local" / "state"
    if not base.is_absolute():
        raise SessionError("XDG_STATE_HOME must be an absolute path")
    return Path(os.path.abspath(base)) / "browser-automation" / "sessions"


def _key(name: str) -> str:
    return sha256(_name(name).encode()).hexdigest()[:20]


def _namespace(name: str) -> str:
    return sha256(os.fsencode(state_base()) + b"\0" + _name(name).encode()).hexdigest()[:20]


def runtime_root(name: str, *, runtime_base: Path | None = None) -> Path:
    """Choose the initial runtime location; session metadata pins this choice."""
    namespace = _namespace(name)
    candidate = runtime_base if runtime_base is not None else Path(os.environ.get("XDG_RUNTIME_DIR", "").strip() or f"/tmp/st-bs-{os.getuid()}")
    if not candidate.is_absolute():
        raise SessionError("XDG_RUNTIME_DIR must be an absolute path")
    candidate = Path(os.path.abspath(candidate))
    # agent-browser socket filenames also include a short hashed daemon name.
    if len(os.fsencode(candidate / "st-browser-sessions" / namespace / "sockets" / f"s-{_key(name)}.sock")) >= 104:
        candidate = Path(f"/tmp/st-bs-{os.getuid()}")
    return candidate / "st-browser-sessions" / namespace


def lock_address(name: str) -> str:
    return f"\0st-browser-session-{os.getuid()}-{_namespace(name)}"


@dataclass(frozen=True)
class SessionLock:
    name: str
    address: str
    _handle: socket.socket = field(repr=False, compare=False)


@contextmanager
def session_lock(name: str, *, lock: SessionLock | None = None) -> Iterator[SessionLock]:
    """Nonblocking per-session mutex; reuse the capability for nested operations."""
    name = _name(name)
    address = lock_address(name)
    if lock is not None:
        if lock.name != name or lock.address != address or lock._handle.fileno() < 0:
            raise SessionError("session lock does not match the requested session")
        yield lock
        return
    with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as handle:
        try:
            handle.bind(address)
        except OSError as exc:
            if exc.errno == errno.EADDRINUSE:
                raise SessionBusy(f"session {name!r} is busy") from exc
            raise
        # Keep the previous mutex reserved during the whole request too. A CLI
        # invocation already running during the upgrade may still hold it.
        if (_root(name) / 'session.json').exists():
            record = _load(name, actor_identity())
            prior_root = _validated_runtime(name, record['runtime_root'])
        else:
            prior_root = runtime_root(name)
        prior_address = f"\0st-browser-session-{os.getuid()}-{sha256(os.fsencode(prior_root)).hexdigest()[:32]}"
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as prior:
            try:
                prior.bind(prior_address)
            except OSError as exc:
                if exc.errno == errno.EADDRINUSE:
                    raise SessionBusy(f"session {name!r} is busy") from exc
                raise
            yield SessionLock(name, address, handle)


@dataclass(frozen=True)
class Session:
    name: str
    actor: str
    state: str
    profile: Path
    runtime_root: Path
    socket_dir: Path
    config: Path
    daemon_session: str
    last_used_ms: int
    lock: SessionLock | None = field(default=None, repr=False, compare=False)

    @property
    def paused(self) -> bool:
        return self.state == "paused"

    def require_automation(self) -> None:
        if self.state != "active":
            raise SessionError(f"session {self.name!r} is {self.state}; explicit owner resume is required")


def _mkdir_durable(path: Path) -> None:
    if path.parent == path:
        return
    _mkdir_durable(path.parent)
    try:
        path.mkdir(mode=0o700)
    except FileExistsError:
        if not path.is_dir():
            raise
    # Adopt existing entries durably too: another creator may have exited
    # between mkdir and syncing this parent, outside our per-session lock.
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def _private(path: Path, *, create: bool = False) -> None:
    if any(part.is_symlink() for part in (path, *path.parents)):
        raise SessionError(f"session directory ownership is unverifiable: {path}")
    if create:
        _mkdir_durable(path)
    if path.is_symlink() or not path.is_dir() or path.stat().st_uid != os.getuid():
        raise SessionError(f"session directory ownership is unverifiable: {path}")
    if path.stat().st_mode & 0o077:
        raise SessionError(f"session directory must be private: {path}")


def _root(name: str) -> Path:
    return state_base() / _key(name)


def _validated_runtime(name: str, value: Any) -> Path:
    if not isinstance(value, str):
        raise SessionError('session runtime identity is invalid')
    path = Path(value)
    if (not path.is_absolute() or str(path) != os.path.abspath(value)
            or path.name != _namespace(name) or path.parent.name != 'st-browser-sessions'
            or len(os.fsencode(path / 'sockets' / f's-{_key(name)}.sock')) >= 104
            or any(part.is_symlink() for part in (path, *path.parents))):
        raise SessionError('session runtime identity is unverifiable')
    return path


def _legacy_runtime(name: str, record: dict[str, Any]) -> Path:
    """Recover a pre-pinning session only from its exact owned live processes."""
    profile = _root(name) / 'profile'
    processes = set(ownership.owned_processes(runtime_root(name), profile=profile))
    processes.update((item['pid'], item['start']) for item in record['processes'])
    roots: set[Path] = set()
    live = False
    for pid, start in processes:
        entry = Path('/proc') / str(pid)
        try:
            if ownership.process_start(pid) != start or entry.stat().st_uid != os.getuid():
                continue
            live = True
            marker = next((item for item in (entry / 'environ').read_bytes().split(b'\0')
                           if item.startswith(b'AGENT_BROWSER_SOCKET_DIR=')), None)
            if marker is None:
                raise SessionError('existing session runtime identity is unavailable')
            sockets = Path(os.fsdecode(marker.split(b'=', 1)[1]))
            if sockets.name != 'sockets':
                raise SessionError('existing session socket identity is unverifiable')
            candidate = _validated_runtime(name, str(sockets.parent))
            if not ownership.process_is_owned(candidate, entry, profile=profile):
                raise SessionError('existing session process ownership changed')
            roots.add(candidate)
        except FileNotFoundError:
            continue
        except PermissionError as exc:
            raise SessionError('existing session runtime ownership is unavailable') from exc
    if len(roots) > 1 or live and not roots:
        raise SessionError('existing session runtime identity is ambiguous')
    if not roots:
        raise SessionError('Legacy session runtime cannot be established; profile retained, use a new session name')
    return next(iter(roots))


def _load(name: str, actor: str) -> dict[str, Any]:
    root = _root(name)
    try:
        _private(state_base())
        _private(root)
        path = root / "session.json"
        if path.is_symlink() or path.stat().st_uid != os.getuid() or path.stat().st_mode & 0o077:
            raise SessionError("session metadata ownership is unverifiable")
        record = json.loads(path.read_text(encoding="utf-8"))
        if (not isinstance(record, dict) or type(record.get("schema_version")) is not int
                or record.get("schema_version") != SCHEMA_VERSION):
            raise SessionError("session metadata version is unsupported")
        if record.get("name") != name or record.get("uid") != os.getuid() or record.get("state") not in _STATES:
            raise SessionError("session metadata identity is unverifiable")
        if record.get("actor") != actor:
            raise SessionError(f"session {name!r} belongs to another actor")
        if (
            type(record.get("last_used_ms")) is not int
            or type(record.get("created_ms")) is not int
            or not isinstance(record.get("processes"), list)
            or any(not isinstance(p, dict) or set(p) != {"pid", "start"}
                   or type(p["pid"]) is not int or p["pid"] < 1
                   or not isinstance(p["start"], str) or not p["start"]
                   for p in record["processes"])
        ):
            raise SessionError("session metadata is invalid")
        _private(root / "profile")
        if 'runtime_root' not in record:
            record['runtime_root'] = str(_legacy_runtime(name, record))
        _validated_runtime(name, record['runtime_root'])
        return record
    except (OSError, ValueError, TypeError) as exc:
        if isinstance(exc, SessionError):
            raise
        raise SessionError(f"session {name!r} metadata is unavailable or invalid") from exc


def _save(name: str, record: dict[str, Any]) -> None:
    root = _root(name)
    temporary = root / f".session-{os.getpid()}.json"
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(record, handle, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(root / "session.json")
        directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)


def _resolved(name: str, record: dict[str, Any]) -> Session:
    runtime = _validated_runtime(name, record['runtime_root'])
    return Session(name, record["actor"], record["state"], _root(name) / "profile", runtime,
                   runtime / "sockets", runtime / "config.json", f"s-{_key(name)}", record["last_used_ms"])


def create(name: str, actor: str | None = None, *, lock: SessionLock | None = None) -> Session:
    actor = actor_identity(actor)
    with session_lock(name, lock=lock):
        _private(state_base().parent, create=True)
        _private(state_base(), create=True)
        root = _root(name)
        try:
            root.mkdir(mode=0o700)
        except FileExistsError as exc:
            raise SessionError(f"session {name!r} already exists; ownership is never implicitly claimed") from exc
        try:
            directory = os.open(root.parent, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
            _private(root / "profile", create=True)
            now = int(time.time() * 1000)
            record = {"schema_version": SCHEMA_VERSION, "name": name, "uid": os.getuid(), "actor": actor,
                      "state": "active", "created_ms": now, "last_used_ms": now, "processes": [],
                      "runtime_root": str(runtime_root(name))}
            _save(name, record)
        except Exception:
            # A failed creation has not launched Chrome or written profile state.
            shutil.rmtree(root)
            raise
        return _resolved(name, record)


def resolve(name: str, actor: str | None = None, *, lock: SessionLock | None = None) -> Session:
    """Resolve approved paths and pause state without launching or changing Chrome."""
    actor = actor_identity(actor)
    with session_lock(name, lock=lock):
        return replace(_resolved(name, _load(name, actor)), lock=lock)


def prepare_runtime(session: Session, *, lock: SessionLock | None = None) -> None:
    """Materialize empty private runtime configuration before an approved launch."""
    actor = actor_identity(session.actor)
    with session_lock(session.name, lock=lock or session.lock):
        approved = _resolved(session.name, _load(session.name, actor))
        if approved != session:
            raise SessionError("runtime preparation requires the current resolved session")
        _prepare_runtime(session)


def _prepare_runtime(session: Session) -> None:
    _private(session.runtime_root.parent.parent, create=True)
    _private(session.runtime_root.parent, create=True)
    _private(session.runtime_root, create=True)
    _private(session.socket_dir, create=True)
    if session.config.is_symlink():
        raise SessionError("session runtime config must not be a symlink")
    if session.config.exists() and (
        session.config.stat().st_uid != os.getuid() or session.config.stat().st_mode & 0o077
    ):
        raise SessionError("session runtime config ownership is unverifiable")
    fd = os.open(session.config, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write("{}\n")


def _processes(session: Session) -> list[tuple[int, str]]:
    return ownership.owned_processes(session.runtime_root, profile=session.profile)


def touch(name: str, actor: str | None = None, *, lock: SessionLock | None = None) -> Session:
    """Persist observed process receipts after use, including failed invocation recovery."""
    actor = actor_identity(actor)
    with session_lock(name, lock=lock):
        record = _load(name, actor)
        session = _resolved(name, record)
        record["last_used_ms"] = int(time.time() * 1000)
        record["processes"] = [{"pid": pid, "start": start} for pid, start in _processes(session)]
        _save(name, record)
        return _resolved(name, record)


@contextmanager
def use(name: str, actor: str | None = None) -> Iterator[Session]:
    """Hold exclusive ownership throughout an automation invocation and its receipt."""
    actor = actor_identity(actor)
    with session_lock(name) as held:
        record = _load(name, actor)
        session = _resolved(name, record)
        session.require_automation()
        if error := _identity_error(session):
            raise SessionError(error)
        # A crashed invocation must not appear idle since an older completed use.
        record["last_used_ms"] = int(time.time() * 1000)
        _save(name, record)
        session = replace(_resolved(name, record), lock=held)
        prepare_runtime(session)
        try:
            yield session
        finally:
            touch(name, actor, lock=held)


def _set_state(name: str, actor: str | None, state: str, lock: SessionLock | None) -> Session:
    actor = actor_identity(actor)
    with session_lock(name, lock=lock):
        record = _load(name, actor)
        if state == "paused" and record["state"] == "closed":
            raise SessionError("closed session must be resumed before pausing")
        record["state"] = state
        if state == "active":
            record["last_used_ms"] = int(time.time() * 1000)
        _save(name, record)
        return _resolved(name, record)


def pause(name: str, actor: str | None = None, *, lock: SessionLock | None = None) -> Session:
    return _set_state(name, actor, "paused", lock)


def resume(name: str, actor: str | None = None, *, lock: SessionLock | None = None) -> Session:
    return _set_state(name, actor, "active", lock)


def _identity_error(session: Session) -> str | None:
    if not session.runtime_root.exists():
        return None
    try:
        _private(session.runtime_root.parent.parent)
        _private(session.runtime_root.parent)
        _private(session.runtime_root)
        _private(session.socket_dir)
        if session.config.is_symlink() or (session.config.exists() and (
            not session.config.is_file() or session.config.stat().st_uid != os.getuid()
            or session.config.stat().st_mode & 0o077
        )):
            return "runtime config ownership is unverifiable"
        pid_path = session.socket_dir / f"{session.daemon_session}.pid"
        if pid_path.is_symlink():
            return "daemon PID ownership is unverifiable"
        if pid_path.exists():
            pid = int(pid_path.read_text().strip())
            if pid < 1:
                return "daemon PID is invalid"
            if ownership.process_start(pid) is not None and not ownership.process_is_owned(
                session.runtime_root, Path("/proc") / str(pid), profile=session.profile
            ):
                return "live daemon ownership is unverifiable"
    except (OSError, ValueError) as exc:
        return f"runtime identity is unverifiable: {exc}"
    return None


def status(name: str, actor: str | None = None, *, lock: SessionLock | None = None) -> dict[str, Any]:
    actor = actor_identity(actor)
    with session_lock(name, lock=lock):
        record = _load(name, actor)
        session = _resolved(name, record)
        error = _identity_error(session)
        processes = _processes(session) if error is None else []
        receipts = {(p.get("pid"), p.get("start")) for p in record["processes"] if isinstance(p, dict)}
        observed = set(processes)
        return {"schema_version": SCHEMA_VERSION, "name": name, "actor": actor, "state": session.state,
                "paused": session.paused, "last_used_ms": session.last_used_ms,
                "runtime_state": "unknown" if error else "running" if processes else "dormant",
                "processes": [{"pid": pid, "start": start} for pid, start in processes],
                "stale_receipts": len(receipts - observed), "error": error}


def list_sessions(actor: str | None = None) -> list[dict[str, Any]]:
    """List only this actor's durable sessions; unknown records are not claimed."""
    actor = actor_identity(actor)
    base = state_base()
    if not base.exists():
        return []
    _private(base)
    result = []
    for root in sorted(base.iterdir()):
        try:
            _private(root)
            path = root / "session.json"
            if path.is_symlink() or path.stat().st_uid != os.getuid() or path.stat().st_mode & 0o077:
                continue
            record = json.loads(path.read_text())
            if not isinstance(record, dict) or record.get("actor") != actor:
                continue
            name = _name(record["name"])
            if root != _root(name):
                continue
            try:
                result.append(status(name, actor))
            except SessionBusy:
                result.append({"name": name, "actor": actor, "runtime_state": "busy"})
            except SessionError as exc:
                result.append({"name": name, "actor": actor, "runtime_state": "unknown", "error": str(exc)})
        except (OSError, ValueError, TypeError, KeyError):
            continue
    return result


def _clean(session: Session) -> list[str]:
    if error := _identity_error(session):
        return [error]
    with contextlib.redirect_stdout(sys.stderr):
        errors = ownership.terminate_owned(session.runtime_root, session.daemon_session, profile=session.profile)
    if errors:
        return errors
    if session.runtime_root.exists():
        try:
            shutil.rmtree(session.runtime_root)
        except OSError as exc:
            return [f"session runtime cleanup failed: {exc}"]
    return []


def close(name: str, actor: str | None = None, *, request: Any = None,
          runner: Callable[[Any, list[str]], subprocess.CompletedProcess[str]] | None = None,
          lock: SessionLock | None = None) -> dict[str, Any]:
    """Close only verified runtime processes, retaining the persistent profile."""
    actor = actor_identity(actor)
    with session_lock(name, lock=lock) as held:
        record = _load(name, actor)
        session = _resolved(name, record)
        errors = []
        warnings = []
        if error := _identity_error(session):
            errors.append(error)
        elif _processes(session) and runner is not None:
            prefix = list(request.launch.prefix) if request is not None else []
            if (
                "--profile" not in prefix
                or prefix[prefix.index("--profile") + 1:][:1] != [str(session.profile)]
                or request.launch.isolation_root != session.runtime_root
            ):
                raise SessionError("close request must use the resolved session profile and runtime")
            try:
                result = runner(request, ["--session", session.daemon_session, "close"])
                if result.returncode:
                    warnings.append(f"graceful close returned {result.returncode}; owned process recovery attempted")
            except (OSError, subprocess.TimeoutExpired) as exc:
                warnings.append(f"graceful close unavailable: {type(exc).__name__}")
        if not errors:
            cleanup_errors = _clean(session)
            if not cleanup_errors:
                errors = []  # Verified fallback establishes the final outcome.
            else:
                errors.extend(cleanup_errors)
        if not errors:
            record["state"] = "closed"
            record["processes"] = []
            _save(name, record)
        return {**status(name, actor, lock=held), "closed": not errors, "errors": errors,
                "warnings": warnings, "profile_retained": True}


def maintenance(actor: str | None = None, *, dry_run: bool = True, idle_ms: int | None = None,
                request_factory: Callable[[Session], Any] | None = None,
                runner: Callable[[Any, list[str]], subprocess.CompletedProcess[str]] | None = None) -> dict[str, Any]:
    """Dry-run by default; active runtimes require an explicit idle threshold."""
    actor = actor_identity(actor)
    if type(dry_run) is not bool:
        raise SessionError("dry_run must be a boolean")
    if idle_ms is not None and (type(idle_ms) is not int or idle_ms < 0):
        raise SessionError("idle_ms must be a nonnegative integer")
    now = int(time.time() * 1000)
    results = []
    for item in list_sessions(actor):
        name = item["name"]
        try:
            with session_lock(name) as held:
                current = status(name, actor, lock=held)
                session = resolve(name, actor, lock=held)
                if current["runtime_state"] == "unknown":
                    results.append({"name": name, "outcome": "unverified", "error": current["error"]})
                    continue
                idle = idle_ms is not None and now - session.last_used_ms >= idle_ms
                candidate = session.runtime_root.exists() and (
                    session.state == "closed" or current["runtime_state"] == "dormant" or idle
                )
                if session.paused:
                    candidate = False  # The human owns this live handoff until explicit resume/close.
                if not candidate:
                    results.append({"name": name, "outcome": "retained"})
                elif dry_run:
                    results.append({"name": name, "outcome": "would_close", "profile_retained": True})
                else:
                    request = request_factory(session) if request_factory else None
                    receipt = close(name, actor, request=request, runner=runner, lock=held)
                    results.append({"name": name, "outcome": "closed" if receipt["closed"] else "incomplete",
                                    "errors": receipt["errors"], "profile_retained": True})
        except SessionBusy:
            results.append({"name": name, "outcome": "busy"})
        except SessionError as exc:
            results.append({"name": name, "outcome": "unverified", "error": str(exc)})
    return {"schema_version": SCHEMA_VERSION, "dry_run": dry_run, "sessions": results}


def operator_inventory() -> list[dict[str, Any]]:
    """Read-only inventory for the local Unix owner's authenticated Runtime UI."""
    base = state_base()
    if not base.exists():
        return []
    _private(base)
    result = []
    for root in sorted(base.iterdir()):
        try:
            _private(root)
            path = root / 'session.json'
            if path.is_symlink():
                continue
            record = json.loads(path.read_text())
            name, actor = _name(record['name']), record['actor']
            record = _load(name, actor)
            session = _resolved(name, record)
            error = _identity_error(session)
            processes = _processes(session) if error is None else []
            result.append({'name':name,'actor':actor,'state':session.state,'paused':session.paused,
                           'runtime_state':'unknown' if error else 'running' if processes else 'dormant',
                           'last_used_ms':session.last_used_ms,'error':error})
        except (OSError, ValueError, TypeError, KeyError):
            continue
    return result
