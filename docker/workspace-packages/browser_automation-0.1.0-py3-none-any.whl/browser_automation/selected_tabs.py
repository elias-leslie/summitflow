"""Opt-in selected Chrome tab authority; no profile discovery or browser launch."""

from __future__ import annotations

import json
import os
import re
import stat
from dataclasses import dataclass, field
from importlib.resources import files
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import httpx

HOST_NAME = "com.summitflow.browser_selected_tabs"
_HANDLE = re.compile(r"^[0-9a-f]{32}$")


class SelectedTabError(ValueError):
    """Selected tab is unavailable or its explicit authority cannot be verified."""


def state_base() -> Path:
    base = Path(os.environ.get("XDG_STATE_HOME", str(Path.home() / ".local/state")))
    if not base.is_absolute():
        raise SelectedTabError("selected-tab state directory must be absolute")
    return base / "browser-automation/selected-tabs"


def private_directory(path: Path) -> None:
    path.mkdir(parents=True, mode=0o700, exist_ok=True)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise SelectedTabError("selected-tab directory must be private and owned by the current user")


def origin(url: str) -> str:
    if not isinstance(url, str) or not url:
        raise SelectedTabError("selected tabs require a regular HTTP or HTTPS origin")
    try:
        parsed = urlsplit(url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError
        host = parsed.hostname.encode("idna").decode("ascii").lower()
        if ":" in host:
            host = f"[{host}]"
        default = 80 if parsed.scheme == "http" else 443
        suffix = f":{parsed.port}" if parsed.port and parsed.port != default else ""
        return f"{parsed.scheme}://{host}{suffix}"
    except (ValueError, UnicodeError) as exc:
        raise SelectedTabError("selected tabs require a regular HTTP or HTTPS origin") from exc


@dataclass(frozen=True)
class SelectedGrant:
    selection: str
    tab_id: int
    origin: str
    target_id: str
    cdp_url: str = field(repr=False)
    control_url: str = field(repr=False)

    def public(self) -> dict[str, Any]:
        return {"selection": self.selection, "tab_id": self.tab_id, "origin": self.origin,
                "target_id": self.target_id, "status": "granted"}


def _read(selection: str) -> SelectedGrant:
    if not _HANDLE.fullmatch(selection):
        raise SelectedTabError("selected-tab handle must be an explicit grant identifier")
    path = state_base() / f"{selection}.json"
    try:
        directory_info = path.parent.lstat()
        if not stat.S_ISDIR(directory_info.st_mode) or directory_info.st_uid != os.getuid() or directory_info.st_mode & 0o077:
            raise SelectedTabError("selected-tab descriptor directory is not private")
        # O_NOFOLLOW plus fstat protects descriptors from symlink substitution.
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, "r", encoding="utf-8") as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077 or info.st_size > 4096:
                raise SelectedTabError("selected-tab descriptor is not private")
            value = json.load(stream)
        if value["schema_version"] != 1 or value["selection"] != selection:
            raise ValueError
        endpoint = urlsplit(value["cdp_url"])
        if endpoint.scheme != "ws" or endpoint.hostname != "127.0.0.1" or not endpoint.port or endpoint.query or endpoint.fragment or endpoint.username or endpoint.password:
            raise ValueError
        if re.fullmatch(r"/[A-Za-z0-9_-]{43}/cdp", endpoint.path) is None:
            raise ValueError
        if type(value["tab_id"]) is not int or value["tab_id"] < 0 or not _HANDLE.fullmatch(value["target_id"]):
            raise ValueError
        granted_origin = origin(value["origin"])
        if granted_origin != value["origin"]:
            raise ValueError
        control_url = f"http://127.0.0.1:{endpoint.port}{endpoint.path[:-3]}status"
        return SelectedGrant(selection, value["tab_id"], granted_origin, value["target_id"], value["cdp_url"], control_url)
    except SelectedTabError:
        raise
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise SelectedTabError("selected-tab grant unavailable; click the extension action to grant again") from exc


def resolve_grant(selection: str) -> SelectedGrant:
    grant = _read(selection)
    try:
        with httpx.Client(trust_env=False, timeout=2) as client:
            reply = client.get(grant.control_url)
            reply.raise_for_status()
            if reply.json() != grant.public():
                raise ValueError
    except (httpx.HTTPError, ValueError) as exc:
        raise SelectedTabError("selected-tab grant expired; click the extension action to grant again") from exc
    return grant


def list_grants() -> list[dict[str, Any]]:
    """List only extension-granted tabs; never enumerate browser targets."""
    result = []
    for path in sorted(state_base().glob("*.json")):
        try:
            result.append(resolve_grant(path.stem).public())
        except SelectedTabError:
            continue
    return result


def revoke_grant(selection: str) -> None:
    # Lazy import keeps package discovery independent of the execution runtime.
    from .selected_execution import revoke

    revoke(selection)


def capabilities() -> dict[str, Any]:
    return {"provider": "selected-chrome-tab", "opt_in": True, "grant": "extension-action",
            "scope": "one tab and exact HTTP(S) origin", "selection_required": True,
            "transport": "chrome.debugger + nativeMessaging + authenticated loopback CDP",
            "supports": ["snapshot", "eval", "click", "fill", "set-value", "select", "upload", "screenshot", "same-origin-navigation", "dialogs"],
            "unsupported": ["other-tabs", "new-tabs", "browser-contexts", "cross-origin-child-targets",
                            "profile-export", "cookies", "downloads", "browser-download-policy", "browser-close"],
            "regrant_on": ["origin-change", "tab-close", "debugger-detach", "extension-restart", "native-host-disconnect"]}


def install_plan(*, extension_id: str, registration_directory: Path, python: Path, destination: Path) -> dict[str, Any]:
    """Reviewable Linux registration payload. This function never writes or installs."""
    if re.fullmatch(r"[a-p]{32}", extension_id) is None:
        raise SelectedTabError("provide the explicitly chosen Chrome extension ID")
    if any(not path.is_absolute() for path in (registration_directory, python, destination)):
        raise SelectedTabError("installation plan requires explicit absolute paths")
    if any("\n" in str(path) or "\r" in str(path) for path in (registration_directory, python, destination)):
        raise SelectedTabError("installation paths must not contain newlines")
    if any(character.isspace() for character in str(python)):
        raise SelectedTabError("native host Python interpreter path must not contain whitespace")
    launcher = destination / "browser-selected-tabs-host"
    # JSON string escaping is not shell escaping. The launcher is Python code.
    launcher_code = f"#!{python}\nfrom browser_automation.native_host import main\nmain()\n"
    return {"dry_run": True, "requires_explicit_install_authorization": True,
            "extension_source": str(files("browser_automation").joinpath("assets/selected-tabs")),
            "files": [{"path": str(launcher), "mode": "0700", "content": launcher_code},
                      {"path": str(registration_directory / f"{HOST_NAME}.json"), "mode": "0600",
                       "content": json.dumps({"name": HOST_NAME, "description": "Selected Chrome tab bridge",
                                              "path": str(launcher), "type": "stdio",
                                              "allowed_origins": [f"chrome-extension://{extension_id}/"]}, indent=2) + "\n"}],
            "grant_instruction": "Load the reviewed extension in the chosen Chrome profile, then click its action on the tab to grant. Click again to revoke."}


def main() -> None:
    """Standalone install-plan command; intentionally no install or enable flag."""
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Review selected-tab native host installation without applying changes")
    commands = parser.add_subparsers(dest="operation", required=True)
    plan = commands.add_parser("install-plan")
    plan.add_argument("--extension-id", required=True)
    plan.add_argument("--registration-directory", type=Path, required=True)
    plan.add_argument("--python", type=Path, required=True)
    plan.add_argument("--destination", type=Path, required=True)
    arguments = parser.parse_args()
    try:
        result = install_plan(extension_id=arguments.extension_id, registration_directory=arguments.registration_directory,
                              python=arguments.python, destination=arguments.destination)
    except SelectedTabError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(2) from None
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
