"""Private Chrome native-messaging host and selected-target CDP transport.

Stdout belongs exclusively to Chrome's binary framing protocol. No request,
URL, page content, credential, or endpoint token is logged.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import secrets
import struct
import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO, Callable
from uuid import uuid4

from .selected_tabs import SelectedGrant, SelectedTabError, origin, private_directory, state_base

MAX_MESSAGE = 1024 * 1024
COMMAND_TIMEOUT = 15
MAX_CLIENT_COMMANDS = 8
_DOMAINS = {"Accessibility", "DOM", "DOMSnapshot", "CSS", "Runtime", "Page", "Input", "Emulation", "Network", "Log", "Console"}
_DENIED = {"Page.close", "Page.crash", "Page.addScriptToEvaluateOnNewDocument", "Page.setBypassCSP", "Page.setDownloadBehavior",
           "Network.getCookies", "Network.getAllCookies", "Network.setCookie", "Network.setCookies", "Network.deleteCookies",
           "Network.clearBrowserCookies", "Network.clearBrowserCache", "Network.setCookieControls", "Network.getRequestPostData"}


def _renderer_command(method: str) -> bool:
    return method.split(".", 1)[0] in {"Runtime", "DOM", "DOMSnapshot", "CSS", "Accessibility", "Input", "Emulation"} or method in {
        "Page.navigate", "Page.reload", "Page.navigateToHistoryEntry", "Page.getFrameTree", "Page.getLayoutMetrics",
        "Page.captureScreenshot", "Page.captureSnapshot", "Page.printToPDF", "Page.createIsolatedWorld",
    }


def read_message(stream: BinaryIO) -> dict[str, Any] | None:
    def exact(size: int) -> bytes:
        chunks = bytearray()
        while len(chunks) < size:
            chunk = stream.read(size - len(chunks))
            if not chunk:
                raise SelectedTabError("truncated native message")
            chunks.extend(chunk)
        return bytes(chunks)

    first = stream.read(4)
    if not first:
        return None
    if len(first) < 4:
        first += exact(4 - len(first))
    length = struct.unpack("=I", first)[0]
    if not 0 < length <= MAX_MESSAGE:
        raise SelectedTabError("native message exceeds the bridge size limit")
    try:
        value = json.loads(exact(length).decode("utf-8"))
    except (UnicodeError, ValueError) as exc:
        raise SelectedTabError("invalid native message") from exc
    if not isinstance(value, dict):
        raise SelectedTabError("native message must be an object")
    return value


def write_message(stream: BinaryIO, value: dict[str, Any]) -> None:
    raw = json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    if not 0 < len(raw) <= MAX_MESSAGE:
        raise SelectedTabError("native message exceeds the bridge size limit")
    stream.write(struct.pack("=I", len(raw)) + raw)
    stream.flush()


@dataclass
class TabAuthority:
    selection: str
    tab_id: int
    origin: str
    target_id: str
    url: str
    title: str
    live: bool = True

    @classmethod
    def grant(cls, message: dict[str, Any]) -> TabAuthority:
        if type(message.get("tab_id")) is not int or message["tab_id"] < 0:
            raise SelectedTabError("grant requires an explicit tab ID")
        granted_origin = origin(message.get("url", ""))
        if message.get("origin") != granted_origin:
            raise SelectedTabError("grant origin mismatch")
        return cls(uuid4().hex, message["tab_id"], granted_origin, uuid4().hex,
                   message["url"], str(message.get("title", ""))[:512])

    def target(self) -> dict[str, Any]:
        return {"targetId": self.target_id, "type": "page", "title": self.title,
                "url": self.url, "attached": True, "canAccessOpener": False}

    def validate_command(self, message: dict[str, Any], session: str | None) -> None:
        if not self.live:
            raise SelectedTabError("selected-tab grant revoked; user regrant required")
        method = message.get("method")
        params = message.get("params", {})
        if type(message.get("id")) is not int or not isinstance(method, str) or not isinstance(params, dict):
            raise SelectedTabError("malformed CDP command")
        if message.get("sessionId") is not None and message.get("sessionId") != session:
            raise SelectedTabError("CDP session is outside the selected grant")
        if "targetId" in params and params["targetId"] != self.target_id:
            raise SelectedTabError("target is outside the selected grant")
        if method == "Page.navigate" and origin(params.get("url", "")) != self.origin:
            raise SelectedTabError("navigation outside the granted origin requires user regrant")
        if method == "Target.setAutoAttach" and params.get("flatten") is not True:
            raise SelectedTabError("only selected-target flat CDP sessions are supported")
        safe_virtual = {"Target.setDiscoverTargets", "Target.setAutoAttach", "Target.getTargets",
                        "Target.getTargetInfo", "Target.attachToTarget", "Target.detachFromTarget",
                        "Browser.getVersion", "BrowserAutomation.revokeGrant"}
        if method not in safe_virtual and (method.split(".", 1)[0] not in _DOMAINS or method in _DENIED):
            raise SelectedTabError("CDP method is unsupported by selected-tab authority")
        if method == "Target.attachToTarget" and params.get("targetId") != self.target_id:
            raise SelectedTabError("attach requires the explicitly selected target")


class NativeBridge:
    def __init__(self, send: Callable[[dict[str, Any]], None], directory: Path | None = None):
        self.send = send
        self.directory = directory if directory is not None else state_base()
        self.authority: TabAuthority | None = None
        self.grant: SelectedGrant | None = None
        self.server: Any = None
        self.client: Any = None
        self.session: str | None = None
        self.pending: dict[str, asyncio.Future[dict[str, Any]]] = {}
        self.pending_methods: dict[str, str] = {}
        self.dialog_open = False
        self.stopped = asyncio.Event()

    async def start(self, message: dict[str, Any]) -> None:
        from websockets.asyncio.server import serve

        if self.authority is not None:
            raise SelectedTabError("one native connection permits one user grant")
        authority = TabAuthority.grant(message)
        private_directory(self.directory)
        self.authority = authority
        token = secrets.token_urlsafe(32)
        logger = logging.Logger("selected-tabs-native")
        logger.disabled = True
        self.server = await serve(self._client, "127.0.0.1", 0, origins=[None], max_size=MAX_MESSAGE,
                                  max_queue=8, ping_interval=20, ping_timeout=10, close_timeout=1,
                                  process_request=self._http, logger=logger)
        port = next(iter(self.server.sockets)).getsockname()[1]
        self.grant = SelectedGrant(authority.selection, authority.tab_id, authority.origin, authority.target_id,
                                   f"ws://127.0.0.1:{port}/{token}/cdp",
                                   f"http://127.0.0.1:{port}/{token}/status")
        descriptor = {"schema_version": 1, **self.grant.public(), "cdp_url": self.grant.cdp_url}
        path = self.directory / f"{authority.selection}.json"
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(descriptor, stream)
        self.send({"type": "ready", **self.grant.public()})

    async def _http(self, connection: Any, request: Any) -> Any:
        from urllib.parse import urlsplit

        if self.grant is None or self.authority is None or not self.authority.live:
            return connection.respond(410, "Grant unavailable")
        endpoint = urlsplit(self.grant.cdp_url)
        # No proxy trust, no arbitrary Host, no browser-origin websocket clients.
        if request.headers.get("Host") != f"127.0.0.1:{endpoint.port}" or request.headers.get("Origin"):
            return connection.respond(403, "Local authenticated clients only")
        if request.path == urlsplit(self.grant.control_url).path:
            return connection.respond(200, json.dumps(self.grant.public()))
        if not secrets.compare_digest(request.path, endpoint.path):
            return connection.respond(403, "Grant unavailable")
        if self.client is not None:
            return connection.respond(409, "Selected tab is owned by another client")
        return None

    async def _client(self, connection: Any) -> None:
        # The second check closes the handshake race between two local clients.
        if self.client is not None:
            await connection.close(1008, "Selected tab is busy")
            return
        self.client = connection
        self.session = None
        tasks: set[asyncio.Task[None]] = set()

        def completed(task: asyncio.Task[None]) -> None:
            tasks.discard(task)
            if not task.cancelled():
                task.exception()  # Consume disconnect errors without transport logging.

        async def reply(request: Any) -> None:
            revoke_control = False
            try:
                try:
                    result = await self.command(request)
                    if request.get("method") == "BrowserAutomation.revokeGrant":
                        revoke_control = True
                        await self.revoke("user-revoked", shutdown=False)
                    response = {"id": request["id"], "result": result}
                except (SelectedTabError, ValueError, TypeError) as exc:
                    response = {"id": request.get("id", 0) if isinstance(request, dict) else 0,
                                "error": {"code": -32000, "message": str(exc) if isinstance(exc, SelectedTabError) else "invalid CDP command"}}
                if isinstance(request, dict) and "sessionId" in request:
                    response["sessionId"] = request["sessionId"]
                await connection.send(json.dumps(response))
            finally:
                if revoke_control:
                    self._finish_revocation("user-revoked")

        try:
            async for raw in connection:
                request: Any = None
                try:
                    request = json.loads(raw)
                    if not isinstance(request, dict):
                        raise SelectedTabError("CDP command must be an object")
                    # Reserve one slot for dialog response/revocation. Reading never
                    # waits on renderer execution, which Chrome pauses under modals.
                    control = request.get("method") in {"Page.handleJavaScriptDialog", "BrowserAutomation.revokeGrant"}
                    limit = MAX_CLIENT_COMMANDS if control else MAX_CLIENT_COMMANDS - 1
                    if len(tasks) >= limit:
                        raise SelectedTabError("selected-tab command queue is full")
                except (SelectedTabError, ValueError, TypeError) as exc:
                    await connection.send(json.dumps({"id": request.get("id", 0) if isinstance(request, dict) else 0,
                        "error": {"code": -32000, "message": str(exc) if isinstance(exc, SelectedTabError) else "invalid CDP command"}}))
                    continue
                task = asyncio.create_task(reply(request))
                tasks.add(task)
                task.add_done_callback(completed)
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            self.client = None
            self.session = None

    async def command(self, request: dict[str, Any]) -> dict[str, Any]:
        authority = self.authority
        if authority is None:
            raise SelectedTabError("no explicitly granted selected tab")
        authority.validate_command(request, self.session)
        method = request["method"]
        params = request.get("params", {})
        if method == "Target.getTargets":
            return {"targetInfos": [authority.target()]}
        if method == "Target.getTargetInfo":
            return {"targetInfo": authority.target()}
        if method == "Target.attachToTarget":
            if params.get("flatten") is not True:
                raise SelectedTabError("selected target requires flatten:true")
            self.session = self.session or uuid4().hex
            return {"sessionId": self.session}
        if method == "Target.detachFromTarget":
            if params.get("sessionId") != self.session:
                raise SelectedTabError("detach requires the selected CDP session")
            self.session = None
            return {}
        if method in {"Target.setDiscoverTargets", "Target.setAutoAttach", "BrowserAutomation.revokeGrant"}:
            # Browser-level discovery/autoattach are virtual and never sent to Chrome.
            # Cross-origin child targets remain unsupported; no hidden attachment.
            return {}
        if method == "Browser.getVersion":
            return {"protocolVersion": "1.3", "product": "SelectedChromeTab/1", "revision": "",
                    "userAgent": "", "jsVersion": ""}
        if request.get("sessionId") != self.session or not self.session:
            raise SelectedTabError("page commands require the attached selected session")
        if self.dialog_open and _renderer_command(method):
            raise SelectedTabError("selected-tab dialog is open; respond to the dialog before page commands")
        command_id = uuid4().hex
        future = asyncio.get_running_loop().create_future()
        self.pending[command_id] = future
        self.pending_methods[command_id] = method
        try:
            self.send({"type": "command", "request_id": command_id, "tab_id": authority.tab_id,
                       "origin": authority.origin, "method": method, "params": params})
            reply = await asyncio.wait_for(future, COMMAND_TIMEOUT)
            if not authority.live:
                raise SelectedTabError("grant revoked while command was in flight")
            if reply.get("error"):
                raise SelectedTabError("selected-tab debugger command failed or is unsupported")
            return reply.get("result", {})
        except TimeoutError as exc:
            if self.dialog_open:
                raise SelectedTabError("selected-tab command paused by an open dialog; respond to the dialog") from exc
            await self.revoke("native-command-timeout")
            raise SelectedTabError("selected-tab command timed out; user regrant required") from exc
        finally:
            self.pending.pop(command_id, None)
            self.pending_methods.pop(command_id, None)

    async def receive(self, message: dict[str, Any]) -> None:
        kind = message.get("type")
        if kind == "grant":
            await self.start(message)
            return
        authority = self.authority
        if authority is None or not authority.live or message.get("tab_id") != authority.tab_id:
            await self.revoke("invalid-native-authority")
            return
        if kind == "result":
            request_id = message.get("request_id")
            future = self.pending.get(request_id) if isinstance(request_id, str) else None
            if future is not None and not future.done():
                future.set_result(message)
        elif kind == "revoke":
            await self.revoke("extension-revoked")
        elif kind == "event":
            if not isinstance(message.get("method"), str) or not isinstance(message.get("params", {}), dict):
                await self.revoke("invalid-native-event")
                return
            if message["method"] == "Page.javascriptDialogOpening":
                params = message.get("params", {})
                try:
                    if params.get("type") not in {"alert", "confirm", "prompt", "beforeunload"} or origin(params.get("url", "")) != authority.origin:
                        raise SelectedTabError("dialog outside selected origin")
                except SelectedTabError:
                    await self.revoke("invalid-native-dialog")
                    return
                self.dialog_open = True
                for identifier, future in self.pending.items():
                    if not future.done() and _renderer_command(self.pending_methods[identifier]):
                        future.set_exception(SelectedTabError("selected-tab dialog opened; respond before page evidence or commands"))
            elif message["method"] == "Page.javascriptDialogClosed":
                self.dialog_open = False
            if message.get("method") == "Page.frameNavigated":
                frame = message.get("params", {}).get("frame", {})
                if not isinstance(frame, dict):
                    await self.revoke("invalid-native-frame")
                    return
                if not frame.get("parentId"):
                    try:
                        if origin(frame.get("url", "")) != authority.origin:
                            await self.revoke("origin-changed")
                            return
                    except SelectedTabError:
                        await self.revoke("origin-changed")
                        return
                    authority.url = frame["url"]
            if self.client is not None and self.session:
                await self.client.send(json.dumps({"method": message["method"], "params": message.get("params", {}),
                                                   "sessionId": self.session}))
        else:
            await self.revoke("invalid-native-message")

    def _finish_revocation(self, reason: str) -> None:
        if self.authority:
            try:
                self.send({"type": "revoke", "tab_id": self.authority.tab_id, "reason": reason})
            except (OSError, SelectedTabError):
                pass
        if self.server:
            self.server.close()
        self.stopped.set()

    async def revoke(self, reason: str, *, shutdown: bool = True) -> None:
        if self.authority:
            self.authority.live = False
        for future in self.pending.values():
            if not future.done():
                future.set_exception(SelectedTabError("selected-tab grant revoked; user regrant required"))
        if self.grant:
            (self.directory / f"{self.grant.selection}.json").unlink(missing_ok=True)
            # This grant owns an optional agent-browser IPC namespace, never Chrome's profile.
            from .selected_execution import cleanup_runtime
            await asyncio.to_thread(cleanup_runtime, self.grant.selection)
        if shutdown:
            self._finish_revocation(reason)

    async def close(self) -> None:
        await self.revoke("native-host-disconnected")
        if self.server:
            await self.server.wait_closed()


async def _run(input_stream: BinaryIO, output_stream: BinaryIO) -> None:
    loop = asyncio.get_running_loop()
    incoming: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue(maxsize=8)
    output_lock = threading.Lock()

    def send(value: dict[str, Any]) -> None:
        with output_lock:
            write_message(output_stream, value)

    def reader() -> None:
        try:
            while (message := read_message(input_stream)) is not None:
                asyncio.run_coroutine_threadsafe(incoming.put(message), loop).result()
        except (SelectedTabError, OSError):
            pass
        finally:
            asyncio.run_coroutine_threadsafe(incoming.put(None), loop)

    thread = threading.Thread(target=reader, daemon=True)
    bridge = NativeBridge(send)
    thread.start()
    try:
        while not bridge.stopped.is_set():
            next_message = asyncio.create_task(incoming.get())
            stopped = asyncio.create_task(bridge.stopped.wait())
            done, waiting = await asyncio.wait({next_message, stopped}, return_when=asyncio.FIRST_COMPLETED)
            for task in waiting:
                task.cancel()
            if next_message not in done:
                break
            message = next_message.result()
            if message is None:
                break
            await bridge.receive(message)
    finally:
        await bridge.close()


def main() -> None:
    try:
        asyncio.run(_run(sys.stdin.buffer, sys.stdout.buffer))
    except (SelectedTabError, OSError):
        # Chrome owns stdout. Fail closed without printing potentially sensitive exception data.
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
