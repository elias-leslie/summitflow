"""Supported browser automation owner."""

