"""Validation for owner-versioned operations; no shell or launch policy parsing."""
from __future__ import annotations

from typing import Any

_OPERATIONS = {
    "capabilities": {"topic"}, "help": {"command"},
    "observe": {"selector", "interactive", "compact", "delta", "full", "depth", "max_chars", "screenshot"},
    "run": {"actions", "postconditions", "observation", "screenshot", "binding", "max_chars"},
    "extract": {"fields", "binding", "max_chars"},
    "session": {"action", "name", "dry_run", "idle_ms", "all"},
    "workflow": {"action", "definition", "parameters", "run_id", "resolution", "output"},
    "selected-tabs": {"action", "handle"},
}
_GLOBALS = {"--session", "--profile", "--idle-timeout", "--cdp", "--config", "--executable-path", "--engine", "--headed", "--provider", "--auto-connect", "--extensions", "--args", "--proxy", "--restore", "--pin-tab", "--no-pin-tab"}


def _object(value: Any, allowed: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) - allowed:
        raise ValueError(f"{label} must be an object with only {sorted(allowed)}")
    return value


def _text(value: Any, label: str, *, nullable: bool = False) -> None:
    if nullable and value is None:
        return
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} must be a non-empty string")


def _binding(value: Any) -> None:
    if value is None:
        return
    value = _object(value, {"session", "target_id", "document_id"}, "binding")
    if set(value) != {"session", "target_id", "document_id"}:
        raise ValueError("binding requires session, target_id, document_id from an observation")
    _text(value["session"], "binding.session")
    _text(value["document_id"], "binding.document_id")
    _text(value["target_id"], "binding.target_id", nullable=True)


def validate_payload(operation: str, value: Any) -> dict[str, Any]:
    value = _object(value, _OPERATIONS[operation], f"{operation} payload")
    if operation in {"observe", "run", "extract"} and "max_chars" in value:
        if type(value["max_chars"]) is not int or value["max_chars"] <= 0:
            raise ValueError(f"{operation}.max_chars must be a positive integer")
    if operation == "selected-tabs":
        if value.get('action') not in {'list','capabilities','revoke'}:
            raise ValueError('selected-tabs.action is unsupported')
        if value['action']=='revoke':
            _text(value.get('handle'),'selected-tabs.handle')
    elif operation == "workflow":
        if value.get("action") not in {"run", "resume", "cancel", "status", "record-start", "record-stop"}:
            raise ValueError("workflow.action is unsupported")
        _text(value.get("run_id"), "workflow.run_id")
        if value.get("action") == "run" and not isinstance(value.get("definition"), dict):
            raise ValueError("workflow.definition must be an object")
        if not isinstance(value.get("parameters", {}), dict):
            raise ValueError("workflow.parameters must be an object")
        _text(value.get("output"), "workflow.output", nullable=True)
        if value.get("resolution") is not None:
            resolution = _object(value["resolution"], {"step", "outcome"}, "workflow.resolution")
            _text(resolution.get("step"), "resolution.step")
            if resolution.get("outcome") not in {"completed", "retry"}:
                raise ValueError("resolution.outcome must be completed or retry")
    elif operation == "session":
        if value.get("action") not in {"create", "list", "status", "pause", "resume", "close", "maintenance", "view", "lease"}:
            raise ValueError("session.action is unsupported")
        if value["action"] not in {"list", "maintenance"}:
            _text(value.get("name"), "session.name")
        if "dry_run" in value and type(value["dry_run"]) is not bool:
            raise ValueError("session.dry_run must be a boolean")
        if "all" in value and type(value["all"]) is not bool:
            raise ValueError("session.all must be a boolean")
        if value.get("idle_ms") is not None and (type(value["idle_ms"]) is not int or value["idle_ms"] < 0):
            raise ValueError("session.idle_ms must be a nonnegative integer or null")
    elif operation == "capabilities":
        _text(value.get("topic"), "topic", nullable=True)
    elif operation == "help":
        command = value.get("command")
        if not isinstance(command, list) or not command or any(not isinstance(x, str) or not x or x.startswith("-") for x in command):
            raise ValueError("help.command must be a non-empty command path array")
    elif operation == "observe":
        if "depth" in value and (type(value["depth"]) is not int or value["depth"] < 0):
            raise ValueError("observe.depth must be a nonnegative integer")
        for name in ("selector", "screenshot"):
            _text(value.get(name), name, nullable=True)
        for name in ("interactive", "compact", "delta", "full"):
            if name in value and type(value[name]) is not bool:
                raise ValueError(f"observe.{name} must be a boolean")
    elif operation == "run":
        actions = value.get("actions")
        if not isinstance(actions, list) or not actions:
            raise ValueError("run.actions must be a non-empty array of argument arrays")
        for action in actions:
            if not isinstance(action, list) or not action or any(not isinstance(x, str) for x in action) or not action[0] or action[0].startswith("-"):
                raise ValueError("each action must be a non-empty command argument array")
            if any(x.split("=", 1)[0] in _GLOBALS for x in action) or action[0] in {"batch", "connect", "chat", "confirm", "deny"} or action[:2] == ["close", "--all"]:
                raise ValueError("actions cannot change managed launch/session authority or nest batches")
        conditions = value.get("postconditions", [])
        if not isinstance(conditions, list):
            raise ValueError("postconditions must be an array")
        for condition in conditions:
            condition = _object(condition, {"kind", "value", "timeout_ms"}, "postcondition")
            if condition.get("kind") not in {"text", "selector", "url", "fn", "network"}:
                raise ValueError("postcondition.kind must be text, selector, url, fn, or network")
            _text(condition.get("value"), "postcondition.value")
            if "timeout_ms" in condition and (type(condition["timeout_ms"]) is not int or condition["timeout_ms"] <= 0):
                raise ValueError("postcondition.timeout_ms must be a positive integer")
        if value.get("observation") is not None:
            validate_payload("observe", value["observation"])
        _text(value.get("screenshot"), "screenshot", nullable=True)
        _binding(value.get("binding"))
    elif operation == "extract":
        fields = value.get("fields")
        if not isinstance(fields, dict) or not fields:
            raise ValueError("extract.fields must be a non-empty field map")
        for name, field in fields.items():
            _text(name, "field name")
            field = _object(field, {"selector", "attribute", "multiple", "type", "required"}, f"field {name}")
            _text(field.get("selector"), "field.selector")
            _text(field.get("attribute"), "field.attribute", nullable=True)
            if field.get("type", "string") not in {"string", "number", "boolean"}:
                raise ValueError("field.type must be string, number, or boolean")
            for option in ("multiple", "required"):
                if option in field and type(field[option]) is not bool:
                    raise ValueError(f"field.{option} must be boolean")
        _binding(value.get("binding"))
    return value
