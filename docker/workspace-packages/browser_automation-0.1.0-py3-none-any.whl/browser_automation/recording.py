"""Opt-in semantic recording of acknowledged managed actions, without auth data."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any
from uuid import uuid4

from . import sessions
from .contract import BrowserRequest
from .workflows import _SENSITIVE, validate_definition


def _read(name: str, *, lock=None) -> tuple[Path, dict[str, Any] | None]:
    session = sessions.resolve(name,lock=lock)
    path = session.profile.parent / 'recording.json'
    if not path.exists():
        return path, None
    if path.is_symlink() or path.stat().st_uid != os.getuid() or path.stat().st_mode & 0o077:
        raise ValueError('Recording ownership is unverifiable')
    record = json.loads(path.read_text())
    if record.get('actor') != sessions.actor_identity():
        raise ValueError('Recording belongs to a different actor')
    return path, record


def _save(path: Path, record: dict[str,Any]) -> None:
    tmp = path.with_name(path.name + '.' + uuid4().hex)
    fd = os.open(tmp,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    try:
        with os.fdopen(fd,'w') as stream:
            json.dump(record,stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp,path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        tmp.unlink(missing_ok=True)


def _parameter(record: dict[str, Any], preferred: str) -> str:
    name = re.sub(r'[^a-z0-9_]+', '_', preferred.lower()).strip('_') or 'input'
    if not name[0].isalpha():
        name = 'input_' + name
    if _SENSITIVE.search(name):
        name = 'input'
    parameters = record.setdefault('parameters', {})
    base, suffix = name, 2
    while name in parameters:
        name = f'{base}_{suffix}'
        suffix += 1
    parameters[name] = {'type': 'string', 'required': True}
    return '{{' + name + '}}'


def _parameterize(action: list[str], record: dict[str, Any], name: str) -> list[str]:
    indices: range | list[int] = []
    if action[0] in {'fill', 'set-value', 'type', 'select', 'upload', 'download'} and len(action) > 2:
        indices = range(2, len(action)) if action[0] in {'select', 'upload'} else [2]
        if action[0] == 'download' or name.startswith('input_') and action[0] in {'select', 'upload'}:
            name = {'select':'select_value', 'upload':'upload_path', 'download':'download_path'}[action[0]]
    elif action[0] == 'find' and len(action) > 4 and action[3] == 'fill':
        name = action[2] if action[1] != 'role' else name
        indices = [4]
    elif action[0] == 'keyboard' and len(action) > 2 and action[1] in {'type', 'inserttext'}:
        indices = [2]
    elif action[0] in {'open', 'goto', 'navigate'} and len(action) > 1:
        name, indices = 'navigation_url', [1]
    elif action[:2] == ['dialog', 'accept'] and len(action) > 2:
        name, indices = 'dialog_reply', [2]
    for index in indices:
        action[index] = _parameter(record, name)
    return action


def _postconditions(receipt: dict[str, Any], record: dict[str, Any]) -> list[dict[str, Any]]:
    conditions = []
    for item in receipt.get('postconditions', []):
        if not item.get('verified'):
            continue
        condition = dict(item['condition'])
        if condition['kind'] == 'selector':
            if _SENSITIVE.search(condition['value']):
                record['omitted'] += 1
                continue
        else:
            # A later assertion may embed an earlier input in arbitrary text or
            # JavaScript. Keep the asserted kind and timeout, but never persist
            # the value or a mapping of entered values to recover it later.
            condition['value'] = _parameter(record, 'assertion_' + condition['kind'])
        conditions.append(condition)
    return conditions


def _metadata(request: BrowserRequest, receipt: dict[str, Any], record: dict[str, Any],
              step: dict[str, Any] | None, *, blocked: bool) -> dict[str, Any] | None:
    payload = request.payload or {}
    requested_options = payload if request.operation == 'observe' else payload.get('observation')
    requested_observation = isinstance(requested_options, dict)
    options: dict[str, Any] = requested_options if isinstance(requested_options, dict) else {}
    top_screenshot = payload.get('screenshot') if request.operation != 'observe' else None
    requested_screenshot = top_screenshot or options.get('screenshot')
    if not requested_observation and not requested_screenshot:
        return step
    safe = not blocked and not record.get('pending_dialog') and receipt.get('status') == 'complete' and not _SENSITIVE.search(options.get('selector') or '')
    metadata: dict[str, Any] = {}
    if requested_observation:
        selector = options.get('selector') or ''
        if safe and isinstance(receipt.get('observation'), dict) and receipt.get('observation_binding') != 'refresh_required' and not _SENSITIVE.search(selector) and not re.search(r'@e\d+\b', selector):
            metadata['observation'] = {key:value for key,value in options.items() if key in {'selector', 'interactive', 'compact', 'delta', 'full', 'depth', 'max_chars'}}
            if 'max_chars' in payload:
                metadata['observation']['max_chars'] = payload['max_chars']
        else:
            record['omitted'] += 1
    if requested_screenshot:
        from .engine import _screenshot_complete
        artifact = receipt.get('screenshot')
        if safe and isinstance(artifact, str) and _screenshot_complete(artifact, None):
            parameter = _parameter(record, 'screenshot_path')
            if top_screenshot or 'observation' not in metadata:
                metadata['screenshot'] = parameter
            if options.get('screenshot') and 'observation' in metadata:
                metadata['observation']['screenshot'] = parameter
        else:
            record['omitted'] += 1
    if metadata:
        if step is None:
            # Workflow steps are structured runs. A read-only URL command anchors
            # explicitly requested evidence without repeating a completed write.
            step = {'id':f'step-{len(record["steps"])+1}', 'actions':[['get', 'url']], 'effect':'read'}
            record['steps'].append(step)
        step.update(metadata)
    return step


def append(request: BrowserRequest, receipt: dict[str,Any], *, session: sessions.Session, runner=None) -> None:
    path, record = _read(session.name,lock=session.lock)
    if not record or not record.get('active'):
        return
    observation = receipt.get('observation',{})
    snapshot = observation.get('snapshot', {}) if isinstance(observation, dict) else {}
    refs = {}
    if isinstance(observation, dict):
        refs = observation.get('refs', {}) or (snapshot.get('refs', {}) if isinstance(snapshot, dict) else {})
    # Actions refer to the preceding observation. A post-action observation can
    # reuse the same transient ref for a different element after navigation.
    action_refs = record['refs'] or refs
    payload = request.payload or {}
    blocked_metadata = session.state != 'active' or any(_SENSITIVE.search(ref.get('name', '')) for ref in (refs or action_refs).values() if isinstance(ref, dict))
    last_step: dict[str, Any] | None = None
    for result in receipt.get('completed',[]):
        action = list(payload['actions'][result['index']])
        parameter_name = f'input_{len(record["steps"])+1}'
        if action[0] in {'auth','cookies','storage','eval','clipboard','get','wait','snapshot','screenshot','close','tab','network','trace'}:
            if action[0] in {'auth', 'cookies', 'storage', 'eval', 'clipboard'}:
                blocked_metadata = True
            record['omitted']+=1
            continue
        if len(action)>1 and action[1].startswith('@e'):
            ref = action_refs.get(action[1][1:])
            if ref and ref.get('name'):
                parameter_name = ref['name']
            if ref and ref.get('role') and ref.get('name') and action[0] in {'click','fill','check','hover'}:
                action = ['find','role',ref['role'],action[0],*action[2:],'--name',ref['name'],'--exact']
            elif runner is not None:
                from .structured import _batch
                rows,error = _batch(request,runner,[['get','attr',action[1],'id'],['get','attr',action[1],'name']])
                candidates = []
                if not error:
                    for attribute,row in zip(('id','name'),rows):
                        value = row.get('result',{}).get('value')
                        if row['success'] and isinstance(value,str) and value:
                            candidates.append(f'[{attribute}={json.dumps(value)}]')
                resolved = None
                for candidate in candidates:
                    counts,count_error = _batch(request,runner,[['get','count',candidate]])
                    if not count_error and counts and counts[0]['success'] and counts[0].get('result',{}).get('count')==1:
                        resolved = candidate
                        break
                if resolved:
                    action[1] = resolved
                else:
                    record['omitted']+=1
                    continue
            else:
                record['omitted']+=1
                continue
        # Test control identity separately from entered content. Dynamic values
        # are parameterized even when they happen to contain sensitive words.
        if action[0] in {'fill', 'set-value', 'type', 'select', 'upload', 'download'}:
            identity = action[:2]
        elif action[0] == 'find' and len(action)>4 and action[3]=='fill':
            identity = action[:4] + action[5:]
        elif action[0] in {'open', 'goto', 'navigate'}:
            identity = action[:1] + action[2:]
        elif action[0] == 'keyboard' and action[1] in {'type', 'inserttext'} or action[:2] == ['dialog', 'accept']:
            identity = action[:2]
        else:
            identity = action
        if _SENSITIVE.search(parameter_name) or any(_SENSITIVE.search(argument) for argument in identity) or any(argument in {'--headers', '--init-script'} for argument in action):
            blocked_metadata = True
            record['omitted']+=1
            continue
        pending = record.get('pending_dialog')
        step: dict[str, Any]
        if action[0] == 'dialog':
            if action[1] not in {'accept', 'dismiss'}:
                record['omitted'] += 1
                continue
            recovery = receipt.get('dialog_recovery', {})
            binding = receipt.get('binding') or {}
            target = recovery.get('target_id') or binding.get('target_id')
            verified_after = recovery.get('document_verified_after') or receipt.get('status') == 'complete' and bool(binding.get('document_id'))
            handled = isinstance(result.get('result'), dict) and result['result'].get('handled') is True
            if not pending or not pending.get('target_id') or target != pending['target_id'] or not verified_after or not handled:
                record['omitted'] += 1
                continue
            step = record['steps'][-1]
            if step['id'] != pending['step_id']:
                record['omitted'] += 1
                continue
            step['actions'].append(_parameterize(action, record, parameter_name))
            record.pop('pending_dialog')
        else:
            step = {'id':f'step-{len(record["steps"])+1}','actions':[_parameterize(action, record, parameter_name)],'effect':'write'}
            record['steps'].append(step)
        last_step = step
        if isinstance(result.get('result'), dict) and result['result'].get('dialogOpened'):
            binding = receipt.get('binding') or {}
            record['pending_dialog'] = {'step_id':step['id'], 'target_id':binding.get('target_id')}
    last_step = _metadata(request, receipt, record, last_step, blocked=blocked_metadata)
    if not record.get('pending_dialog'):
        conditions = _postconditions(receipt, record)
        if conditions and (last_step is not None or record['steps']):
            step = last_step if last_step is not None else record['steps'][-1]
            step.setdefault('postconditions', []).extend(conditions)
    if refs:
        record['refs'] = {key:{field:value[field] for field in ('role', 'name') if field in value} for key,value in refs.items() if isinstance(value,dict)}
    _save(path,record)


def execute_recording(request: BrowserRequest, session: sessions.Session) -> int:
    payload = request.payload or {}
    path, record = _read(session.name,lock=session.lock)
    if payload['action']=='record-start':
        if record and record.get('active'):
            raise ValueError('A recording is already active; finish it before another')
        record = {'schema_version':1,'actor':session.actor,'run_id':payload['run_id'],'active':True,'steps':[],'refs':{},'omitted':0}
        _save(path,record)
        print(json.dumps({'schema_version':1,'status':'recording','run_id':record['run_id'],'session':session.name}))
        return 0
    if not record or record['run_id'] != payload['run_id'] or not record.get('active'):
        raise ValueError('No matching active recording')
    if record.get('pending_dialog'):
        raise ValueError('Recording has an unresolved dialog; acknowledge accept or dismiss on the original target before export')
    parameters = payload.get('parameters',{})
    if any(_SENSITIVE.search(name) for name in parameters):
        raise ValueError('Sensitive values cannot be workflow parameters')
    def substitute(value):
        if isinstance(value,str):
            for name, parameter in parameters.items():
                if value==str(parameter):
                    return '{{'+name+'}}'
        elif isinstance(value,list):
            return [substitute(item) for item in value]
        elif isinstance(value,dict):
            return {key:substitute(item) for key,item in value.items()}
        return value
    specification = {**record.get('parameters',{}),**{name:{'type':'boolean' if type(value) is bool else 'number' if type(value) in {int,float} else 'string'} for name,value in parameters.items()}}
    definition = {'schema_version':1,'name':record['run_id'],'parameters':specification,'steps':substitute(record['steps'])}
    validation_values = {name:False if spec['type']=='boolean' else 0 if spec['type']=='number' else 'parameter' for name,spec in specification.items()}
    validate_definition(definition,{**validation_values,**parameters})
    output = Path(payload.get('output') or (request.root / '.dev-tools' / f'workflow-{uuid4().hex[:12]}.json'))
    if not output.is_absolute():
        output = request.root / output
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x',encoding='utf-8') as stream:
        json.dump(definition,stream,indent=2)
        stream.write('\n')
    record['active']=False
    _save(path,record)
    print(json.dumps({'schema_version':1,'status':'recorded','run_id':record['run_id'],'session':session.name,'definition':definition,'output':str(output),'omitted':record['omitted']}))
    return 0
