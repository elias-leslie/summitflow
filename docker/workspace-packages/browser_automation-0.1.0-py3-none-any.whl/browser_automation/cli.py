"""Supported browser command owner executable."""

from __future__ import annotations

import json
from importlib.resources import files
from pathlib import Path

import typer
from st_sdk.output import output_error
from st_sdk.runtime import describe_app, run_app
from st_sdk.usage import usage

from .contract import BrowserRequest
from .engine import execute

APP_NAMESPACE = "st.browser"
_USAGE = """Remote browser automation through st

Default target:
  Plain st browser commands use local system Chrome profile AI.
  Force Proxmox/VM with --proxmox or ST_BROWSER_TARGET=proxmox when VM isolation is better.
  Override VM with ST_BROWSER_HOST, ST_BROWSER_DEFAULT_HOST, or ST_BROWSER_VM_ID.
  Do not start arbitrary Chrome, CDP proxies, or agent-browser on the project/server host.
  The approved local default is the local-AI profile flow.
  Set ST_BROWSER_DISABLE_DEFAULT_VM_HOST=1 to require explicit host config.

Usage:
  st browser health
  st browser --local-ai health
  st browser --local-ai open <project-or-url>
  st browser --proxmox check <project-or-url> [screenshot-path]
  st browser url <project>
  st browser check [--session <name>] <project-or-url> [screenshot-path]
  st browser open <project-or-url>
  st browser screenshot [path]
  st browser snapshot
  st browser eval <js>
  st browser --proxmox endpoint [--http|--ws|--json]
  st browser update
  st browser [--chrome|--lp|--engine <name>] <agent-browser command> [args...]

Examples:
  st browser --local-ai open portfolio-ai
  st browser --local-ai check portfolio-ai /tmp/portfolio-ai.png
  st browser health
  st browser url a-term
  st browser check a-term /tmp/a-term.png
  st browser --proxmox endpoint --ws
  st vm status <browser-vm-id>
  ST_BROWSER_HOST=<browser-vm-or-connector> st browser health
  ST_BROWSER_HOST=<browser-vm-or-connector> st browser check http://app.lan:3001 /tmp/page.png
  st browser --proxmox snapshot

Proxmox local page URL guard:
  With --proxmox, localhost/127.0.0.1 targets are blocked because they point at the browser VM.
  Use st browser url <project>; intentional Proxmox local targets print a confirmation token.

Debug local CDP override:
  ST_BROWSER_HOST=127.0.0.1 ST_BROWSER_ALLOW_LOCAL=1 st browser health

Local system Chrome:
  Default mode uses system Chrome, profile `AI`, headless hardware GL, and no
  software-rasterizer fallback. It creates no desktop window or focus change.
  The host-local browser is a singleton; route parallel browser work through --proxmox.
  Window control: ST_BROWSER_LOCAL_AI_VISIBLE=1 creates a normal watched window;
  ST_BROWSER_LOCAL_AI_MINIMIZED=1 creates a minimized window. Both are explicit-only.
  Override local Chrome with ST_BROWSER_LOCAL_CHROME, ST_BROWSER_LOCAL_AI_PROFILE.

Local desktop UI:
  Use st ui when the already-open desktop/PWA is the right evidence source or browser automation is not enough.
"""

app = typer.Typer(add_completion=False, help=_USAGE, context_settings={"help_option_names": []})


@app.callback(invoke_without_command=True)
@usage(
    surface="st.browser",
    cmd="st browser check <url> <png>",
    when="UI render verification; screenshots; DOM snapshots",
    precautions=(
        "plain st browser uses local Chrome AI profile by default",
        "use --proxmox or ST_BROWSER_TARGET=proxmox when VM isolation is better for the task",
        "use st ui when the open desktop/PWA is the right evidence source",
        "never start arbitrary chrome/CDP on project or server host; local-AI is the approved local profile flow",
        "only set ST_BROWSER_HOST / ST_BROWSER_VM_ID for explicit approved override",
    ),
    task_types=("frontend", "ui-design", "design-review", "verification"),
    tier="mandate",
)
def browser(
    request: str | None = typer.Option(None, "--request", hidden=True),
    describe: bool = typer.Option(False, "--describe", hidden=True),
) -> None:
    if describe:
        typer.echo(json.dumps(describe_app(app, APP_NAMESPACE), indent=2))
        return
    if request is None:
        typer.echo(_USAGE)
        raise typer.Exit(0)
    try:
        parsed = BrowserRequest.from_json(request)
    except ValueError as exc:
        output_error(str(exc))
        raise typer.Exit(2) from None
    raise typer.Exit(execute(parsed))


def write_metadata() -> None:
    target = files("browser_automation").joinpath("metadata/browser-extension.json")
    described = describe_app(app, APP_NAMESPACE)
    manifest = {
        "id": "browser.automation",
        "owner": "browser-automation",
        "namespace": "browser",
        "version": "0.1.0",
        "st_contract_versions": [1],
        "summary": "Managed browser automation with SummitFlow-owned routing policy.",
        "effects": ["read-local", "write-local", "read-remote", "write-remote", "network", "process", "desktop"],
        "help": described["help"],
        "usage": described["usage"],
    }
    Path(str(target)).write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    run_app(app, APP_NAMESPACE)


if __name__ == "__main__":
    main()
