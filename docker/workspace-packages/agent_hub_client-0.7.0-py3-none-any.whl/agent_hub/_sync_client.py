"""Synchronous client for Agent Hub API."""

from __future__ import annotations

import warnings
from collections.abc import Iterator
from typing import Any

import httpx

from agent_hub._agents import AgentOperationsMixin
from agent_hub._automations import AutomationOperationsMixin
from agent_hub._base import BaseClientMixin
from agent_hub._catalog import CatalogOperationsMixin
from agent_hub._completion import build_completion_payload, handle_completion_response
from agent_hub._image import generate_image_sync
from agent_hub._memory import MemoryOperationsMixin
from agent_hub._sessions import SessionOperationsMixin
from agent_hub._streaming import stream_completion_sse_sync
from agent_hub._workflow import build_workflow_payload, handle_workflow_response
from agent_hub.constants import DEFAULT_IMAGE_AGENT
from agent_hub.exceptions import ClientDisabledError
from agent_hub.models import (
    CompletionResponse,
    ImageGenerationResponse,
    MessageInput,
    NativeContinuation,
    StreamChunk,
    ToolDefinition,
    ToolResultMessage,
)


class AgentHubClient(
    BaseClientMixin,
    AgentOperationsMixin,
    CatalogOperationsMixin,
    SessionOperationsMixin,
    MemoryOperationsMixin,
    AutomationOperationsMixin,
):
    """Synchronous client for Agent Hub API.

    Example:
        client = AgentHubClient(
            base_url="http://localhost:8003",
            client_name="my-app"
        )
        response = client.complete(
            agent_slug="chat",
            messages=[{"role": "user", "content": "Hello!"}]
        )
        print(response.content)
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8003",
        api_key: str | None = None,
        timeout: float | None = None,
        client_name: str | None = None,
        auto_inject_headers: bool = True,
        client_id: str | None = None,
        request_source: str | None = None,
        cli_command: str | None = None,
        source_client: str = "agent-hub-sdk",
    ) -> None:
        """Initialize the client.

        Args:
            base_url: Agent Hub API base URL.
            api_key: Optional API key for authentication.
            timeout: Request timeout in seconds.
            client_name: Name of this client for usage tracking (required by API).
                If not provided, auto-detected from caller module.
            auto_inject_headers: Whether to auto-inject X-Source-Client and
                X-Source-Path headers. Set to False to disable.
            client_id: Client ID for access control authentication.
            request_source: Request source identifier for tracking.
            cli_command: CLI command name override for tool tracking.
                When set, this replaces the default SDK method name (e.g., "sdk.complete")
                in the X-Tool-Name header. Use this from CLI tools to track the actual
                command (e.g., "st memory save" instead of "sdk.save_learning").
            source_client: ``X-Source-Client`` value; Agent Hub classifies
                values containing "cli" as CLI traffic and "sdk" as SDK traffic.
        """
        super().__init__(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            client_name=client_name,
            auto_inject_headers=auto_inject_headers,
            client_id=client_id,
            request_source=request_source,
            cli_command=cli_command,
            source_client=source_client,
        )
        self._client: httpx.Client | None = None

    def _get_client(self) -> httpx.Client:
        """Get or create httpx client."""
        if self._client is None:
            headers = self._build_base_headers()
            self._client = httpx.Client(
                base_url=self.base_url,
                headers=headers,
                timeout=self.timeout,
            )
        return self._client

    def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self) -> AgentHubClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def complete(
        self,
        messages: list[dict[str, str] | MessageInput | ToolResultMessage],
        *,
        project_id: str,
        agent_slug: str | None = None,
        model: str | None = None,
        temperature: float = 1.0,
        session_id: str | None = None,
        external_id: str | None = None,
        enable_caching: bool = True,
        use_memory: bool = False,
        memory_group_id: str | None = None,
        memory_variant_override: str | None = None,
        tools: list[dict[str, Any] | ToolDefinition] | None = None,
        enable_programmatic_tools: bool = False,
        container_id: str | None = None,
        max_turns: int = 1,
        working_dir: str | None = None,
        execute_tools: bool = False,
        task_type: str | None = None,
        trace_id: str | None = None,
        timeout_seconds: float | None = None,
        thinking_level: str | None = None,
        system_prompt: str | None = None,
        include_roles: list[str] | None = None,
        current_branch: str | None = None,
        skip_cache: bool = False,
        response_format: dict[str, Any] | None = None,
        disable_agent_fallbacks: bool = False,
        native_continuation: NativeContinuation | dict[str, Any] | None = None,
        parent_session_id: str | None = None,
        source_metadata: dict[str, Any] | None = None,
        work_context: dict[str, Any] | None = None,
        read_only: bool = False,
    ) -> CompletionResponse:
        """Generate a completion. Use agent_slug for routing with mandates and fallbacks."""
        if not agent_slug and not model:
            raise ValueError(
                "Either 'agent_slug' or 'model' must be provided. "
                "Prefer 'agent_slug' to route to pre-configured agents."
            )

        self._check_disabled()

        client = self._get_client()
        payload = build_completion_payload(
            messages=messages,
            project_id=project_id,
            agent_slug=agent_slug,
            model=model,
            temperature=temperature,
            session_id=session_id,
            external_id=external_id,
            enable_caching=enable_caching,
            use_memory=use_memory,
            memory_group_id=memory_group_id,
            memory_variant_override=memory_variant_override,
            tools=tools,
            enable_programmatic_tools=enable_programmatic_tools,
            container_id=container_id,
            max_turns=max_turns,
            working_dir=working_dir,
            execute_tools=execute_tools,
            task_type=task_type,
            trace_id=trace_id,
            timeout_seconds=timeout_seconds,
            thinking_level=thinking_level,
            system_prompt=system_prompt,
            include_roles=include_roles,
            current_branch=current_branch,
            response_format=response_format,
            disable_agent_fallbacks=disable_agent_fallbacks,
            native_continuation=native_continuation,
            parent_session_id=parent_session_id,
            source_metadata=source_metadata,
            work_context=work_context,
            read_only=read_only,
        )

        extra_headers = {"X-Skip-Cache": "true"} if skip_cache else None
        headers = self._inject_tracking_headers("sdk.complete", extra_headers=extra_headers)
        request_timeout = timeout_seconds if timeout_seconds is not None else self.timeout
        response = client.post(
            "/api/complete", json=payload, headers=headers, timeout=request_timeout
        )

        return handle_completion_response(response, self)

    def stream_sse(
        self,
        messages: list[dict[str, str] | MessageInput | ToolResultMessage],
        *,
        project_id: str,
        agent_slug: str | None = None,
        model: str | None = None,
        temperature: float = 1.0,
        session_id: str | None = None,
        use_memory: bool = False,
        memory_group_id: str | None = None,
        tools: list[dict[str, Any] | ToolDefinition] | None = None,
        max_turns: int = 1,
        working_dir: str | None = None,
        execute_tools: bool = False,
        task_type: str | None = None,
        trace_id: str | None = None,
        thinking_level: str | None = None,
        include_roles: list[str] | None = None,
        current_branch: str | None = None,
        skip_cache: bool = False,
        parent_session_id: str | None = None,
        source_metadata: dict[str, Any] | None = None,
        work_context: dict[str, Any] | None = None,
        read_only: bool = False,
        timeout_seconds: float | None = None,
    ) -> Iterator[StreamChunk]:
        """Stream a completion using SSE; the synchronous form of ``AsyncAgentHubClient.stream_sse``."""
        if not agent_slug and not model:
            raise ValueError(
                "Either 'agent_slug' or 'model' must be provided. "
                "Prefer 'agent_slug' to route to pre-configured agents."
            )
        self._check_disabled()
        payload = build_completion_payload(
            messages=messages,
            project_id=project_id,
            agent_slug=agent_slug,
            model=model,
            temperature=temperature,
            session_id=session_id,
            use_memory=use_memory,
            memory_group_id=memory_group_id,
            tools=tools,
            max_turns=max_turns,
            working_dir=working_dir,
            execute_tools=execute_tools,
            task_type=task_type,
            trace_id=trace_id,
            thinking_level=thinking_level,
            include_roles=include_roles,
            current_branch=current_branch,
            parent_session_id=parent_session_id,
            source_metadata=source_metadata,
            work_context=work_context,
            read_only=read_only,
            stream=True,
        )
        extra_headers = {"X-Skip-Cache": "true"} if skip_cache else None
        headers = self._inject_tracking_headers("sdk.stream_sse", extra_headers=extra_headers)
        try:
            yield from stream_completion_sse_sync(
                client=self._get_client(), payload=payload, headers=headers, timeout=timeout_seconds,
            )
        except ClientDisabledError as e:
            self._disabled = True
            self._disabled_reason = e.reason
            raise

    def close_native_continuation(
        self,
        *,
        session_id: str,
        generation: int,
        controller_generation: str,
    ) -> dict[str, Any]:
        """Close one exact retained native generation without executing a turn."""
        self._check_disabled()
        client = self._get_client()
        headers = self._inject_tracking_headers("sdk.close_native_continuation")
        response = client.post(
            "/api/complete/native/close",
            json={
                "session_id": session_id,
                "generation": generation,
                "controller_generation": controller_generation,
            },
            headers=headers,
        )
        if not response.is_success:
            from agent_hub._utils import handle_error

            handle_error(response)
        return response.json()

    def workflow(
        self,
        *,
        project_id: str,
        shared_context: str | None = None,
        external_id: str | None = None,
        trace_id: str | None = None,
        clarify: dict[str, Any] | None = None,
        plan: dict[str, Any] | None = None,
        execute: dict[str, Any] | None = None,
        review: dict[str, Any] | None = None,
        qa: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Deprecated: the server route was removed. Kept for import compatibility."""

        warnings.warn(
            "AgentHubClient.workflow() is deprecated in agent-hub-client 0.7.0: Agent Hub no "
            "longer serves /api/orchestration/workflow. It will be removed in 0.8.0; "
            "compose complete() calls with an explicit agent_slug instead.",
            DeprecationWarning,
            stacklevel=2,
        )

        self._check_disabled()

        client = self._get_client()
        payload = build_workflow_payload(
            project_id=project_id,
            shared_context=shared_context,
            external_id=external_id,
            trace_id=trace_id,
            clarify=clarify,
            plan=plan,
            execute=execute,
            review=review,
            qa=qa,
        )
        headers = self._inject_tracking_headers("sdk.workflow")
        response = client.post(
            "/api/orchestration/workflow",
            json=payload,
            headers=headers,
            timeout=self.timeout,
        )
        return handle_workflow_response(response, self)

    def generate_image(
        self,
        prompt: str,
        *,
        project_id: str,
        agent_slug: str | None = DEFAULT_IMAGE_AGENT,
        model: str | None = None,
        size: str = "1024x1024",
        style: str | None = None,
        reference_image: str | None = None,
        reference_mime_type: str | None = None,
    ) -> ImageGenerationResponse:
        """Generate an image from a text prompt."""
        client = self._get_client()
        headers = self._inject_tracking_headers("sdk.generate_image")
        return generate_image_sync(
            client=client,
            headers=headers,
            prompt=prompt,
            project_id=project_id,
            agent_slug=agent_slug,
            model=model,
            size=size,
            style=style,
            reference_image=reference_image,
            reference_mime_type=reference_mime_type,
        )
