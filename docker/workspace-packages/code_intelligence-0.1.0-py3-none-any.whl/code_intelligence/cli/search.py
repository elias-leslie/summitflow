"""Precision Code Search CLI command."""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Annotated, Any

import typer
from st_sdk import APIError, STClient, get_config_optional, usage
from st_sdk.config import get_project_root_path
from st_sdk.execution_context import (
    canonical_repo_root,
    resolve_checkout_project_id,
    resolve_checkout_root,
)
from st_sdk.output import handle_api_error, output_json
from st_sdk.state import is_compact, is_human

from code_intelligence.precision.token_utils import estimate_tokens
from code_intelligence.search.search_checkout import (
    _build_checkout_precision_result,
    _checkout_has_local_changes,
    _normalize_path_prefix,
    _search_checkout_file_symbols,
    _search_checkout_symbols,
    _search_checkout_text,
)
from code_intelligence.search.search_models import SearchRoots, SearchScope
from code_intelligence.search.search_output import (
    _print_file_symbols_compact,
    _print_precision_compact,
    _print_symbols_compact,
    _print_text_compact,
)

app = typer.Typer(help="Precision Code Search")

ProjectOption = Annotated[str | None, typer.Option("--project", "-P", help="Project ID (overrides auto-detection for this search)")]
QueryArgument = Annotated[list[str] | None, typer.Argument(help="Search query (symbol name, function, class, endpoint)")]
BudgetOption = Annotated[int, typer.Option("--budget", "-b", help="Token budget for prompt context")]
LimitOption = Annotated[int, typer.Option("--limit", "-l", help="Maximum primitive results")]
OffsetOption = Annotated[int, typer.Option("--offset", help="Primitive result offset for text, symbols, or file listings")]
TextOption = Annotated[bool, typer.Option("--text", help="Search literal text/content")]
SymbolsOption = Annotated[bool, typer.Option("--symbols", help="Use the symbol search primitive")]
JsonOption = Annotated[bool, typer.Option("--json", "-j", help="Emit full JSON payload")]
FileOption = Annotated[str | None, typer.Option("--file", "-f", help="List symbols in a specific file")]
PathOption = Annotated[str | None, typer.Option("--path", help="Restrict search to a relative file/subtree prefix")]
HintOption = Annotated[bool, typer.Option("--hint/--no-hint", help="Show refinement hints when results are poor")]
ScopeOption = Annotated[
    SearchScope,
    typer.Option(
        "--scope",
        help=(
            "auto: verify current source and recover definitions; "
            "project: hosted project source; "
            "checkout: local search for alternate or offline checkouts"
        ),
        case_sensitive=False,
    ),
]

_SEARCH_PROGRESS_DELAY_SECONDS = 1.5
_MAX_RESULT_LIMIT = 20
_SEARCH_PROGRESS_MESSAGE = (
    "st search: still working; checking indexed candidates against current source."
)


def _emit_status(message: str) -> None:
    """Write a human-oriented status line to stderr without polluting stdout payloads."""
    typer.echo(message, err=True)


def _start_delayed_status_timer(message: str) -> threading.Timer:
    """Start a delayed stderr status note for slow precision searches."""
    timer = threading.Timer(_SEARCH_PROGRESS_DELAY_SECONDS, _emit_status, args=(message,))
    timer.daemon = True
    timer.start()
    return timer


def _normalize_limit(limit: int) -> int:
    if limit <= _MAX_RESULT_LIMIT:
        return limit
    _emit_status(f"st search: --limit {limit} capped at {_MAX_RESULT_LIMIT}.")
    return _MAX_RESULT_LIMIT


def _run_precision_search(
    client: STClient,
    query: str,
    budget: int,
    limit: int,
    *,
    path_prefix: str | None = None,
    include_candidates: bool = False,
) -> dict[str, Any]:
    """Run precision search with a delayed status line so stale refreshes don't look hung."""
    timer = _start_delayed_status_timer(_SEARCH_PROGRESS_MESSAGE)
    try:
        return client.request(
            "GET",
            "/explorer/precision-search",
            params={
                key: value
                for key, value in {
                    "q": query,
                    "budget": budget,
                    "limit": limit,
                    "path_prefix": path_prefix,
                    "include_candidates": True if include_candidates else None,
                }.items()
                if value is not None
            },
        )
    finally:
        timer.cancel()


def _emit_precision_search_metadata_note(metadata: dict[str, Any]) -> None:
    """Explain incomplete current-source retrieval when relevant."""
    if metadata.get("refreshed_index"):
        _emit_status("st search: refreshed stale Explorer indexes before returning results.")
        return
    if metadata.get("retrieval_errors"):
        errors = ", ".join(str(item) for item in metadata["retrieval_errors"])
        _emit_status(f"st search: current-source lookup incomplete ({errors}).")
    has_usable_results = any(
        int(metadata.get(key) or 0) > 0
        for key in ("final_tokens", "symbol_count", "text_match_count")
    )
    if metadata.get("stale_hit") and not has_usable_results and not metadata.get("source_verified"):
        age = metadata.get("symbol_index_age_minutes")
        age_note = f" ({age}m old)" if isinstance(age, int) and age > 0 else ""
        _emit_status(f"st search: no verified matches; the symbol index{age_note} is stale.")
    if metadata.get("checkout_overlay_applied"):
        _emit_status("st search: assembled current checkout candidates with indexed project candidates.")


def _resolve_search_roots(project_override: str | None, scope: SearchScope) -> SearchRoots:
    """Resolve canonical project and current-checkout roots for this search."""
    checkout_root = resolve_checkout_root()
    canonical_root = canonical_repo_root()
    config = get_config_optional()
    selected_project_id = project_override or config.project_id or None
    checkout_project_id = resolve_checkout_project_id()
    if selected_project_id and checkout_project_id and selected_project_id != checkout_project_id:
        return _resolve_cross_project_roots(selected_project_id, scope)

    checkout_has_changes = _checkout_has_local_changes(checkout_root)
    if scope == SearchScope.CHECKOUT:
        return SearchRoots(scope, "checkout" if checkout_root else "project", None, checkout_root, checkout_has_changes)

    project_root = _project_root(config.project_root, selected_project_id, checkout_project_id, canonical_root)
    effective_scope = _effective_scope(scope, selected_project_id, checkout_project_id, checkout_root, project_root, checkout_has_changes)
    checkout_is_project = bool(
        checkout_root is not None
        and checkout_project_id is not None
        and (selected_project_id is None or selected_project_id == checkout_project_id)
    )
    return SearchRoots(scope, effective_scope, project_root, checkout_root, checkout_has_changes, checkout_is_project)


def _resolve_cross_project_roots(selected_project_id: str, scope: SearchScope) -> SearchRoots:
    """The cwd checkout belongs to a different project than the one being
    searched, so it must never be used as the live tree — the only valid
    live tree is the selected project's registered root."""
    if scope == SearchScope.CHECKOUT:
        target_root = _registered_project_root(selected_project_id)
        if target_root is None:
            typer.echo(
                f"Error: --scope checkout needs a local root for project `{selected_project_id}`, but none is "
                "registered or present on this host — drop --scope checkout to search its index, or rescan the project.",
                err=True,
            )
            raise typer.Exit(1)
        return SearchRoots(scope, "checkout", target_root, target_root, _checkout_has_local_changes(target_root), True)
    # Defer the root lookup: AUTO/PROJECT searches only need it if an
    # identifier miss escalates to a live parse of the target tree.
    return SearchRoots(scope, "project", None, None, False, False, selected_project_id)


def _registered_project_root(project_id: str) -> Path | None:
    root_path = get_project_root_path(project_id)
    if not root_path:
        return None
    root = Path(root_path).resolve()
    return root if root.is_dir() else None


def _project_root(
    configured_root: str | None,
    selected_project_id: str | None,
    checkout_project_id: str | None,
    canonical_root: Path | None,
) -> Path | None:
    if configured_root:
        return Path(configured_root).resolve()
    if selected_project_id and checkout_project_id and selected_project_id == checkout_project_id:
        return canonical_root
    return None


def _effective_scope(
    scope: SearchScope,
    selected_project_id: str | None,
    checkout_project_id: str | None,
    checkout_root: Path | None,
    project_root: Path | None,
    checkout_has_changes: bool,
) -> str:
    if scope == SearchScope.PROJECT or (selected_project_id and checkout_project_id and selected_project_id != checkout_project_id):
        return "project"
    if checkout_root and project_root and checkout_root != project_root and checkout_project_id and (
        selected_project_id is None or selected_project_id == checkout_project_id
    ):
        return "combined"
    if checkout_root and project_root is None and selected_project_id is None:
        return "checkout"
    return "project"


def _search_client(project: str | None) -> STClient:
    return STClient(project_id=project) if project else STClient()


def _remote_result(project: str | None, endpoint: str, **params: Any) -> dict[str, Any]:
    client = _search_client(project)
    return client.request(
        "GET",
        endpoint,
        params={key: value for key, value in params.items() if value is not None},
    )


def _current_root(roots: SearchRoots) -> Path | None:
    if roots.scope == SearchScope.PROJECT:
        return None
    if roots.effective_scope in {"checkout", "combined"} and roots.checkout_root is not None:
        return roots.checkout_root
    if roots.scope == SearchScope.AUTO:
        if roots.checkout_is_project:
            return roots.checkout_root
        if roots.cross_project_id:
            return _registered_project_root(roots.cross_project_id)
        return roots.project_root
    return None


def _file_result(roots: SearchRoots, project: str | None, file_path: str, limit: int, offset: int = 0) -> dict[str, Any]:
    if current_root := _current_root(roots):
        return _search_checkout_file_symbols(current_root, file_path, limit=limit, offset=offset)
    return _remote_result(project, "/explorer/symbols/by-file", file_path=file_path, limit=limit, offset=offset or None)


def _text_result(roots: SearchRoots, project: str | None, query: str, limit: int, path_prefix: str | None, offset: int = 0) -> dict[str, Any]:
    if current_root := _current_root(roots):
        return _search_checkout_text(current_root, query, limit=limit, path_prefix=path_prefix, offset=offset)
    return _remote_result(project, "/explorer/text/search", q=query, limit=limit, path_prefix=path_prefix, offset=offset or None)


def _symbols_result(roots: SearchRoots, project: str | None, query: str, limit: int, path_prefix: str | None, offset: int = 0) -> dict[str, Any]:
    if current_root := _current_root(roots):
        return _search_checkout_symbols(current_root, query, limit=limit, path_prefix=path_prefix, offset=offset)
    return _remote_result(project, "/explorer/symbols/search", q=query, limit=limit, path_prefix=path_prefix, offset=offset or None)


def _local_precision_result(
    roots: SearchRoots,
    project: str | None,
    query: str,
    budget: int,
    limit: int,
    path_prefix: str | None,
    *,
    root: Path,
    indexed_candidates: list[dict[str, object]] | None = None,
) -> dict[str, Any]:
    result = _build_checkout_precision_result(
        query,
        root,
        budget,
        limit,
        path_prefix=path_prefix,
        indexed_candidates=indexed_candidates,
    )
    metadata = dict(result.get("metadata") or {})
    metadata.update(
        scope="combined" if roots.effective_scope == "combined" else "checkout",
        checkout_root=str(root),
        project_root=str(roots.project_root) if roots.project_root else None,
        checkout_overlay_applied=roots.effective_scope == "combined",
    )
    return {"query": query, "prompt_context": result.get("prompt_context", ""), "metadata": metadata}


def _precision_result(
    roots: SearchRoots,
    project: str | None,
    query: str,
    budget: int,
    limit: int,
    path_prefix: str | None,
) -> dict[str, Any]:
    if roots.effective_scope == "checkout" and roots.checkout_root is not None:
        return _local_precision_result(
            roots, project, query, budget, limit, path_prefix, root=roots.checkout_root
        )

    try:
        project_result = _run_precision_search(
            _search_client(project),
            query,
            budget,
            limit,
            path_prefix=path_prefix,
            include_candidates=roots.effective_scope == "combined",
        )
    except APIError as exc:
        local_root = _current_root(roots)
        if local_root is None:
            raise
        result = _local_precision_result(
            roots, project, query, budget, limit, path_prefix, root=local_root
        )
        result["metadata"]["host_unverified_reason"] = f"host_request_failed:{exc.status_code}"
        return result
    if roots.effective_scope != "combined":
        project_result.pop("candidates", None)
    if roots.effective_scope == "combined" and roots.checkout_root is not None:
        candidates = project_result.get("candidates")
        return _local_precision_result(
            roots,
            project,
            query,
            budget,
            limit,
            path_prefix,
            root=roots.checkout_root,
            indexed_candidates=candidates if isinstance(candidates, list) else [],
        )
    if roots.scope == SearchScope.AUTO:
        live_root = roots.checkout_root if roots.checkout_is_project else (
            _registered_project_root(roots.cross_project_id) if roots.cross_project_id else roots.project_root
        )
        metadata = project_result.get("metadata") or {}
        same_root = live_root is not None and metadata.get("source_root") == str(live_root.resolve())
        # A remote client may have no local checkout. The hosted route can still
        # verify the selected canonical project; an actual local checkout must
        # agree with that root or be verified independently below.
        host_root_applies = same_root or (live_root is None and bool(metadata.get("source_root")))
        if not (host_root_applies and metadata.get("source_verified") and metadata.get("retrieval_complete")):
            if live_root is not None:
                result = _local_precision_result(
                    roots, project, query, budget, limit, path_prefix, root=live_root
                )
                result["metadata"]["host_unverified_reason"] = metadata.get("retrieval_errors") or "host_source_unverified"
                return result
            metadata = dict(metadata)
            metadata["retrieval_errors"] = [
                *metadata.get("retrieval_errors", []),
                "local_source_root_unavailable",
            ]
            metadata.update(
                source_verified=False,
                retrieval_complete=False,
                final_tokens=0,
                prompt_tokens=0,
                symbol_count=0,
                text_match_count=0,
                symbol_tokens=0,
                fallback_tokens=0,
                naive_file_tokens=0,
                estimated_tokens_saved=0,
                measurement_available=False,
                baseline_label=None,
                used_symbol_first=False,
                used_fallback=False,
                fallback_mode=None,
                prompt_truncated=False,
                symbol_truncated=False,
                text_truncated=False,
                emitted_output_tokens=None,
            )
            return {**project_result, "prompt_context": "", "metadata": metadata}
    return project_result


def _emit_file_output(file_path: str, result: dict[str, Any], raw_json: bool, show_hint: bool) -> None:
    if raw_json:
        output_json(result)
    elif is_compact():
        _print_file_symbols_compact(str(result.get("file_path", file_path)), result, show_hint=show_hint)
    else:
        output_json(result)


def _emit_query_output(query: str, result: dict[str, Any], text: bool, symbols: bool, hint: bool) -> None:
    if is_compact():
        if text:
            _print_text_compact(query, result)
        elif symbols:
            _print_symbols_compact(query, result)
        else:
            _print_precision_compact(query, result.get("prompt_context", ""), result.get("metadata", {}), show_hint=hint)
        return
    _output_accounted_json(result)


def _output_accounted_json(result: dict[str, Any]) -> None:
    metadata = result.get("metadata")
    if isinstance(metadata, dict) and "prompt_context" in result:
        count = 0
        for _ in range(8):
            metadata["emitted_output_tokens"] = count
            rendered = json.dumps(result, default=str, indent=2 if is_human() else None) + "\n"
            updated = estimate_tokens(rendered)
            if updated == count:
                break
            count = updated
        metadata["emitted_output_tokens"] = count
    output_json(result)


@app.command()
@usage(
    surface="st.search",
    cmd='st search "query"',
    when="repo/code discovery; before adding any function/endpoint/command/component — search first and extend a close match instead of writing new",
    precautions=(
        "start with default search; it validates indexed candidates against current source and recovers local definitions",
        "use 1-4 identifier or filename terms and consume the returned source; narrow with --path or --file, and use --text for literal content",
        "if mode=text-fallback or empty, refine the query or use a primitive; --scope checkout is for alternate or offline roots",
        "on a close match, extend/reuse it rather than adding a near-duplicate",
    ),
    tier="mandate",
)
def search(
    project: ProjectOption = None,
    query: QueryArgument = None,
    budget: BudgetOption = 1200,
    limit: LimitOption = 20,
    offset: OffsetOption = 0,
    text: TextOption = False,
    symbols: SymbolsOption = False,
    raw_json: JsonOption = False,
    file: FileOption = None,
    path: PathOption = None,
    hint: HintOption = True,
    scope: ScopeOption = SearchScope.AUTO,
) -> None:
    """Search code with automatic current-source verification.

    Start with plain st search and 1-4 identifier or filename terms. Use the
    returned source before another lookup. Narrow with --path or --file, and
    use --text for literal content.

    The default auto scope validates indexed candidates against current source
    and recovers stale or missing definitions. Use --scope checkout for an
    alternate or offline checkout. Follow verification warnings and narrow
    truncated results for more source.
    """
    q = " ".join(query).strip() if query else ""
    limit = _normalize_limit(limit)
    if limit < 1 or offset < 0 or (offset and not (text or symbols or file)):
        typer.echo("Error: --limit must be positive and --offset is for primitive results only", err=True)
        raise typer.Exit(1)
    normalized_path = _normalize_path_prefix(path)
    if not q and not file:
        typer.echo("Error: empty query", err=True)
        raise typer.Exit(1)
    if text and symbols:
        typer.echo("Error: choose at most one primitive mode", err=True)
        raise typer.Exit(1)

    roots = _resolve_search_roots(project, scope)
    if scope == SearchScope.CHECKOUT and roots.checkout_root is None:
        typer.echo("Error: --scope checkout requires a git checkout", err=True)
        raise typer.Exit(1)

    try:
        if file:
            _emit_file_output(file, _file_result(roots, project, file, limit, offset), raw_json, hint)
            return
        result = _text_result(roots, project, q, limit, normalized_path, offset) if text else _query_result(roots, project, q, budget, limit, normalized_path, symbols, offset)
    except APIError as e:
        handle_api_error(e)
        return

    if raw_json:
        _output_accounted_json(result)
        return
    if not text and not symbols:
        _emit_precision_search_metadata_note(result.get("metadata", {}))
    _emit_query_output(q, result, text, symbols, hint)


def _query_result(
    roots: SearchRoots,
    project: str | None,
    query: str,
    budget: int,
    limit: int,
    path_prefix: str | None,
    symbols: bool,
    offset: int = 0,
) -> dict[str, Any]:
    if symbols:
        return _symbols_result(roots, project, query, limit, path_prefix, offset)
    return _precision_result(roots, project, query, budget, limit, path_prefix)
