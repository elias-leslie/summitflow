"""Precision Code Search CLI command (local source only)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated, Any, NoReturn

import typer
from st_sdk import usage
from st_sdk.config import get_project_root_path
from st_sdk.execution_context import resolve_checkout_project_id, resolve_checkout_root
from st_sdk.output import output_json
from st_sdk.state import is_compact, is_human

from code_intelligence.precision.token_utils import estimate_tokens
from code_intelligence.search.search_checkout import (
    _build_checkout_precision_result,
    _search_checkout_file_symbols,
    _search_checkout_symbols,
    _search_checkout_text,
)
from code_intelligence.search.search_checkout_paths import normalize_search_path
from code_intelligence.search.search_output import (
    _print_file_symbols_compact,
    _print_precision_compact,
    _print_symbols_compact,
    _print_text_compact,
)

app = typer.Typer(help="Precision Code Search")

ProjectOption = Annotated[str | None, typer.Option("--project", "-P", help="Search another project's registered local root instead of the current checkout")]
QueryArgument = Annotated[list[str] | None, typer.Argument(help="Search query (symbol name, function, class, endpoint)")]
BudgetOption = Annotated[int, typer.Option("--budget", "-b", help="Token budget for precision prompt context only (not primitives)")]
LimitOption = Annotated[int, typer.Option("--limit", "-l", help="Maximum primitive results")]
OffsetOption = Annotated[int, typer.Option("--offset", help="Primitive result offset for text, symbols, or file listings")]
TextOption = Annotated[bool, typer.Option("--text", help="Join query arguments into one case-insensitive literal phrase")]
SymbolsOption = Annotated[bool, typer.Option("--symbols", help="Use the symbol search primitive")]
JsonOption = Annotated[bool, typer.Option("--json", "-j", help="Emit full JSON payload")]
FileOption = Annotated[str | None, typer.Option("--file", "-f", help="List symbols in a file independently of the query")]
PathOption = Annotated[str | None, typer.Option("--path", help="Restrict to an existing in-root file/subtree (relative or absolute)")]
HintOption = Annotated[bool, typer.Option("--hint/--no-hint", help="Show refinement hints when results are poor")]

_MAX_RESULT_LIMIT = 20


def _emit_status(message: str) -> None:
    """Write a human-oriented status line to stderr without polluting stdout payloads."""
    typer.echo(message, err=True)


def _fail(message: str) -> NoReturn:
    typer.echo(f"Error: {message}", err=True)
    raise typer.Exit(1)


def _normalize_limit(limit: int) -> int:
    if limit <= _MAX_RESULT_LIMIT:
        return limit
    _emit_status(f"st search: --limit {limit} capped at {_MAX_RESULT_LIMIT}.")
    return _MAX_RESULT_LIMIT


def _registered_project_root(project_id: str) -> Path | None:
    root_path = get_project_root_path(project_id)
    if not root_path:
        return None
    root = Path(root_path).resolve()
    return root if root.is_dir() else None


def _resolve_search_root(project_override: str | None) -> Path:
    """Return the one local source tree this search reads.

    `-P <project>` naming a project other than the cwd checkout's searches that
    project's registered root; otherwise the current git checkout is searched.
    """
    if project_override and project_override != resolve_checkout_project_id():
        root = _registered_project_root(project_override)
        if root is None:
            _fail(
                f"no local root for project `{project_override}` (not registered, registry unreachable, "
                "or its root is absent on this host); run st search from a checkout of it instead."
            )
        return root
    checkout_root = resolve_checkout_root()
    if checkout_root is None:
        _fail(
            "st search reads the current git checkout; run it inside one, "
            "or pass -P <project> for a project registered on this host."
        )
    return checkout_root


def _precision_result(
    root: Path, query: str, budget: int, limit: int, path_prefix: str | None
) -> dict[str, Any]:
    result = _build_checkout_precision_result(query, root, budget, limit, path_prefix=path_prefix)
    return {"query": query, "prompt_context": result.get("prompt_context", ""), "metadata": dict(result.get("metadata") or {})}


def _emit_retrieval_note(metadata: dict[str, Any]) -> None:
    """Explain incomplete current-source retrieval when relevant."""
    if errors := metadata.get("retrieval_errors"):
        _emit_status(f"st search: current-source lookup incomplete ({', '.join(str(item) for item in errors)}).")


def _emit_file_output(file_path: str, result: dict[str, Any], raw_json: bool, show_hint: bool) -> None:
    if raw_json:
        output_json(result)
    elif is_compact():
        _print_file_symbols_compact(str(result.get("file_path", file_path)), result, show_hint=show_hint)
    else:
        output_json(result)


def _emit_query_output(query: str, result: dict[str, Any], text: bool, symbols: bool, hint: bool) -> None:
    if is_compact():
        if text:
            _print_text_compact(query, result)
        elif symbols:
            _print_symbols_compact(query, result)
        else:
            _print_precision_compact(query, result.get("prompt_context", ""), result.get("metadata", {}), show_hint=hint)
        return
    _output_accounted_json(result)


def _output_accounted_json(result: dict[str, Any]) -> None:
    metadata = result.get("metadata")
    if isinstance(metadata, dict) and "prompt_context" in result:
        count = 0
        for _ in range(8):
            metadata["emitted_output_tokens"] = count
            rendered = json.dumps(result, default=str, indent=2 if is_human() else None) + "\n"
            updated = estimate_tokens(rendered)
            if updated == count:
                break
            count = updated
        metadata["emitted_output_tokens"] = count
    output_json(result)


@app.command()
@usage(
    surface="st.search",
    cmd='st search "query"',
    when="optional ranked discovery; search before adding code, extend a close match",
    precautions=(
        "rg/rg --files for exact literals, regex, multiple needles, file enumeration, exhaustive references",
        "1-4 identifier or filename terms",
    ),
    tier="reference",
)
def search(
    project: ProjectOption = None,
    query: QueryArgument = None,
    budget: BudgetOption = 1200,
    limit: LimitOption = 20,
    offset: OffsetOption = 0,
    text: TextOption = False,
    symbols: SymbolsOption = False,
    raw_json: JsonOption = False,
    file: FileOption = None,
    path: PathOption = None,
    hint: HintOption = True,
) -> None:
    """Search the current checkout's source for ranked definitions.

    ST is optional precision navigation for ranked discovery and current
    definitions. Use rg/rg --files for exact literals, regex, multiple needles,
    file enumeration and exhaustive references. Search before adding code and
    reuse a close match.

    Results are read from the current git checkout; -P <project> searches
    that project's registered root on this host instead.

    --text joins arguments into one case-insensitive literal phrase. --file
    lists that file's symbols independently of the query. --budget applies
    only to precision context. Whole-file reduction estimates are hypothetical
    whole-file baselines, not savings against a native search/read workflow.
    Narrow truncated results for more source.
    """
    q = " ".join(query).strip() if query else ""
    limit = _normalize_limit(limit)
    if limit < 1 or offset < 0 or (offset and not (text or symbols or file)):
        _fail("--limit must be positive and --offset is for primitive results only")
    if not q and not file:
        _fail("empty query")
    if text and symbols:
        _fail("choose at most one primitive mode")

    root = _resolve_search_root(project)
    try:
        normalized_path = normalize_search_path(root, path)
        if file:
            file = normalize_search_path(root, file, must_exist=False) or file
            _emit_file_output(file, _search_checkout_file_symbols(root, file, limit=limit, offset=offset), raw_json, hint)
            return
        if text:
            result = _search_checkout_text(root, q, limit=limit, path_prefix=normalized_path, offset=offset)
        elif symbols:
            result = _search_checkout_symbols(root, q, limit=limit, path_prefix=normalized_path, offset=offset)
        else:
            result = _precision_result(root, q, budget, limit, normalized_path)
    except ValueError as exc:
        _fail(str(exc))

    if raw_json:
        _output_accounted_json(result)
        return
    if not text and not symbols:
        _emit_retrieval_note(result.get("metadata", {}))
    _emit_query_output(q, result, text, symbols, hint)
