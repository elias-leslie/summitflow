"""Graphify CLI wrappers for agent topology work."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import asdict
from pathlib import Path
from typing import Annotated, Any

import typer
from st_sdk import STClient, get_config, usage
from st_sdk.details import display_path, strip_ansi, write_details
from st_sdk.output import output_json

from code_intelligence.graphify_tools import (
    GraphifyCommandResult,
    estimate_tokens,
    explain_graph,
    graphify_code_refresh_needed,
    graphify_report_path,
    graphify_status,
    path_graph,
    query_graph,
    refresh_graph,
    run_graphify,
)
from code_intelligence.precision.token_utils import truncate_to_tokens

from .graph_fallow import (
    fallow_profile as _fallow_profile,
)
from .graph_fallow import (
    gitnexus_profile as _gitnexus_profile,
)
from .graph_fallow import (
    run_fallow_compact,
)
from .graph_fallow import (
    run_measured as _run_measured,
)

app = typer.Typer(help="Graphify topology and profiling helpers")

_GRAPH_REFRESH_PROGRESS_DELAY_SECONDS = 1.5
_DOCTOR_BLOCKING_DIAGNOSTICS = {"graph_missing", "graph_stale", "graph_unreadable", "detect_missing"}
_DEFAULT_CONTEXT_QUESTION = "What are the central modules, coupling points, and architecture communities in this project?"
_SEMANTIC_BATCH_AGENT = "graphify-semantic-extractor"
_SEMANTIC_BATCH_MAX_CHARS = 48_000
_SEMANTIC_BATCH_MAX_FILES = 8
_SEMANTIC_TEXT_SUFFIXES = {".md", ".mdx", ".txt", ".rst", ".adoc", ".json", ".yaml", ".yml", ".csv", ".svg"}
_SEMANTIC_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
_SEMANTIC_SOURCE_TYPES = {"document", "paper", "image", "video", "audio"}
_CODE_ONLY_NODE_TYPES = {"code", "rationale", "community"}


def projects_api(method: str, path: str = "") -> dict[str, Any] | list[dict[str, Any]]:
    """Read the SummitFlow-owned global project registry through the public SDK."""
    client = STClient(require_project=False)
    try:
        return client.request(
            method,
            f"/projects{path}",
            project_scoped=False,
        )
    finally:
        client.close()


def _project_payload(project_id: str) -> dict[str, Any]:
    project = projects_api("GET", f"/{project_id}")
    if not isinstance(project, dict):
        raise typer.BadParameter(f"Project '{project_id}' not found")
    return project


def _all_projects() -> list[dict[str, Any]]:
    projects = projects_api("GET")
    if not isinstance(projects, list):
        return []
    return projects


def _project_id(value: str | None) -> str:
    return value or get_config().project_id


def _root_for_project(project_id: str) -> Path:
    project = _project_payload(project_id)
    return _root_from_project_payload(project_id, project)


def _root_from_project_payload(project_id: str, project: dict[str, Any]) -> Path:
    root_path = project.get("root_path")
    if not root_path:
        raise typer.BadParameter(f"Project '{project_id}' has no root_path configured")
    return Path(str(root_path)).expanduser().resolve()


def _emit_status(message: str) -> None:
    typer.echo(message, err=True)


def _start_delayed_status_timer(message: str) -> threading.Timer:
    timer = threading.Timer(_GRAPH_REFRESH_PROGRESS_DELAY_SECONDS, _emit_status, args=(message,))
    timer.daemon = True
    timer.start()
    return timer


def _status_for_project(
    project_id: str,
    *,
    auto_refresh: bool = True,
    action: str = "status",
    create_missing: bool = True,
) -> dict[str, Any]:
    return _status_for_project_root(
        project_id,
        _root_for_project(project_id),
        auto_refresh=auto_refresh,
        action=action,
        create_missing=create_missing,
    )


def _refresh_graphify_status(
    project_id: str,
    root: Path,
    *,
    action: str,
    status: dict[str, Any],
) -> dict[str, Any]:
    timer = _start_delayed_status_timer(f"st graph: refreshing Graphify code graph before {action}.")
    try:
        refresh_graph(root)
    except (FileNotFoundError, RuntimeError, subprocess.SubprocessError, OSError) as exc:
        if not status.get("graph_exists") or "graph_unreadable" in status.get("diagnostics", []):
            raise
        _emit_status(f"st graph: auto-refresh failed before {action}; using existing graph. reason={exc}")
        return status
    finally:
        timer.cancel()
    _emit_status(f"st graph: refreshed Graphify code graph before {action}.")
    return graphify_status(project_id, root)


def _status_for_project_root(
    project_id: str,
    root: Path,
    *,
    auto_refresh: bool = True,
    action: str = "status",
    create_missing: bool = True,
) -> dict[str, Any]:
    status = graphify_status(project_id, root)
    if not create_missing and not status.get("graph_exists"):
        return status
    if not auto_refresh or not graphify_code_refresh_needed(status):
        return status
    return _refresh_graphify_status(project_id, root, action=action, status=status)


def _fresh_root_for_project(project_id: str, *, action: str) -> Path:
    root = _root_for_project(project_id)
    status = graphify_status(project_id, root)
    if not graphify_code_refresh_needed(status):
        return root
    timer = _start_delayed_status_timer(f"st graph: refreshing Graphify code graph before {action}.")
    try:
        refresh_graph(root)
    except (FileNotFoundError, RuntimeError, subprocess.SubprocessError, OSError) as exc:
        timer.cancel()
        if not status.get("graph_exists") or "graph_unreadable" in status.get("diagnostics", []):
            raise
        _emit_status(f"st graph: auto-refresh failed before {action}; using existing graph. reason={exc}")
        return root
    finally:
        timer.cancel()
    _emit_status(f"st graph: refreshed Graphify code graph before {action}.")
    return root


def _command_payload(result: GraphifyCommandResult) -> dict[str, Any]:
    return asdict(result)


def _command_output(result: subprocess.CompletedProcess[str]) -> str:
    return "\n".join(part for part in ((result.stdout or "").strip(), (result.stderr or "").strip()) if part)


def _issue_count(status: dict[str, Any]) -> int:
    return sum(1 for item in status.get("diagnostics", []) if item in _DOCTOR_BLOCKING_DIAGNOSTICS)


def _warning_count(status: dict[str, Any]) -> int:
    return sum(1 for item in status.get("diagnostics", []) if item not in _DOCTOR_BLOCKING_DIAGNOSTICS)


def _compact_status_lines(status: dict[str, Any]) -> list[str]:
    diagnostics = status.get("diagnostics") or []
    return [
        "## Graph Status",
        f"- project: {status.get('project_id', '-')}",
        f"- nodes: {status.get('node_count', 0)}",
        f"- edges: {status.get('edge_count', 0)}",
        f"- communities: {status.get('community_count', 0)}",
        f"- semantic_coverage: {status.get('semantic_coverage', '-')}",
        f"- diagnostics: {', '.join(str(item) for item in diagnostics) if diagnostics else '-'}",
        f"- graph_stale: {str(status.get('graph_stale', False)).lower()}",
    ]


def _report_context(root: Path, *, line_limit: int = 80) -> str:
    report = graphify_report_path(root)
    if not report.exists():
        return "## Graph Report\n- missing"
    lines = report.read_text(encoding="utf-8", errors="replace").splitlines()
    selected: list[str] = []
    capture = False
    for line in lines:
        if line.startswith("# Graph Report") or line.startswith("## Summary") or line.startswith("## Community Hubs"):
            capture = True
        elif line.startswith("## ") and selected and not line.startswith("## Community Hubs"):
            capture = False
        if capture:
            selected.append(line)
        if len(selected) >= line_limit:
            break
    if not selected:
        selected = lines[:line_limit]
    return "\n".join(selected)


def _graph_context_payload(project_id: str, root: Path, status: dict[str, Any], *, budget: int) -> dict[str, Any]:
    report_context = _report_context(root)
    body = "\n".join(
        [
            "Graphify Context",
            "",
            "Use st graph query/path/explain for topology. Use st search for exact source facts.",
            "",
            *_compact_status_lines(status),
            "",
            report_context,
            "",
            "## Useful Commands",
            f"- st graph query --project {project_id} --budget 1200 \"{_DEFAULT_CONTEXT_QUESTION}\"",
            f"- st graph explain --project {project_id} \"<node>\"",
            f"- st graph path --project {project_id} \"<source>\" \"<target>\"",
            f"- st search -P {project_id} \"<symbol or route>\"",
        ]
    )
    truncated = truncate_to_tokens(body, budget)
    return {
        "project_id": project_id,
        "prompt_context": truncated,
        "metadata": {
            "budget": budget,
            "estimated_tokens": estimate_tokens(truncated),
            "diagnostics": status.get("diagnostics", []),
            "semantic_coverage": status.get("semantic_coverage"),
            "graph_stale": status.get("graph_stale", False),
            "node_count": status.get("node_count", 0),
            "edge_count": status.get("edge_count", 0),
            "community_count": status.get("community_count", 0),
        },
    }


def _semantic_refresh_prompt(project_id: str, root: Path, status: dict[str, Any]) -> str:
    diagnostics = ", ".join(str(item) for item in status.get("diagnostics", [])) or "-"
    return f"""Refresh Graphify semantic coverage for project `{project_id}` at `{root}`.

Use local project rules. Keep work scoped to Graphify artifacts and diagnostics.

Required workflow:
1. Run `st pulse --gate`.
2. Run `st graph status --project {project_id}`. If graph is stale/missing/unreadable, run `st graph refresh --project {project_id}` and re-check.
3. Inspect `graphify-out/.graphify_detect.json`. Process only non-code semantic sources: document, paper, image, video, audio. Current status diagnostics: {diagnostics}.
4. Use the Graphify skill extraction rules for semantic nodes/edges/hyperedges. Prefer Gemini via Agent Hub for semantic extraction when model calls are needed.
5. Merge semantic results into `graphify-out/graph.json`, regenerate `graphify-out/GRAPH_REPORT.md` and `graphify-out/graph.html`, then run `st graph status --project {project_id}`.
6. Keep stdout compact. Put large logs under `.dev-tools/`.

Do not perform unrelated refactors. Do not edit source code unless needed to repair Graphify tooling itself.
"""


def _semantic_sources(root: Path) -> list[tuple[str, Path]]:
    detect_path = root / "graphify-out" / ".graphify_detect.json"
    if not detect_path.exists():
        return []
    try:
        detect = json.loads(detect_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    files = detect.get("files", {})
    if not isinstance(files, dict):
        return []
    sources: list[tuple[str, Path]] = []
    for source_type in sorted(_SEMANTIC_SOURCE_TYPES):
        paths = files.get(source_type, [])
        if not isinstance(paths, list):
            continue
        for raw_path in paths:
            path = Path(str(raw_path))
            if not path.is_absolute():
                path = root / path
            if path.exists() and path.is_file():
                sources.append((source_type, path.resolve()))
    return sources


def _rel_source(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def _semantic_source_text(root: Path, source_type: str, path: Path) -> tuple[str, bool]:
    rel = _rel_source(root, path)
    suffix = path.suffix.lower()
    if suffix in _SEMANTIC_IMAGE_SUFFIXES:
        return f"=== {rel} ({source_type}, image attachment) ===\nUse attached image. Extract visible UI, labels, workflows, and domain concepts.", True
    if suffix in _SEMANTIC_TEXT_SUFFIXES or source_type in {"document", "paper"}:
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            content = ""
        return f"=== {rel} ({source_type}) ===\n{content[:20_000]}", False
    return f"=== {rel} ({source_type}) ===\nBinary source. Extract only filename-level concept if content is unavailable.", False


def _semantic_batch_size(root: Path, source_type: str, path: Path) -> int:
    text, _ = _semantic_source_text(root, source_type, path)
    return len(text)


def _semantic_batches(root: Path, sources: list[tuple[str, Path]]) -> list[list[tuple[str, Path]]]:
    batches: list[list[tuple[str, Path]]] = []
    current: list[tuple[str, Path]] = []
    current_chars = 0
    for item in sources:
        source_type, path = item
        size = _semantic_batch_size(root, source_type, path)
        if current and (len(current) >= _SEMANTIC_BATCH_MAX_FILES or current_chars + size > _SEMANTIC_BATCH_MAX_CHARS):
            batches.append(current)
            current = []
            current_chars = 0
        current.append(item)
        current_chars += size
    if current:
        batches.append(current)
    return batches


def _semantic_batch_prompt(root: Path, batch: list[tuple[str, Path]]) -> tuple[str, list[Path]]:
    sections: list[str] = []
    images: list[Path] = []
    source_list: list[str] = []
    for source_type, path in batch:
        rel = _rel_source(root, path)
        source_list.append(f"- {rel} ({source_type})")
        text, is_image = _semantic_source_text(root, source_type, path)
        sections.append(text)
        if is_image:
            images.append(path)
    return (
        "Extract Graphify semantic graph JSON for these non-code sources.\n"
        "Return JSON only. No markdown fences. No prose.\n\n"
        "Schema:\n"
        '{"nodes":[{"id":"source_entity","label":"Human Name","file_type":"document|paper|image|concept",'
        '"source_file":"relative/path","source_location":null}],'
        '{"edges":[{"source":"node_id","target":"node_id","relation":"references|cites|conceptually_related_to|shares_data_with|semantically_similar_to",'
        '"confidence":"EXTRACTED|INFERRED|AMBIGUOUS","confidence_score":1.0,"source_file":"relative/path","source_location":null,"weight":1.0}],'
        '"hyperedges":[]}\n\n'
        "Rules:\n"
        "- Use only these source_file values:\n"
        + "\n".join(source_list)
        + "\n- Create concise nodes for decisions, workflows, requirements, risks, concepts, screens, and docs.\n"
        "- Do not duplicate AST/code nodes. Do not extract secrets or credentials.\n"
        "- Keep IDs lowercase with only a-z, 0-9, underscore.\n\n"
        + "\n\n".join(sections),
        images,
    )


def _parse_semantic_fragment(raw: str) -> dict[str, Any]:
    text = strip_ansi(raw).strip()
    if text.startswith("Error:"):
        raise RuntimeError(text)
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    decoder = json.JSONDecoder()
    index = text.find("{")
    while index >= 0:
        try:
            payload, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            index = text.find("{", index + 1)
            continue
        if isinstance(payload, dict):
            return payload
        index = text.find("{", index + 1)
    raise RuntimeError("semantic extractor returned no JSON object")


def _safe_node_id(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "_", value).strip("_").lower()
    return cleaned or "semantic_node"


def _dedupe_node_id(node_id: str, used: set[str]) -> str:
    candidate = _safe_node_id(node_id)
    if candidate not in used:
        used.add(candidate)
        return candidate
    base = candidate
    index = 2
    while f"{base}_{index}" in used:
        index += 1
    candidate = f"{base}_{index}"
    used.add(candidate)
    return candidate


def _semantic_source_label(root: Path, path: Path) -> str:
    return _rel_source(root, path)


def _semantic_node_source_type(source_file: str, allowed_sources: dict[str, str]) -> str:
    file_type = allowed_sources[source_file]
    if file_type in _CODE_ONLY_NODE_TYPES:
        return allowed_sources[source_file]
    return file_type


def _sanitize_semantic_node(root: Path, batch: list[tuple[str, Path]], raw_node: dict[str, Any], used: set[str], allowed_sources: dict[str, str], id_map: dict[str, str]) -> dict[str, Any] | None:
    source_file = str(raw_node.get("source_file") or "")
    if source_file not in allowed_sources:
        return None
    label = str(raw_node.get("label") or raw_node.get("id") or Path(source_file).stem)
    original_id = str(raw_node.get("id") or f"{Path(source_file).stem}_{label}")
    node_id = _dedupe_node_id(original_id, used)
    id_map[_safe_node_id(original_id)] = node_id
    file_type = _semantic_node_source_type(source_file, allowed_sources)
    return {
        **raw_node,
        "id": node_id,
        "label": label[:160],
        "file_type": file_type,
        "source_file": source_file,
        "source_location": raw_node.get("source_location"),
    }


def _sanitize_semantic_edge(raw_edge: dict[str, Any], allowed_sources: dict[str, str], id_map: dict[str, str], valid_ids: set[str]) -> dict[str, Any] | None:
    source = id_map.get(_safe_node_id(str(raw_edge.get("source") or "")), str(raw_edge.get("source") or ""))
    target = id_map.get(_safe_node_id(str(raw_edge.get("target") or "")), str(raw_edge.get("target") or ""))
    if source not in valid_ids or target not in valid_ids or source == target:
        return None
    source_file = str(raw_edge.get("source_file") or "")
    if source_file not in allowed_sources:
        source_file = next(iter(allowed_sources))
    return {
        **raw_edge,
        "source": source,
        "target": target,
        "_src": source,
        "_tgt": target,
        "relation": str(raw_edge.get("relation") or "conceptually_related_to"),
        "confidence": str(raw_edge.get("confidence") or "INFERRED"),
        "confidence_score": float(raw_edge.get("confidence_score") or 0.8),
        "source_file": source_file,
        "source_location": raw_edge.get("source_location"),
        "weight": float(raw_edge.get("weight") or 1.0),
    }


def _sanitize_semantic_fragment(root: Path, batch: list[tuple[str, Path]], fragment: dict[str, Any], used: set[str]) -> dict[str, list[dict[str, Any]]]:
    allowed_sources = {_semantic_source_label(root, path): source_type for source_type, path in batch}
    nodes: list[dict[str, Any]] = []
    id_map: dict[str, str] = {}
    for raw_node in fragment.get("nodes", []):
        if not isinstance(raw_node, dict):
            continue
        node = _sanitize_semantic_node(root, batch, raw_node, used, allowed_sources, id_map)
        if node is not None:
            nodes.append(node)
    valid_ids = set(used)
    edges: list[dict[str, Any]] = []
    for raw_edge in fragment.get("edges", []):
        if not isinstance(raw_edge, dict):
            continue
        edge = _sanitize_semantic_edge(raw_edge, allowed_sources, id_map, valid_ids)
        if edge is not None:
            edges.append(edge)
    return {"nodes": nodes, "edges": edges, "hyperedges": []}


def _merge_semantic_fragments(root: Path, fragments: list[dict[str, list[dict[str, Any]]]], semantic_sources: list[tuple[str, Path]]) -> None:
    graph_path = root / "graphify-out" / "graph.json"
    data = json.loads(graph_path.read_text(encoding="utf-8"))
    semantic_rel_sources = {_rel_source(root, path) for _, path in semantic_sources}
    old_nodes = data.get("nodes", [])
    old_links = data.get("links", data.get("edges", []))
    removed_ids = {
        str(node.get("id"))
        for node in old_nodes
        if isinstance(node, dict)
        and str(node.get("file_type") or "") not in _CODE_ONLY_NODE_TYPES
        and str(node.get("source_file") or "") in semantic_rel_sources
    }
    nodes = [node for node in old_nodes if not (isinstance(node, dict) and str(node.get("id")) in removed_ids)]
    links = [
        edge
        for edge in old_links
        if isinstance(edge, dict)
        and str(edge.get("source") or edge.get("_src") or "") not in removed_ids
        and str(edge.get("target") or edge.get("_tgt") or "") not in removed_ids
        and str(edge.get("source_file") or "") not in semantic_rel_sources
    ]
    for fragment in fragments:
        nodes.extend(fragment["nodes"])
        links.extend(fragment["edges"])
    data["nodes"] = nodes
    data["links"] = links
    if "edges" in data:
        data.pop("edges", None)
    graph_path.write_text(json.dumps(data), encoding="utf-8")


def _semantic_batch_command(
    st_bin: str,
    project_id: str,
    agent: str,
    model: str | None,
    timeout: int,
    prompt_path: Path,
    images: list[Path],
) -> list[str]:
    command = [
        st_bin,
        "complete",
        "--agent",
        agent,
        "--project",
        project_id,
        "--roles",
        "agent_system_prompt",
        "--file",
        str(prompt_path),
        "--timeout",
        str(timeout),
        "--skip-cache",
    ]
    if model:
        command[4:4] = ["-M", model]
    for image in images:
        command.extend(["--image", str(image)])
    return command


def _run_semantic_batch_command(command: list[str], root: Path, timeout: int, batch_index: int) -> str:
    output = ""
    for attempt in range(1, 4):
        result = subprocess.run(command, cwd=root, text=True, capture_output=True, timeout=timeout + 30, check=False)
        output = _command_output(result)
        if result.returncode == 0 and not output.startswith("Error:"):
            return output
        if attempt == 3 or "Internal server error" not in output:
            raise RuntimeError(output[-4000:] or f"batch {batch_index} exited {result.returncode}")
        time.sleep(2 * attempt)
    return output


def _semantic_refresh_batch_result(
    project_id: str,
    root: Path,
    *,
    agent: str,
    model: str | None,
    timeout: int,
    batch_index: int,
    batch_count: int,
    batch: list[tuple[str, Path]],
    st_bin: str,
    used_ids: set[str],
) -> tuple[dict[str, list[dict[str, Any]]], str, list[Path]]:
    prompt, images = _semantic_batch_prompt(root, batch)
    prompt_path = write_details(root, f"graphify-semantic-batch-{batch_index:03d}-prompt", prompt)
    command = _semantic_batch_command(st_bin, project_id, agent, model, timeout, prompt_path, images)
    output = _run_semantic_batch_command(command, root, timeout, batch_index)
    fragment = _parse_semantic_fragment(output)
    sanitized = _sanitize_semantic_fragment(root, batch, fragment, used_ids)
    return sanitized, output, images


def _semantic_refresh_summary_line(batch_index: int, batch_count: int, batch: list[tuple[str, Path]], sanitized: dict[str, list[dict[str, Any]]]) -> str:
    return f"batch={batch_index}/{batch_count} files={len(batch)} nodes={len(sanitized['nodes'])} edges={len(sanitized['edges'])}"


def _semantic_refresh_initial_state(project_id: str, root: Path, agent: str | None, model: str | None) -> tuple[dict[str, Any], list[tuple[str, Path]], list[list[tuple[str, Path]]], str]:
    status = _status_for_project_root(project_id, root, auto_refresh=True, action="semantic-refresh")
    sources = _semantic_sources(root)
    batches = _semantic_batches(root, sources) if sources else []
    st_bin = shutil.which("st") or sys.argv[0]
    return status, sources, batches, st_bin


def _semantic_refresh_used_ids(root: Path) -> set[str]:
    return {
        str(node.get("id"))
        for node in json.loads((root / "graphify-out" / "graph.json").read_text(encoding="utf-8")).get("nodes", [])
        if isinstance(node, dict) and node.get("id")
    }


def _semantic_refresh_result_counts(refreshed_status: dict[str, Any]) -> tuple[int, int, list[str]]:
    semantic_source_count = int(refreshed_status.get("semantic_source_count", 0) or 0)
    semantic_node_count = int(refreshed_status.get("semantic_node_count", 0) or 0)
    diagnostics = [str(item) for item in refreshed_status.get("diagnostics", [])]
    return semantic_source_count, semantic_node_count, diagnostics


def _semantic_refresh_write_summary(root: Path, start: float, batches: list[list[tuple[str, Path]]], details_lines: list[str], exit_code: int, refreshed_status: dict[str, Any]) -> int:
    semantic_source_count, semantic_node_count, diagnostics = _semantic_refresh_result_counts(refreshed_status)
    elapsed_ms = round((time.perf_counter() - start) * 1000)
    details = write_details(root, "graphify-semantic-refresh", "\n".join(details_lines))
    print(
        f"GRAPH_SEMANTIC_REFRESH:{'OK' if exit_code == 0 else 'FAIL'}:{exit_code}|"
        f"elapsed_ms={elapsed_ms}|batches={len(batches)}|semantic={semantic_node_count}/"
        f"{semantic_source_count}|diagnostics={','.join(diagnostics) or '-'}|"
        f"details:{display_path(root, details)}"
    )
    return exit_code


def _run_semantic_refresh_batches(
    project_id: str,
    root: Path,
    *,
    agent: str | None,
    model: str | None,
    timeout: int,
) -> int:
    if not agent:
        raise typer.BadParameter("semantic-refresh requires --agent with a purpose-built Agent Hub agent slug")
    status, sources, batches, st_bin = _semantic_refresh_initial_state(project_id, root, agent, model)
    if not sources:
        print(f"GRAPH_SEMANTIC_REFRESH:OK:0|semantic=0/0|diagnostics={','.join(status.get('diagnostics', [])) or '-'}")
        return 0
    fragments: list[dict[str, list[dict[str, Any]]]] = []
    used_ids = _semantic_refresh_used_ids(root)
    start = time.perf_counter()
    details_lines = [f"semantic_sources={len(sources)} batches={len(batches)} agent={agent} model={model or 'agent-default'}"]
    try:
        for index, batch in enumerate(batches, start=1):
            sanitized, _, _ = _semantic_refresh_batch_result(
                project_id,
                root,
                agent=agent,
                model=model,
                timeout=timeout,
                batch_index=index,
                batch_count=len(batches),
                batch=batch,
                st_bin=st_bin,
                used_ids=used_ids,
            )
            fragments.append(sanitized)
            details_lines.append(_semantic_refresh_summary_line(index, len(batches), batch, sanitized))
        _merge_semantic_fragments(root, fragments, sources)
        refresh_result = run_graphify(root, ["cluster-only", str(root)], timeout=timeout)
        details_lines.append(refresh_result.output)
        refreshed_status = graphify_status(project_id, root)
        _, semantic_node_count, diagnostics = _semantic_refresh_result_counts(refreshed_status)
        exit_code = 0 if semantic_node_count > 0 and "semantic_sources_not_extracted" not in diagnostics else 1
    except (OSError, RuntimeError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        refreshed_status = graphify_status(project_id, root)
        _, semantic_node_count, diagnostics = _semantic_refresh_result_counts(refreshed_status)
        details_lines.append(f"ERROR: {type(exc).__name__}: {exc}")
        exit_code = 1
    return _semantic_refresh_write_summary(root, start, batches, details_lines, exit_code, refreshed_status)


def _semantic_refresh_agent_command(
    st_bin: str,
    project_id: str,
    root: Path,
    agent: str,
    model: str | None,
    timeout: int,
    prompt_path: Path,
) -> list[str]:
    command = [
        st_bin,
        "agent",
        "run",
        "--agent",
        agent,
        "--project",
        project_id,
        "--working-dir",
        str(root),
        "--file",
        str(prompt_path),
        "--timeout",
        str(timeout),
    ]
    if model:
        command[5:5] = ["-M", model]
    return command


def _run_semantic_refresh_agent(
    project_id: str,
    root: Path,
    *,
    agent: str | None,
    model: str | None,
    max_turns: int,
    timeout: int,
) -> int:
    del max_turns
    status = _status_for_project_root(project_id, root, auto_refresh=True, action="semantic-refresh")
    prompt = _semantic_refresh_prompt(project_id, root, status)
    prompt_path = write_details(root, "graphify-semantic-refresh-prompt", prompt)
    st_bin = shutil.which("st") or sys.argv[0]
    if not agent:
        raise typer.BadParameter("semantic-refresh requires --agent with a purpose-built Agent Hub agent slug")
    command = _semantic_refresh_agent_command(st_bin, project_id, root, agent, model, timeout, prompt_path)
    start = time.perf_counter()
    try:
        result = subprocess.run(command, cwd=root, text=True, capture_output=True, timeout=timeout + 30, check=False)
        output = _command_output(result)
        exit_code = result.returncode
        if output.startswith("Error:"):
            exit_code = exit_code or 1
    except (OSError, subprocess.SubprocessError) as exc:
        output = f"{type(exc).__name__}: {exc}"
        exit_code = 127
    elapsed_ms = round((time.perf_counter() - start) * 1000)
    details = write_details(root, "graphify-semantic-refresh", output)
    refreshed_status = graphify_status(project_id, root)
    semantic_source_count, semantic_node_count, diagnostics = _semantic_refresh_result_counts(refreshed_status)
    if semantic_source_count and (semantic_node_count == 0 or "semantic_sources_not_extracted" in diagnostics):
        exit_code = exit_code or 1
    print(
        f"GRAPH_SEMANTIC_REFRESH:{'OK' if exit_code == 0 else 'FAIL'}:{exit_code}|"
        f"elapsed_ms={elapsed_ms}|semantic={semantic_node_count}/"
        f"{semantic_source_count}|"
        f"diagnostics={','.join(diagnostics) or '-'}|"
        f"prompt:{display_path(root, prompt_path)}|details:{display_path(root, details)}"
    )
    return exit_code


@app.command("status")
def _status_payload(all_projects: bool, refresh: bool, project: str | None) -> dict[str, Any] | list[dict[str, Any]]:
    if all_projects:
        projects = _all_projects()
        return [
            _status_for_project_root(
                str(item["id"]),
                _root_from_project_payload(str(item["id"]), item),
                auto_refresh=refresh,
                create_missing=False,
            )
            for item in projects
            if item.get("id")
        ]
    return _status_for_project(_project_id(project), auto_refresh=refresh)


@app.command("status")
def status(
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to current project.")] = None,
    all_projects: Annotated[bool, typer.Option("--all", help="Show every registered project.")] = False,
    refresh: Annotated[bool, typer.Option("--refresh/--no-refresh", help="Refresh stale code graphs before reporting.")] = True,
) -> None:
    """Show Graphify status and diagnostics."""
    output_json(_status_payload(all_projects, refresh, project))


@app.command("doctor")
@usage(
    surface="st.graph.doctor",
    cmd="st graph doctor --project <project>",
    when="Graphify health; auto-refreshes stale code graph",
    task_types=("exploration", "refactor", "backend"),
    tier="reference",
)
def _doctor_statuses(project: str | None, refresh: bool) -> list[dict[str, Any]]:
    if project:
        project_id = _project_id(project)
        return [_status_for_project(project_id, auto_refresh=refresh, action="doctor", create_missing=True)]
    projects = _all_projects()
    return [
        _status_for_project_root(
            str(item["id"]),
            _root_from_project_payload(str(item["id"]), item),
            auto_refresh=refresh,
            action="doctor",
            create_missing=False,
        )
        for item in projects
        if item.get("id")
    ]


def _doctor_items(statuses: list[dict[str, Any]], *, blocking: bool) -> list[dict[str, Any]]:
    return [
        {
            "project_id": item["project_id"],
            "diagnostics": [
                diagnostic
                for diagnostic in item["diagnostics"]
                if (diagnostic in _DOCTOR_BLOCKING_DIAGNOSTICS) is blocking
            ],
            "changed_files_since_graph": item["changed_files_since_graph"],
        }
        for item in statuses
        if (_issue_count(item) if blocking else _warning_count(item))
    ]


def _doctor_result(statuses: list[dict[str, Any]]) -> dict[str, Any]:
    issues = _doctor_items(statuses, blocking=True)
    warnings = _doctor_items(statuses, blocking=False)
    return {
        "status": "ISSUES" if issues else "OK",
        "projects": len(statuses),
        "issues": issues,
        "warnings": warnings,
        "issue_count": sum(_issue_count(item) for item in statuses),
        "warning_count": sum(_warning_count(item) for item in statuses),
    }


@app.command("doctor")
def doctor(
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to every project.")] = None,
    refresh: Annotated[bool, typer.Option("--refresh/--no-refresh", help="Refresh stale code graphs before diagnosis.")] = True,
) -> None:
    """Report Graphify issues that affect agent usefulness."""
    statuses = _doctor_statuses(project, refresh)
    result = _doctor_result(statuses)
    output_json(result)
    if result["issues"]:
        raise typer.Exit(2)


@app.command("refresh")
def refresh(
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to current project.")] = None,
) -> None:
    """Refresh a project's code-only Graphify graph."""
    project_id = _project_id(project)
    root = _root_for_project(project_id)
    result = refresh_graph(root)
    output_json({"project_id": project_id, **_command_payload(result), "status": _status_for_project_root(project_id, root)})


@app.command("context")
def context(
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to current project.")] = None,
    budget: Annotated[int, typer.Option("--budget", min=200, max=8000, help="Prompt context token budget.")] = 1200,
) -> None:
    """Emit compact Graphify context for agents."""
    project_id = _project_id(project)
    root = _fresh_root_for_project(project_id, action="context")
    status = graphify_status(project_id, root)
    output_json(_graph_context_payload(project_id, root, status, budget=budget))


@app.command("semantic-refresh")
def semantic_refresh(
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to current project.")] = None,
    agent: Annotated[str | None, typer.Option("--agent", "-a", help="Purpose-built Agent Hub agent slug.")] = (
        "graphify-semantic-extractor"
    ),
    model: Annotated[
        str | None,
        typer.Option("--model", "-M", help="Optional model override. Defaults to the agent model chain."),
    ] = None,
    timeout: Annotated[int, typer.Option("--timeout", min=60, max=7200, help="Agent Hub read timeout seconds.")] = 1800,
    execute: Annotated[bool, typer.Option("--execute/--no-execute", help="Run Agent Hub; otherwise write prompt and print command.")] = True,
) -> None:
    """Launch an explicit semantic Graphify refresh through Agent Hub."""
    project_id = _project_id(project)
    root = _root_for_project(project_id)
    if not execute:
        status = _status_for_project_root(project_id, root, auto_refresh=True, action="semantic-refresh")
        prompt_path = write_details(root, "graphify-semantic-refresh-prompt", _semantic_refresh_prompt(project_id, root, status))
        print(
            "GRAPH_SEMANTIC_REFRESH:READY|"
            f"project={project_id}|prompt:{display_path(root, prompt_path)}|"
            f"mode=batch|agent={agent}|model={model or 'agent-default'}"
        )
        return
    raise typer.Exit(
        _run_semantic_refresh_batches(
            project_id,
            root,
            agent=agent,
            model=model,
            timeout=timeout,
        )
    )


@app.command("query")
def query(
    question: Annotated[str, typer.Argument(help="Topology question.")],
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to current project.")] = None,
    budget: Annotated[int, typer.Option("--budget", min=100, max=8000, help="Graphify token budget.")] = 1200,
    dfs: Annotated[bool, typer.Option("--dfs", help="Use depth-first traversal.")] = False,
) -> None:
    """Run Graphify query against a project graph."""
    result = query_graph(_fresh_root_for_project(_project_id(project), action="query"), question, budget=budget, dfs=dfs)
    output_json(_command_payload(result))


@app.command("path")
def path(
    source: Annotated[str, typer.Argument(help="Source node label.")],
    target: Annotated[str, typer.Argument(help="Target node label.")],
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to current project.")] = None,
) -> None:
    """Find shortest Graphify path between two nodes."""
    result = path_graph(_fresh_root_for_project(_project_id(project), action="path"), source, target)
    output_json(_command_payload(result))


@app.command("explain")
def explain(
    node: Annotated[str, typer.Argument(help="Node label.")],
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to current project.")] = None,
) -> None:
    """Explain one graph node and its neighbors."""
    result = explain_graph(_fresh_root_for_project(_project_id(project), action="explain"), node)
    output_json(_command_payload(result))


@app.command("fallow")
def fallow(
    mode: Annotated[
        str,
        typer.Argument(help="Fallow mode: audit, changed, health, plugins, flags, dead-code, dupes."),
    ] = "audit",
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to current project.")] = None,
    changed_since: Annotated[str, typer.Option("--changed-since", help="Git ref for changed mode.")] = "main",
    top: Annotated[int, typer.Option("--top", min=1, max=100, help="Clone groups for dupes mode.")] = 10,
    timeout: Annotated[int, typer.Option("--timeout", min=5, max=600, help="Command timeout in seconds.")] = 120,
) -> None:
    """Run Fallow with compact stdout and full details in .dev-tools."""
    raise typer.Exit(
        run_fallow_compact(
            _root_for_project(_project_id(project)),
            mode,
            changed_since=changed_since,
            top=top,
            timeout=timeout,
        )
    )


@app.command("profile")
def _profile_runs(project_id: str, root: Path, question: str, budget: int, st_bin: str) -> list[dict[str, Any]]:
    return [
        _run_measured([st_bin, "-P", project_id, "search", question], cwd=root),
        _command_payload(query_graph(root, question, budget=budget)),
    ]


def _profile_codex_probes(root: Path) -> list[dict[str, Any]]:
    codex_bin = shutil.which("codex")
    if not codex_bin:
        return [{"tool": "codex", "available": False}]
    return [
        _run_measured([codex_bin, "--version"], cwd=root, timeout=30),
        _run_measured([codex_bin, "exec", "--help"], cwd=root, timeout=30),
    ]


def _profile_agent_hub_probe(st_bin: str, project_id: str, question: str, root: Path) -> dict[str, Any]:
    return _run_measured(
        [
            st_bin,
            "-P",
            "agent-hub",
            "agents",
            "preview",
            "explorer",
            "-P",
            project_id,
            "--input",
            question,
            "--json",
        ],
        cwd=root,
        timeout=90,
    )


@app.command("profile")
def profile(
    question: Annotated[
        str,
        typer.Option("--question", "-q", help="Architecture question to profile."),
    ] = "What are the central modules and relationship patterns in this project?",
    project: Annotated[str | None, typer.Option("--project", "-p", help="Project id. Defaults to current project.")] = None,
    budget: Annotated[int, typer.Option("--budget", min=100, max=8000, help="Graphify token budget.")] = 1200,
    codex: Annotated[bool, typer.Option("--codex", help="Probe Codex CLI availability and startup cost.")] = False,
    agent_hub: Annotated[bool, typer.Option("--agent-hub", help="Probe Agent Hub completion CLI availability.")] = False,
    gitnexus: Annotated[
        bool,
        typer.Option("--gitnexus", help="Evaluate optional GitNexus fit without installing or mutating MCP config."),
    ] = False,
    fallow: Annotated[
        bool,
        typer.Option("--fallow", help="Evaluate optional Fallow JS/TS codebase-intelligence fit."),
    ] = False,
) -> None:
    """Profile st search vs Graphify command shapes for agent work."""
    project_id = _project_id(project)
    root = _fresh_root_for_project(project_id, action="profile")
    st_bin = shutil.which("st") or sys.argv[0]
    runs = _profile_runs(project_id, root, question, budget, st_bin)
    tool_probes: list[dict[str, Any]] = []
    if codex:
        tool_probes.extend(_profile_codex_probes(root))
    if agent_hub:
        tool_probes.append(_profile_agent_hub_probe(st_bin, project_id, question, root))
    if gitnexus:
        tool_probes.append(_gitnexus_profile(root))
    if fallow:
        tool_probes.append(_fallow_profile(root))
    output_json(
        {
            "project_id": project_id,
            "question": question,
            "runs": runs,
            "tool_probes": tool_probes,
            "recommendation": "Use st search for exact symbols/files; use st graph query/path/explain for topology; use Fallow for JS/TS changed-code health; use GitNexus for indexed symbol impact.",
        }
    )
