"""Entrypoint for the native precision-search command owner."""

from st_sdk.runtime import run_app

from .search import app


def main() -> None:
    run_app(app, "code-search")
