"""Entrypoint for the native graph command owner."""

from st_sdk.runtime import run_app

from .graph import app


def main() -> None:
    run_app(app, "code-graph")
