"""Checkout-overlay and output helpers for precision code search."""
