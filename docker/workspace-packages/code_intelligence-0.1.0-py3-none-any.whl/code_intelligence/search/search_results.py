"""Result assembly lives in code_intelligence.precision.current_search.

The former string prompt merger could repeat symbols and overstate savings.
Callers pass structured candidates to the shared assembler instead.
"""
