"""Checkout precision adapter for the shared current-source assembler."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from code_intelligence.precision.current_search import collect_current_search_context


def _build_checkout_precision_result(
    query: str,
    checkout_root: Path,
    budget: int,
    limit: int,
    *,
    path_prefix: str | None = None,
    indexed_candidates: list[dict[str, object]] | None = None,
) -> dict[str, Any]:
    """Build a source-verified checkout result using the common owner."""
    result = collect_current_search_context(
        "",
        query,
        project_root=checkout_root,
        search_text=lambda *_args, **_kwargs: {"items": []},
        indexed_candidates=indexed_candidates if indexed_candidates is not None else [],
        budget_tokens=budget,
        symbol_limit=limit,
        path_prefix=path_prefix,
    )
    return {"query": query, "prompt_context": result.prompt_context, "metadata": result.metadata}
