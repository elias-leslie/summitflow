"""Checkout text search helpers for `st search`."""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Any

from .search_checkout_paths import (
    CHECKOUT_RIPGREP_TIMEOUT_SECONDS,
    LINE_PREVIEW_LIMIT,
    _is_test_path,
    _iter_checkout_files,
    _normalize_rel_path,
    _path_matches_prefix,
    _resolve_checkout_path_prefix,
    code_search_exclude_globs,
    is_code_search_path,
)


def _empty_text_result(query: str, normalized_prefix: str | None) -> dict[str, Any]:
    return {
        "query": query,
        "count": 0,
        "files_searched": 0,
        "items": [],
        "truncated": False,
        "next_offset": None,
        "scope": "checkout",
        "path_prefix": normalized_prefix,
    }


def _search_checkout_text(
    root: Path,
    query: str,
    *,
    limit: int,
    path_prefix: str | None = None,
    offset: int = 0,
) -> dict[str, Any]:
    """Search the current checkout directly from the filesystem."""
    if limit < 1 or offset < 0:
        raise ValueError("limit must be positive and offset must be nonnegative")
    query_value = query.strip()
    normalized_prefix, target_root = _resolve_checkout_path_prefix(root, path_prefix)
    if not query_value or (normalized_prefix and target_root is None):
        return _empty_text_result(query, normalized_prefix)

    all_checkout_files = _iter_checkout_files(root, start_root=target_root)
    if rg_result := _search_checkout_text_with_rg(root, query, query_value, normalized_prefix, limit, all_checkout_files, offset):
        return rg_result
    return _search_checkout_text_with_python(root, query, query_value, normalized_prefix, limit, all_checkout_files, offset)


def _search_checkout_text_with_rg(
    root: Path,
    query: str,
    query_value: str,
    normalized_prefix: str | None,
    limit: int,
    all_checkout_files: list[Path],
    offset: int,
) -> dict[str, Any] | None:
    rg_path = shutil.which("rg")
    if not rg_path:
        return None
    args = [
        rg_path,
        "--line-number",
        "--with-filename",
        "--ignore-case",
        "--fixed-strings",
        "--hidden",
        "--no-ignore",
    ]
    for glob in code_search_exclude_globs(normalized_prefix):
        args.extend(["--glob", glob])
    args.extend(["--", query_value, normalized_prefix or "."])
    try:
        proc = subprocess.run(
            args,
            cwd=root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=CHECKOUT_RIPGREP_TIMEOUT_SECONDS,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if proc.returncode not in (0, 1):
        return None
    return _text_result_from_rg_output(root, query, normalized_prefix, limit, all_checkout_files, proc, offset)


def _text_result_from_rg_output(
    root: Path,
    query: str,
    normalized_prefix: str | None,
    limit: int,
    all_checkout_files: list[Path],
    proc: subprocess.CompletedProcess[str],
    offset: int,
) -> dict[str, Any]:
    items: list[dict[str, Any]] = []
    total_matches = 0
    for raw_line in sorted(
        proc.stdout.splitlines(),
        key=lambda line: (_is_test_path(line.partition(":")[0]), line.partition(":")[0], line),
    ):
        path_part, sep, remainder = raw_line.partition(":")
        if not sep:
            continue
        line_part, sep, content = remainder.partition(":")
        if not sep:
            continue
        rel_path = path_part[2:] if path_part.startswith("./") else path_part
        if not _path_matches_prefix(rel_path, normalized_prefix) or not is_code_search_path(rel_path, path_prefix=normalized_prefix):
            continue
        try:
            line_number = int(line_part)
        except ValueError:
            continue
        total_matches += 1
        if total_matches > offset and len(items) < limit:
            items.append(_text_item(rel_path, line_number, content, None))
    return _text_result(root, query, normalized_prefix, items, len(all_checkout_files), total_matches > offset + len(items), total_matches=total_matches, offset=offset)


def _search_checkout_text_with_python(
    root: Path,
    query: str,
    query_value: str,
    normalized_prefix: str | None,
    limit: int,
    all_checkout_files: list[Path],
    offset: int,
) -> dict[str, Any]:
    query_lower = query_value.lower()
    items: list[dict[str, Any]] = []
    files_searched = 0
    total_matches = 0
    for path in sorted(
        all_checkout_files,
        key=lambda item: (_is_test_path(_normalize_rel_path(root, item) or ""), item.as_posix()),
    ):
        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        files_searched += 1
        rel_path = _normalize_rel_path(root, path)
        if rel_path is None or not _path_matches_prefix(rel_path, normalized_prefix):
            continue
        total_matches += _append_python_text_matches(items, path, rel_path, content, query_lower, limit, offset, total_matches)
    return _text_result(root, query, normalized_prefix, items, files_searched, total_matches > offset + len(items), total_matches=total_matches, offset=offset, strategy="checkout_fallback")


def _append_python_text_matches(
    items: list[dict[str, Any]],
    path: Path,
    rel_path: str,
    content: str,
    query_lower: str,
    limit: int,
    offset: int,
    seen_matches: int,
) -> int:
    matches = 0
    for line_number, line in enumerate(content.splitlines(), start=1):
        if query_lower not in line.lower():
            continue
        matches += 1
        if seen_matches + matches > offset and len(items) < limit:
            items.append(_text_item(rel_path, line_number, line, path.suffix.lower().lstrip(".")))
    return matches


def _text_item(rel_path: str, line_number: int, content: str, language: str | None) -> dict[str, Any]:
    return {
        "path": rel_path,
        "line": line_number,
        "content": content[:LINE_PREVIEW_LIMIT],
        "language": language,
        "truncated_file": False,
    }


def _text_result(
    root: Path,
    query: str,
    normalized_prefix: str | None,
    items: list[dict[str, Any]],
    files_searched: int,
    truncated: bool,
    *,
    strategy: str = "checkout_ripgrep",
    total_matches: int | None = None,
    offset: int = 0,
) -> dict[str, Any]:
    return {
        "query": query,
        "count": total_matches if total_matches is not None else len(items),
        "files_searched": files_searched,
        "items": items,
        "truncated": truncated,
        "next_offset": offset + len(items) if truncated else None,
        "strategy": strategy,
        "scope": "checkout",
        "root_path": str(root),
        "path_prefix": normalized_prefix,
    }
