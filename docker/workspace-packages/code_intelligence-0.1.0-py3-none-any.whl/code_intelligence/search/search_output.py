"""Compact output helpers for `st search`."""

from __future__ import annotations

from typing import Any

from code_intelligence.precision.token_utils import estimate_tokens

from .search_checkout import _normalize_path_prefix
from .search_hints import HINT_PREFIX, generate_hint


def _path_suffix(path_prefix: str | None) -> str:
    """Return a compact path suffix when search is restricted to a subtree/file."""
    normalized_prefix = _normalize_path_prefix(path_prefix)
    return f"|path={normalized_prefix}" if normalized_prefix else ""


def _page_suffix(result: dict[str, Any]) -> str:
    next_offset = result.get("next_offset")
    return f"|next={next_offset}" if next_offset is not None else ""


def _print_precision_compact(
    query: str, prompt_context: str, metadata: dict[str, Any], *, show_hint: bool = True
) -> None:
    """Print TOON-style compact output for agent consumption."""
    symbol_count = metadata.get("symbol_count", 0)
    if metadata.get("used_symbol_first"):
        mode = "combined" if metadata.get("used_fallback") else "symbol-first"
    else:
        mode = "text-fallback"
    tokens_saved = (
        metadata.get("estimated_tokens_saved", 0)
        if metadata.get("measurement_available", True)
        else "unmeasured"
    )
    final_tokens = metadata.get("final_tokens", 0)
    suffix = _path_suffix(metadata.get("path_prefix"))
    if metadata.get("measurement_available"):
        suffix += "|baseline=hypothetical-whole-files"
    if any(metadata.get(key) for key in ("prompt_truncated", "symbol_truncated", "text_truncated")):
        suffix += "|truncated=1"

    if not prompt_context:
        saved = "unmeasured" if not metadata.get("measurement_available", True) else 0
        lines = [f"SEARCH:{query}|mode=empty|symbols=0|tokens=0|whole_file_reduction_estimate={saved}{suffix}"]
        if show_hint and (hint_text := generate_hint(query, "empty", metadata)):
            lines.append(f"{HINT_PREFIX}{hint_text}")
        output = "\n".join(lines)
        metadata["emitted_output_tokens"] = estimate_tokens(output + "\n")
        print(output)
        return

    lines = [
        f"SEARCH:{query}|mode={mode}|symbols={symbol_count}|tokens={final_tokens}|whole_file_reduction_estimate={tokens_saved}{suffix}"
    ]
    if show_hint and (hint_text := generate_hint(query, mode, metadata)):
        lines.append(f"{HINT_PREFIX}{hint_text}")
    lines.extend(["", prompt_context])
    output = "\n".join(lines)
    metadata["emitted_output_tokens"] = estimate_tokens(output + "\n")
    print(output)


def _print_text_compact(query: str, result: dict[str, Any]) -> None:
    """Print TOON-style compact text search output."""
    items = result.get("items", [])
    count = result.get("count", len(items) if isinstance(items, list) else 0)
    files_searched = result.get("files_searched", 0)
    suffix = f"{_path_suffix(result.get('path_prefix'))}{_page_suffix(result)}"

    if not items and not count:
        print(f"SEARCH:{query}|mode=empty|symbols=0|tokens=0{suffix}")
        return

    print(f"SEARCH:{query}|mode=text|matches={count}|files={files_searched}{suffix}")
    print()
    for item in items:
        if isinstance(item, dict):
            print(f"- {item.get('path', 'unknown')}:{item.get('line', '?')} | {item.get('content', '')}")


def _print_symbols_compact(query: str, result: dict[str, Any]) -> None:
    """Print TOON-style compact symbol search output."""
    items = result.get("items", [])
    count = result.get("count", len(items) if isinstance(items, list) else 0)
    suffix = f"{_path_suffix(result.get('path_prefix'))}{_page_suffix(result)}"

    if not items and not count:
        print(f"SEARCH:{query}|mode=empty|symbols=0|tokens=0{suffix}")
        return

    print(f"SEARCH:{query}|mode=symbols|symbols={count}{suffix}")
    print()
    for item in items:
        if isinstance(item, dict):
            print(
                f"- `{item.get('qualified_name', item.get('name', 'unknown'))}` "
                f"({item.get('kind', 'unknown')}) {item.get('file_path', 'unknown')}:{item.get('start_line', '?')}"
            )


def _print_file_symbols_compact(file_path: str, result: dict[str, Any], *, show_hint: bool = True) -> None:
    """Print TOON-style compact output for file symbol listing."""
    items = result.get("items", [])
    count = result.get("count", len(items) if isinstance(items, list) else 0)
    resolved_suffix = f"|resolved_from={result['resolved_from']}" if result.get("resolved_from") else ""
    resolved_suffix += _page_suffix(result)

    if not items and not count:
        print(f"SEARCH:--file {file_path}|mode=empty|symbols=0|tokens=0{resolved_suffix}")
        if show_hint:
            _print_file_empty_hint(file_path, result)
        return

    print(f"SEARCH:--file {file_path}|mode=file-symbols|symbols={count}{resolved_suffix}")
    print()
    for item in items:
        if isinstance(item, dict):
            print(_format_file_symbol(item))


def _print_file_empty_hint(file_path: str, result: dict[str, Any]) -> None:
    candidates = result.get("candidates") or []
    if candidates:
        listed = ", ".join(f"`{c}`" for c in candidates)
        print(f"{HINT_PREFIX}`{file_path}` matches multiple files — rerun with one exact path: {listed}")
    elif result.get("file_exists") or result.get("resolved_from"):
        print(
            f"{HINT_PREFIX}`{file_path}` has no extractable symbols (unsupported language or no definitions) — "
            'use `st search --text "<phrase>"` or read the file directly'
        )
    else:
        print(
            f"{HINT_PREFIX}no file matching `{file_path}` found — a basename or path-suffix fragment also resolves; "
            "check the spelling or pass the path relative to the search root"
        )


def _print_hint(query: str, mode: str, metadata: dict[str, Any], show_hint: bool) -> None:
    if show_hint and (hint_text := generate_hint(query, mode, metadata)):
        print(f"{HINT_PREFIX}{hint_text}")


def _format_file_symbol(item: dict[str, Any]) -> str:
    kind = item.get("kind", "unknown")
    name = item.get("qualified_name", item.get("name", "unknown"))
    line = item.get("start_line", "?")
    detail = item.get("signature", "") or item.get("summary", "")
    suffix = f" - {detail}" if detail else ""
    return f"- `{name}` ({kind}) :{line}{suffix}"
