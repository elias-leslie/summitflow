"""Prompt budget helpers for `st search`."""

from __future__ import annotations

from code_intelligence.precision.token_utils import estimate_tokens


def truncate_prompt_to_budget(text: str, budget: int) -> str:
    """Trim prompt text until the local token estimator is within the requested budget."""
    if budget <= 0:
        return ""
    if estimate_tokens(text) <= budget:
        return text
    marker = "\n[... truncated ...]"
    lines: list[str] = []
    in_code = False
    for line in text.splitlines():
        next_code = in_code ^ (line.strip() == "```")
        closing_fence = "\n```" if next_code else ""
        candidate = "\n".join([*lines, line]).rstrip()
        if estimate_tokens(candidate + closing_fence + marker) > budget:
            break
        lines.append(line)
        in_code = next_code
    prefix = "\n".join(lines).rstrip()
    suffix = "\n```" if in_code else ""
    result = (prefix + suffix + marker).strip()
    return result if estimate_tokens(result) <= budget else ""
