"""Checkout path and process helpers for `st search`."""

from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

SUPPORTED_SYMBOL_EXTENSIONS = {".py", ".ts", ".tsx"}
CHECKOUT_EXCLUDE_GLOBS = (
    "!**/.git/**",
    "!**/node_modules/**",
    "!**/.venv/**",
    "!**/.next/**",
    "!**/dist/**",
    "!**/build/**",
    "!**/coverage/**",
    "!**/.dev-tools/**",
    "!**/.st/**",
    "!**/.summitflow/**",
    "!**/.pytest_cache/**",
    "!**/.ruff_cache/**",
    "!**/graphify-out/**",
    "!**/.env*",
    "!**/*.pem",
    "!**/*.key",
    "!**/credentials.json",
    "!**/secrets.json",
    "!**/secrets/**",
    "!**/credentials/**",
)
CHECKOUT_EXCLUDE_DIRS = {".git", "node_modules", ".venv", ".next", "dist", "build", "coverage", "__pycache__", "secrets", "credentials", ".dev-tools", ".st", ".summitflow", ".pytest_cache", ".ruff_cache", "graphify-out"}
CHECKOUT_EXCLUDE_NAMES = {"credentials.json", "secrets.json"}
CHECKOUT_EXCLUDE_SUFFIXES = {".pem", ".key"}
# SQL-compatible equivalent of permanent path exclusions for host indexes.
SEARCH_UNSEARCHABLE_PATH_REGEX = (
    r"(^|/)(\.env[^/]*|credentials\.json|secrets\.json|"
    + "|".join(re.escape(part) for part in sorted(CHECKOUT_EXCLUDE_DIRS))
    + r")(/|$)|(^|/)[^/]*\.(pem|key)(/|$)|^/|(^|/)\.\.(/|$)"
)
# Root-relative, observed generated source/output trees only. Shared with hosts
# so existing index rows can be excluded before candidate/page limits.
SEARCH_ARTIFACT_PATH_REGEX = (
    r"^data/artifacts/source-scans/[^/]+/snapshot(/|$)"
    r"|^tests/evaluation/(runs|snapshots)(/|$)"
    r"|^tests/evaluation/verifier/raw-[^/]+(/|$)"
    r"|^tests/evaluation/integration/[^/]+\.(txt|json)$"
)
SEARCH_ARTIFACT_EXCLUDE_GLOBS = (
    "!data/artifacts/source-scans/*/snapshot/**",
    "!tests/evaluation/runs/**",
    "!tests/evaluation/snapshots/**",
    "!tests/evaluation/verifier/raw-*/**",
    "!tests/evaluation/integration/*.txt",
    "!tests/evaluation/integration/*.json",
)


def is_search_artifact_path(path: str) -> bool:
    """Whether a root-relative path belongs to an observed retained artifact."""
    return re.search(SEARCH_ARTIFACT_PATH_REGEX, path) is not None


def is_code_search_path(path: str, *, path_prefix: str | None = None, explicit_file: bool = False) -> bool:
    """Owner eligibility policy; intentional artifact scopes never allow secrets.

    An artifact can be opted in only by a scope already inside its excluded
    subtree (or an exact file lookup), never by a broad ancestor such as data.
    """
    return _is_searchable_path(path) and (
        not is_search_artifact_path(path)
        or explicit_file
        or bool(path_prefix and is_search_artifact_path(path_prefix) and _path_matches_prefix(path, path_prefix))
    )


def code_search_exclude_globs(path_prefix: str | None = None) -> tuple[str, ...]:
    """Traversal exclusions appropriate for a normalized explicit scope."""
    artifacts = () if path_prefix and is_search_artifact_path(path_prefix) else SEARCH_ARTIFACT_EXCLUDE_GLOBS
    return (*CHECKOUT_EXCLUDE_GLOBS, *artifacts)


CHECKOUT_RIPGREP_TIMEOUT_SECONDS = 15
LINE_PREVIEW_LIMIT = 240


def _normalize_path_prefix(path_prefix: str | None) -> str | None:
    """Normalize an optional relative file/subtree prefix."""
    if path_prefix is None:
        return None
    normalized = str(path_prefix).strip().replace("\\", "/")
    path = Path(normalized)
    if path.is_absolute():
        raise ValueError("Absolute search paths need an available selected root; use a relative --path")
    if ".." in path.parts:
        raise ValueError("Search path must stay inside the selected root (no '..')")
    return path.as_posix() if path.parts else None


def normalize_search_path(root: Path | None, path_prefix: str | None, *, must_exist: bool = True) -> str | None:
    """Validate scope against the selected root before discovery or transport."""
    if path_prefix is None or not str(path_prefix).strip():
        return None
    raw = str(path_prefix).strip().replace("\\", "/")
    if root is None or not root.is_dir():
        normalized = _normalize_path_prefix(raw)
        if normalized and not _is_searchable_path(normalized):
            raise ValueError("Search path is excluded for safety")
        return normalized
    root = root.resolve()
    path = Path(raw)
    if ".." in path.parts:
        raise ValueError("Search path must stay inside the selected root (no '..')")
    target = path if path.is_absolute() else root / path
    try:
        lexical = target.relative_to(root).as_posix()
        resolved = target.resolve().relative_to(root).as_posix()
    except ValueError as exc:
        raise ValueError(f"Search path must stay inside selected root {root}") from exc
    if not _is_searchable_path(lexical) or not _is_searchable_path(resolved):
        raise ValueError("Search path is excluded for safety")
    if must_exist and not target.exists():
        raise ValueError(f"Search path does not exist inside selected root: {raw}")
    return None if resolved == "." else resolved


def _path_matches_prefix(path: str, path_prefix: str | None) -> bool:
    normalized_prefix = _normalize_path_prefix(path_prefix)
    return not normalized_prefix or path == normalized_prefix or path.startswith(f"{normalized_prefix}/")


def _checkout_has_local_changes(root: Path | None) -> bool:
    """Return True when the checkout contains tracked or untracked changes."""
    if root is None:
        return False
    try:
        proc = subprocess.run(
            ["git", "status", "--short", "--untracked-files=all"],
            cwd=root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return True
    return proc.returncode != 0 or bool(proc.stdout.strip())


def _normalize_rel_path(root: Path, path: Path) -> str | None:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return None


def _is_searchable_path(rel_path: str) -> bool:
    path = Path(rel_path)
    parts = {part.lower() for part in path.parts}
    name = path.name.lower()
    return (
        not path.is_absolute()
        and ".." not in path.parts
        and not parts.intersection(CHECKOUT_EXCLUDE_DIRS)
        and not any(part.startswith(".env") or part in CHECKOUT_EXCLUDE_NAMES or Path(part).suffix in CHECKOUT_EXCLUDE_SUFFIXES for part in parts)
        and not name.startswith(".env")
        and name not in CHECKOUT_EXCLUDE_NAMES
        and path.suffix.lower() not in CHECKOUT_EXCLUDE_SUFFIXES
    )


def _is_test_path(rel_path: str) -> bool:
    path = Path(rel_path)
    return any(part.lower() in {"test", "tests", "__tests__", "spec", "specs"} for part in path.parts[:-1]) or path.name.lower().startswith(("test_", "spec_")) or path.name.lower().endswith((".test.ts", ".test.tsx", ".spec.ts", ".spec.tsx"))


def _resolve_checkout_path_prefix(root: Path, path_prefix: str | None) -> tuple[str | None, Path | None]:
    normalized_prefix = normalize_search_path(root, path_prefix)
    return normalized_prefix, (root / normalized_prefix).resolve() if normalized_prefix else root


def _iter_checkout_files(
    root: Path,
    *,
    allowed_suffixes: set[str] | None = None,
    start_root: Path | None = None,
) -> list[Path]:
    walk_root = (start_root or root).resolve()
    path_prefix = _normalize_rel_path(root, walk_root) if start_root else None
    if walk_root.is_file():
        rel_path = _normalize_rel_path(root, walk_root)
        if rel_path is None or not is_code_search_path(rel_path, path_prefix=path_prefix):
            return []
        if allowed_suffixes is not None and walk_root.suffix.lower() not in allowed_suffixes:
            return []
        return [walk_root]
    results: list[Path] = []
    for dirpath, dirnames, filenames in walk_root.walk(top_down=True):
        dirnames[:] = [name for name in dirnames if is_code_search_path((dirpath / name).relative_to(root).as_posix(), path_prefix=path_prefix)]
        for filename in filenames:
            path = dirpath / filename
            rel_path = _normalize_rel_path(root, path)
            if rel_path and is_code_search_path(rel_path, path_prefix=path_prefix) and (allowed_suffixes is None or path.suffix.lower() in allowed_suffixes):
                results.append(path)
    return results


def _ripgrep_candidate_paths(
    root: Path,
    query: str,
    *,
    limit: int | None,
    suffixes: set[str] | None = None,
    path_prefix: str | None = None,
) -> list[Path] | None:
    rg_path = shutil.which("rg")
    if not rg_path:
        return None
    normalized_prefix, target_root = _resolve_checkout_path_prefix(root, path_prefix)
    if normalized_prefix and target_root is None:
        return []

    args = [rg_path, "-l", "--ignore-case", "--fixed-strings", "--hidden", "--no-ignore"]
    if suffixes:
        for suffix in sorted(suffixes):
            args.extend(["--glob", f"*{suffix}"])
    for glob in code_search_exclude_globs(normalized_prefix):
        args.extend(["--glob", glob])
    args.extend(["--", query, normalized_prefix or "."])

    try:
        proc = subprocess.run(
            args,
            cwd=root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=CHECKOUT_RIPGREP_TIMEOUT_SECONDS,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if proc.returncode not in (0, 1):
        return None
    return _existing_file_paths(root, proc.stdout.splitlines(), limit, path_prefix=normalized_prefix)


def _existing_file_paths(root: Path, lines: list[str], limit: int | None, *, path_prefix: str | None = None) -> list[Path]:
    results: list[Path] = []
    for raw_line in sorted(lines, key=lambda value: (_is_test_path(value), value)):
        rel_path = raw_line.strip()
        if not rel_path:
            continue
        candidate = (root / rel_path).resolve()
        normalized = _normalize_rel_path(root, candidate)
        if candidate.is_file() and normalized and is_code_search_path(normalized, path_prefix=path_prefix):
            results.append(candidate)
        if limit is not None and len(results) >= limit:
            break
    return results
