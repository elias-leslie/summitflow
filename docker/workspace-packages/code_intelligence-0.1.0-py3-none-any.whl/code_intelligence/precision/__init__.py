"""Local current-source precision search: query parsing, ranking and assembly."""

from .current_search import CurrentSearchResult, collect_current_search_context

__all__ = [
    "CurrentSearchResult",
    "collect_current_search_context",
]
