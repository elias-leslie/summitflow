"""Current-source precision search shared by hosted and checkout callers.

The index supplies candidates, never authority for current source. A small
targeted live search closes gaps left by additions, edits, and stale indexes.
"""

from __future__ import annotations

import hashlib
import re
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from code_intelligence.analyzers.symbol_extractor import extract_symbols_from_source
from code_intelligence.search.search_budget import truncate_prompt_to_budget
from code_intelligence.search.search_checkout_paths import (
    SUPPORTED_SYMBOL_EXTENSIONS,
    _is_searchable_path,
    _iter_checkout_files,
    _normalize_path_prefix,
    _normalize_rel_path,
    _path_matches_prefix,
    _ripgrep_candidate_paths,
)
from code_intelligence.search.search_checkout_symbols import _expand_symbol_queries
from code_intelligence.search.search_checkout_text import _search_checkout_text

from .query import (
    expand_case_variants,
    extract_query_terms,
    identifier_shaped_tokens,
    is_import_query,
    meaningful_terms,
    normalize_queries,
    split_path_and_symbol_terms,
)
from .ranking import normalize_match_text, search_and_rank_symbols, symbol_match_rank
from .sections import _format_related_entry
from .token_utils import estimate_tokens

SearchText = Callable[..., dict[str, Any]]
_TEXT_LIMIT = 12
_LIVE_TERM_LIMIT = 12
_SOURCE_SLICE_LIMIT = 2
_TEXT_BUDGET_SHARE = 0.3
_DEFINITION_PATTERN = re.compile(
    r"\b(?:def|class|function|fn|interface|struct|enum|trait|type|const|let|var|val)\s+([\w$]+)\b"
)


@dataclass(slots=True)
class CurrentSearchResult:
    prompt_context: str
    metadata: dict[str, object]
    candidates: list[dict[str, object]] | None = None


@dataclass(slots=True)
class _Source:
    raw: bytes
    text: str
    lines: list[str]


def _source_for(
    root: Path,
    rel_path: str,
    sources: dict[str, _Source | None],
    errors: list[str],
) -> _Source | None:
    if rel_path in sources:
        return sources[rel_path]
    target = (root / rel_path).resolve()
    if (
        not target.is_relative_to(root)
        or not target.is_file()
        or not _is_searchable_path(rel_path)
    ):
        sources[rel_path] = None
        return None
    try:
        raw = target.read_bytes()
        text = raw.decode("utf-8")
    except (OSError, UnicodeDecodeError):
        errors.append(f"source_read_failed:{rel_path}")
        sources[rel_path] = None
        return None
    source = _Source(raw=raw, text=text, lines=text.splitlines())
    sources[rel_path] = source
    return source


def _verified_row(
    root: Path,
    row: dict[str, object],
    sources: dict[str, _Source | None],
    errors: list[str],
    path_prefix: str | None,
) -> dict[str, object] | None:
    rel_path = str(row.get("file_path") or "")
    if not rel_path or not _is_searchable_path(rel_path) or not _path_matches_prefix(rel_path, path_prefix):
        return None
    source = _source_for(root, rel_path, sources, errors)
    if source is None:
        return None
    expected = row.get("content_hash")
    try:
        offset = int(str(row["byte_offset"]))
        length = int(str(row["byte_length"]))
    except (KeyError, TypeError, ValueError):
        return None
    if not isinstance(expected, str) or not expected or offset < 0 or length <= 0:
        return None
    actual = source.raw[offset : offset + length]
    if len(actual) != length or hashlib.sha256(actual).hexdigest() != expected:
        return None
    start_line = source.raw[:offset].count(b"\n") + 1
    end_line = start_line + actual.count(b"\n") - int(actual.endswith(b"\n"))
    try:
        if int(str(row["start_line"])) != start_line or int(str(row["end_line"])) != end_line:
            return None
    except (KeyError, TypeError, ValueError):
        return None
    try:
        actual.decode("utf-8")
    except UnicodeDecodeError:
        return None
    return {**row, "source_origin": "index", "source_verified": True}


def _live_rows(
    root: Path,
    query: str,
    path_prefix: str | None,
    sources: dict[str, _Source | None],
    errors: list[str],
) -> tuple[list[dict[str, object]], set[str]]:
    terms = list(dict.fromkeys(_expand_symbol_queries(query)))[:_LIVE_TERM_LIMIT]
    paths: dict[str, Path] = {}
    for term in terms:
        if not term or len(term) > 100:
            continue
        found = _ripgrep_candidate_paths(
            root,
            term,
            limit=None,
            suffixes=SUPPORTED_SYMBOL_EXTENSIONS,
            path_prefix=path_prefix,
        )
        if found is None:
            errors.append("candidate_lookup_failed")
            break
        for path in found:
            rel_path = _normalize_rel_path(root, path)
            if rel_path:
                paths[rel_path] = path
    if any(marker in query for marker in ("/", ".py", ".ts", ".tsx")):
        for path in _iter_checkout_files(root, allowed_suffixes=SUPPORTED_SYMBOL_EXTENSIONS):
            rel_path = _normalize_rel_path(root, path)
            if rel_path and _path_matches_prefix(rel_path, path_prefix) and any(
                term.lower() in rel_path.lower() for term in terms
            ):
                paths[rel_path] = path

    if "candidate_lookup_failed" in errors:
        for path in _iter_checkout_files(root, allowed_suffixes=SUPPORTED_SYMBOL_EXTENSIONS):
            rel_path = _normalize_rel_path(root, path)
            if not rel_path or not _path_matches_prefix(rel_path, path_prefix):
                continue
            source = _source_for(root, rel_path, sources, errors)
            if source is None:
                continue
            if any(term.lower() in source.text.lower() for term in terms):
                paths[rel_path] = path

    rows: list[dict[str, object]] = []
    parsed_paths: set[str] = set()
    for rel_path in sorted(paths):
        source = _source_for(root, rel_path, sources, errors)
        if source is None:
            continue
        try:
            symbols = extract_symbols_from_source(source.text, rel_path)
        except (SyntaxError, ValueError, RuntimeError):
            errors.append(f"source_parse_failed:{rel_path}")
            continue
        parsed_paths.add(rel_path)
        for symbol in symbols:
            row = _verified_row(root, {**symbol, "file_path": rel_path}, sources, errors, path_prefix)
            if row is not None:
                row["source_origin"] = "live"
                rows.append(row)
            else:
                errors.append(f"source_coordinates_invalid:{rel_path}")
    return rows, parsed_paths


def _rank_rows(
    project_id: str,
    queries: list[str],
    indexed: list[dict[str, object]],
    live: list[dict[str, object]],
    path_prefix: str | None,
) -> tuple[list[dict[str, object]], list[str]]:
    query = " ".join(queries)
    path_terms, symbol_terms = split_path_and_symbol_terms(queries)
    effective_queries = symbol_terms or path_terms or queries
    query_terms = extract_query_terms(effective_queries)
    normalized_queries = [normalize_match_text(value) for value in effective_queries]
    normalized_terms = [normalize_match_text(value) for value in query_terms]
    identifiers = identifier_shaped_tokens(effective_queries)
    variants = {variant.lower() for token in identifiers for variant in expand_case_variants(token)}

    by_identity: dict[tuple[str, str, str, str], dict[str, object]] = {}
    for row in [*indexed, *live]:
        path = str(row.get("file_path") or "")
        if not path or not _path_matches_prefix(path, path_prefix):
            continue
        identity = (
            project_id,
            path,
            str(row.get("symbol_id") or row.get("qualified_name") or ""),
            str(row.get("kind") or ""),
        )
        if row.get("source_origin") == "live" or identity not in by_identity:
            by_identity[identity] = row

    def relevant(row: dict[str, object]) -> bool:
        blob = " ".join(str(row.get(key) or "") for key in (
            "name", "qualified_name", "file_path", "signature", "summary", "keywords"
        )).lower()
        return any(term.lower() in blob for term in query_terms) or query.lower() in blob

    ranked = [row for row in by_identity.values() if relevant(row)]
    if variants and not any(
        variant in " ".join(str(row.get(key) or "") for key in ("name", "qualified_name", "file_path")).lower()
        for row in ranked for variant in variants
    ):
        return [], identifiers

    ranked.sort(
        key=lambda row: (
            symbol_match_rank(row, normalized_queries, normalized_terms),
            row.get("source_origin") == "live",
        ),
        reverse=True,
    )
    matched_identifiers = [
        token for token in identifiers
        if not any(
            variant.lower() in " ".join(str(row.get(key) or "") for key in ("name", "qualified_name", "file_path")).lower()
            for row in ranked for variant in expand_case_variants(token)
        )
    ]
    return ranked, matched_identifiers


def _symbol_section(
    rows: list[dict[str, object]],
    sources: dict[str, _Source | None],
    related_map: dict[str, list[dict[str, object]]],
) -> str:
    if not rows:
        return ""
    lines = ["## Relevant Symbols", ""]
    emitted_related: set[str] = set()
    for row in rows:
        detail = row.get("summary") or row.get("signature") or ""
        suffix = f" - {detail}" if detail else ""
        lines.append(
            f"- `{row.get('qualified_name') or row.get('name')}` "
            f"({row.get('kind') or 'unknown'}) in {row['file_path']}:{row.get('start_line')}{suffix}"
        )
        path = str(row["file_path"])
        if path in emitted_related:
            continue
        emitted_related.add(path)
        for entry in related_map.get(path, [])[:2]:
            formatted = _format_related_entry(entry)
            if formatted:
                lines.append(f"  related (indexed): {formatted}")

    intervals: dict[str, list[tuple[int, int, str, int, int]]] = {}
    for row in rows[:_SOURCE_SLICE_LIMIT]:
        path = str(row["file_path"])
        source = sources.get(path)
        if source is None:
            continue
        try:
            start = int(str(row["byte_offset"]))
            end = start + int(str(row["byte_length"]))
            start_line = int(str(row["start_line"]))
            end_line = int(str(row["end_line"]))
            decorator_start_line = int(str(row.get("decorator_start_line", start_line)))
        except (KeyError, TypeError, ValueError):
            continue
        if decorator_start_line < start_line:
            source_lines = source.raw.splitlines(keepends=True)
            start = sum(len(line) for line in source_lines[: decorator_start_line - 1])
            start_line = decorator_start_line
        intervals.setdefault(path, []).append((
            start, end, str(row.get("qualified_name") or row.get("name")), start_line, end_line
        ))
    slices: list[str] = []
    for path, values in intervals.items():
        merged: list[tuple[int, int, list[str], int, int]] = []
        for start, end, name, start_line, end_line in sorted(values):
            if merged and start <= merged[-1][1]:
                previous_start, previous_end, names, first_line, last_line = merged[-1]
                merged[-1] = (
                    previous_start, max(previous_end, end), [*names, name],
                    min(first_line, start_line), max(last_line, end_line),
                )
            else:
                merged.append((start, end, [name], start_line, end_line))
        source = sources[path]
        assert source is not None
        for start, end, names, start_line, end_line in merged:
            slices.extend([
                f"### `{', '.join(dict.fromkeys(names))}` ({path}:{start_line}-{end_line})",
                "```",
                source.raw[start:end].decode("utf-8").rstrip(),
                "```",
                "",
            ])
    if slices:
        lines.extend(["", "## Exact Source Slices", "", *slices])
    return "\n".join(lines).strip()


def _text_matches(
    project_id: str,
    queries: list[str],
    root: Path | None,
    search_text: SearchText,
    path_prefix: str | None,
    sources: dict[str, _Source | None],
    errors: list[str],
) -> dict[str, Any]:
    path_terms, _ = split_path_and_symbol_terms(queries)
    phrase = " ".join(path_terms) if path_terms else " ".join(queries)

    def search(needle: str) -> dict[str, Any]:
        # The hosted index remains a candidate transport; only lines matching
        # current source bytes may survive validation.
        indexed: dict[str, Any]
        live: dict[str, Any]
        try:
            indexed = search_text(project_id, needle, limit=_TEXT_LIMIT, path_prefix=path_prefix)
        except Exception as exc:
            errors.append(f"text_index_failed:{type(exc).__name__}")
            indexed = {"items": [], "count": 0, "files_searched": 0}
        if root is None:
            return {"items": [], "count": 0, "files_searched": 0, "truncated": False}
        try:
            live = _search_checkout_text(root, needle, limit=_TEXT_LIMIT, path_prefix=path_prefix)
        except (OSError, ValueError):
            errors.append("text_lookup_failed")
            live = {"items": [], "count": 0, "files_searched": 0, "truncated": False}
        seen: set[tuple[str, int]] = set()
        items: list[dict[str, Any]] = []
        for source_result in (live, indexed):
            for item in source_result.get("items") or []:
                if not isinstance(item, dict):
                    continue
                path = str(item.get("path") or "")
                if not path or not _is_searchable_path(path) or not _path_matches_prefix(path, path_prefix):
                    continue
                try:
                    line = int(str(item.get("line")))
                except (TypeError, ValueError):
                    continue
                snapshot = _source_for(root, path, sources, errors)
                if snapshot is None or not 1 <= line <= len(snapshot.lines):
                    continue
                current = snapshot.lines[line - 1]
                if needle.lower() not in current.lower():
                    continue
                key = (path, line)
                if key not in seen:
                    seen.add(key)
                    items.append({**item, "content": current[:240], "line": line, "path": path})
        items.sort(key=lambda item: (str(item["path"]), int(item["line"])))
        count = max(len(items), int(live.get("count") or 0))
        return {
            "items": items[:_TEXT_LIMIT],
            "count": count,
            "files_searched": int(live.get("files_searched") or 0),
            "truncated": bool(live.get("truncated")) or len(items) > _TEXT_LIMIT,
        }

    result = search(phrase)
    if result["items"]:
        return result
    terms = list(dict.fromkeys(meaningful_terms(phrase)))
    if len(terms) < 2:
        return result
    union: dict[tuple[str, int], dict[str, Any]] = {}
    files_searched = int(result["files_searched"])
    for term in terms:
        part = search(term)
        files_searched = max(files_searched, int(part["files_searched"]))
        part_items = part["items"]
        if not part_items or part["truncated"] or len(part_items) >= _TEXT_LIMIT:
            continue
        for item in part_items:
            union[(str(item["path"]), int(item["line"]))] = item
    if not union:
        return result
    items = list(union.values())
    items.sort(key=lambda item: (str(item["path"]), int(item["line"])))
    return {
        "items": items[:_TEXT_LIMIT],
        "count": len(items),
        "files_searched": files_searched,
        "truncated": len(items) > _TEXT_LIMIT,
        "per_term_union": True,
    }


def _text_section(items: list[dict[str, Any]]) -> str:
    if not items:
        return ""
    return "\n".join([
        "## Relevant Text Matches",
        "",
        *(f"- {item['path']}:{item['line']} - {str(item['content']).strip()}" for item in items),
    ])


def _visible_counts(body: str) -> tuple[int, int]:
    section = ""
    symbols = 0
    matches = 0
    fenced = False
    for line in body.splitlines():
        if line.strip() == "```":
            fenced = not fenced
        elif not fenced and line.startswith("## "):
            section = line
        elif not fenced and line.startswith("- "):
            if section == "## Relevant Symbols":
                symbols += 1
            elif section == "## Relevant Text Matches":
                matches += 1
    return symbols, matches


def _definition_terms(queries: list[str], items: list[dict[str, Any]]) -> list[str]:
    asked = {term for query in queries for term in query.split() if len(term) >= 3}
    found = {
        match.group(1)
        for item in items
        for match in _DEFINITION_PATTERN.finditer(str(item.get("content") or ""))
    }
    return sorted(asked & found)


def collect_current_search_context(
    project_id: str,
    queries: list[str] | tuple[str, ...] | str,
    *,
    project_root: Path | None,
    search_text: SearchText,
    budget_tokens: int = 1200,
    symbol_limit: int = 5,
    path_prefix: str | None = None,
    index_status: dict[str, object] | None = None,
    include_candidates: bool = False,
    indexed_candidates: list[dict[str, object]] | None = None,
    list_related_entries_for_file: Callable[[str, str], list[dict[str, object]]] | None = None,
) -> CurrentSearchResult:
    """Return a bounded, source-verified result; optionally transport candidates."""
    started = time.perf_counter()
    normalized = normalize_queries(queries)
    prefix = _normalize_path_prefix(path_prefix)
    errors: list[str] = []
    root = project_root.resolve() if project_root is not None else None
    if root is None or not root.is_dir():
        root = None
        errors.append("source_root_unavailable")
    sources: dict[str, _Source | None] = {}
    indexed: list[dict[str, object]] = []
    live: list[dict[str, object]] = []
    coverage: dict[str, object] = {}
    query = " ".join(normalized)
    if normalized and not is_import_query(normalized):
        try:
            rows = indexed_candidates
            if rows is None:
                rows = search_and_rank_symbols(
                    project_id,
                    normalized,
                    symbol_limit=max(symbol_limit * 4, 50),
                    path_prefix=prefix,
                    identifier_tokens=identifier_shaped_tokens(normalized),
                    coverage=coverage,
                )
        except Exception as exc:
            errors.append(f"symbol_index_failed:{type(exc).__name__}")
            rows = []
        if root is not None:
            for row in rows:
                verified = _verified_row(root, row, sources, errors, prefix)
                if verified is not None:
                    indexed.append(verified)
            live, parsed_paths = _live_rows(root, query, prefix, sources, errors)
            indexed = [
                row for row in indexed if str(row.get("file_path")) not in parsed_paths
            ]
    ranked, missed_identifiers = _rank_rows(project_id, normalized, indexed, live, prefix)
    selected = ranked[: max(symbol_limit, 0)]
    related_map: dict[str, list[dict[str, object]]] = {}
    if list_related_entries_for_file is not None:
        for path in dict.fromkeys(str(row["file_path"]) for row in selected):
            try:
                related_map[path] = list_related_entries_for_file(project_id, path)
            except Exception as exc:
                errors.append(f"related_index_failed:{type(exc).__name__}")
    else:
        for row in selected:
            entries = row.get("related_entries")
            if isinstance(entries, list):
                related_map[str(row["file_path"])] = [
                    cast(dict[str, object], entry) for entry in entries if isinstance(entry, dict)
                ]
    symbol_section = _symbol_section(selected, sources, related_map)
    weak_plain_phrase = False
    plain_terms = meaningful_terms(normalize_match_text(query))
    if len(plain_terms) >= 2 and "_" not in query and not re.search(r"[a-z][A-Z]", query):
        weak_plain_phrase = not any(
            all(term in normalize_match_text(" ".join(str(row.get(key) or "") for key in (
                "name", "qualified_name", "file_path", "signature", "summary"
            ))) for term in plain_terms)
            for row in selected
        )
    text_result: dict[str, Any] = {"items": [], "count": 0, "files_searched": 0, "truncated": False}
    if normalized and (not symbol_section or weak_plain_phrase or is_import_query(normalized)):
        text_result = _text_matches(
            project_id, normalized, root, search_text, prefix, sources, errors
        )
    retrieval_ms = round((time.perf_counter() - started) * 1000, 2)
    text_items = text_result.get("items") or []
    text_section = _text_section(text_items)
    if symbol_section and text_section:
        mode = "combined"
    elif symbol_section:
        mode = "symbol-first"
    elif text_section:
        mode = "text-fallback"
    else:
        mode = "empty"
    header = f"Precision Code Search: {mode}"
    available = max(0, budget_tokens - estimate_tokens(header + "\n\n"))
    if symbol_section and text_section and estimate_tokens(symbol_section + "\n\n" + text_section) > available:
        text_budget = min(estimate_tokens(text_section), int(available * _TEXT_BUDGET_SHARE))
        visible_text = truncate_prompt_to_budget(text_section, text_budget)
        symbol_budget = max(0, available - estimate_tokens(visible_text + "\n\n"))
        visible_symbol = truncate_prompt_to_budget(symbol_section, symbol_budget)
        body = "\n\n".join(part for part in (visible_symbol, visible_text) if part)
    else:
        body = truncate_prompt_to_budget(
            "\n\n".join(part for part in (symbol_section, text_section) if part), available
        )
    prompt = f"{header}\n\n{body}" if body else ""
    if estimate_tokens(prompt) > budget_tokens:
        prompt = truncate_prompt_to_budget(prompt, budget_tokens)
    symbol_count, text_count = _visible_counts(prompt)
    prompt_truncated = bool(body) and body != "\n\n".join(
        part for part in (symbol_section, text_section) if part
    )
    if (symbol_section or text_section) and not body:
        prompt_truncated = True
    visible_symbol_lines = [
        line for line in prompt.splitlines()
        if line.startswith("- `") and " in " in line
    ]
    visible_paths = {
        match.group(1)
        for line in visible_symbol_lines
        if (match := re.search(r" in (.+?):\d+(?: -|$)", line))
    }
    unique_files = {str(row["file_path"]) for row in selected if str(row["file_path"]) in visible_paths}
    measured_files = [sources[path] for path in unique_files if sources.get(path) is not None]
    measurement_available = bool(measured_files) and len(measured_files) == len(unique_files)
    baseline = sum(estimate_tokens(source.text) for source in measured_files if source is not None)
    prompt_tokens = estimate_tokens(prompt)
    metadata: dict[str, object] = {
        **(index_status or {}),
        "query_count": len(normalized),
        "path_prefix": prefix,
        "source_root": str(root) if root else None,
        "source_verified": root is not None and (
            (bool(selected or text_items) and all(row.get("source_verified") for row in selected))
            or not errors
        ),
        "retrieval_complete": not errors,
        "retrieval_errors": list(dict.fromkeys(errors)),
        "retrieval_ms": retrieval_ms,
        "symbol_count": symbol_count,
        "candidate_count": len(ranked),
        "text_match_count": text_count,
        "text_files_searched": text_result.get("files_searched", 0),
        "text_per_term_union": bool(text_result.get("per_term_union")),
        "definition_matched_terms": _definition_terms(normalized, text_items) if not selected else [],
        "missed_identifier_terms": missed_identifiers,
        "suppressed_generic_symbols": coverage.get("suppressed_generic_symbols", 0),
        "used_symbol_first": symbol_count > 0,
        "used_fallback": text_count > 0,
        "fallback_mode": "text" if text_count > 0 else None,
        "symbol_tokens": estimate_tokens(symbol_section),
        "fallback_tokens": estimate_tokens(text_section),
        "naive_file_tokens": baseline if measurement_available else 0,
        "measurement_available": measurement_available,
        "baseline_label": "unique_current_source_files" if measurement_available else None,
        "estimated_tokens_saved": max(baseline - prompt_tokens, 0) if measurement_available else 0,
        "prompt_tokens": prompt_tokens,
        "final_tokens": prompt_tokens,
        "emitted_output_tokens": None,
        "prompt_truncated": prompt_truncated,
        "symbol_truncated": len(ranked) > symbol_count,
        "text_truncated": bool(text_result.get("truncated")) or len(text_items) > text_count,
        "stale_hit": bool((index_status or {}).get("should_refresh")),
        "refreshed_index": bool((index_status or {}).get("refreshed_index")),
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 2),
    }
    transport = [
        {
            **{key: value for key, value in row.items() if key not in {"keywords", "decorators"}},
            "related_entries": related_map.get(str(row["file_path"]), []),
        }
        for row in ranked
    ] if include_candidates else None
    return CurrentSearchResult(prompt_context=prompt, metadata=metadata, candidates=transport)
