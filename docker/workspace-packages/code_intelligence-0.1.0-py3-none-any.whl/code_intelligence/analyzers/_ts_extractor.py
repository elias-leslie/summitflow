"""TypeScript and TSX symbol extraction using Tree-sitter syntax trees."""

from __future__ import annotations

from typing import cast

import tree_sitter_typescript
from tree_sitter import Language, Node, Parser

from ._helpers import content_hash, keywords
from .symbol_types import SymbolRecord

_DECLARATIONS = {
    "interface_declaration": "type",
    "type_alias_declaration": "type",
    "class_declaration": "class",
    "abstract_class_declaration": "class",
    "function_declaration": "function",
    "generator_function_declaration": "function",
    "enum_declaration": "type",
}
_FUNCTION_VALUES = {"arrow_function", "function_expression", "generator_function"}
_PARSERS = {
    "typescript": Parser(Language(tree_sitter_typescript.language_typescript())),
    "tsx": Parser(Language(tree_sitter_typescript.language_tsx())),
}


def extract_typescript_symbols(source: str, rel_path: str, language: str) -> list[SymbolRecord]:
    """Extract actual declarations, including exported declarations and arrow functions."""
    source_bytes = source.encode("utf-8")
    root = _PARSERS[language].parse(source_bytes).root_node
    if root.has_error:
        raise SyntaxError(f"invalid {language} syntax in {rel_path}")
    symbols: list[SymbolRecord] = []
    for statement in root.named_children:
        declaration = statement.child_by_field_name("declaration") if statement.type == "export_statement" else statement
        if declaration is None:
            continue
        if declaration.type in _DECLARATIONS:
            name_node = declaration.child_by_field_name("name")
            if name_node is not None:
                name = _decode(source_bytes, name_node)
                symbols.append(_symbol(source_bytes, statement, name, _DECLARATIONS[declaration.type], rel_path, language))
        elif declaration.type in {"lexical_declaration", "variable_declaration"}:
            for declarator in declaration.named_children:
                if declarator.type != "variable_declarator":
                    continue
                name_node = declarator.child_by_field_name("name")
                value = declarator.child_by_field_name("value")
                if name_node is None or name_node.type != "identifier" or value is None:
                    continue
                if value.type in _FUNCTION_VALUES:
                    # The declaration includes modifiers and the complete arrow body.
                    node = statement if len(declaration.named_children) == 1 else declarator
                    symbols.append(_symbol(source_bytes, node, _decode(source_bytes, name_node), "function", rel_path, language))
    return symbols


def _decode(source: bytes, node: Node) -> str:
    return source[node.start_byte : node.end_byte].decode("utf-8")


def _symbol(source: bytes, node: Node, name: str, kind: str, rel_path: str, language: str) -> SymbolRecord:
    segment = _decode(source, node)
    signature = segment.splitlines()[0].strip() if segment else ""
    return cast(SymbolRecord, {
        "symbol_id": f"{rel_path}::{name}#{kind}",
        "qualified_name": name,
        "name": name,
        "kind": kind,
        "signature": signature,
        "language": language,
        "start_line": node.start_point.row + 1,
        "end_line": node.end_point.row + (1 if node.end_point.column else 0),
        "byte_offset": node.start_byte,
        "byte_length": node.end_byte - node.start_byte,
        "content_hash": content_hash(segment),
        "summary": None,
        "keywords": keywords(name, signature, None),
        "decorators": [],
    })
