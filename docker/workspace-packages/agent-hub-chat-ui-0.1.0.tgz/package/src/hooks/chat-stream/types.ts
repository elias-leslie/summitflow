/**
 * Type definitions for chat streaming.
 */

import type { ChatMessage, ToolExecution } from "../../types/chat";

/**
 * Internal state for tracking a stream's accumulated content.
 */
export interface StreamState {
  content: string;
  thinking: string;
  tools: ToolExecution[];
  /** Last processed sequence number — events with seq <= this are skipped on reconnect */
  lastSeq: number;
}

/**
 * Session data returned from the backend.
 */
export interface SessionToolExecution {
  id: string;
  name: string;
  input?: Record<string, unknown> | null;
  status: string;
  result?: string | null;
  duration_ms?: number | null;
}

export interface SessionData {
  id: string;
  provider?: string;
  messages?: Array<{
    id: number;
    role: string;
    content: string;
    created_at: string;
    agent_name?: string;
    model_used?: string;
    model_display_name?: string | null;
    agent_display_name?: string | null;
    thinking?: string | null;
    thinking_tokens?: number | null;
    tool_executions?: SessionToolExecution[];
  }>;
}

/**
 * Message history entry for API requests.
 */
export interface MessageHistoryEntry {
  role: string;
  content: string;
}

/**
 * Completion request body for the API.
 */
export interface CompletionRequest {
  agent_slug: string;
  messages: MessageHistoryEntry[];
  temperature: number;
  session_id?: string;
  working_dir?: string;
  tools_enabled: boolean;
  execute_tools?: boolean;
  max_turns?: number;
  project_id: string;
  stream: boolean;
  use_memory: boolean;
  memory_group_id: string;
}
